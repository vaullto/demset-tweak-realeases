﻿# =============================================================
#  Demset Tweaks — "لعبة صافية": مين داخل لعبتك؟
#  يقرا الملفات المحقونة داخل عملية اللعبة (الأوفرلاي والتسجيل)، والبرامج اللي تسجّل بالخلفية.
#  قراءة بس — الإطفاء يصير من مكانه (تويك أو إعدادات البرنامج نفسه).
# =============================================================

# الملفات اللي تحقن نفسها في الألعاب: [نمط الاسم، المعرّف]
$script:HookDlls = @(
  @('^discordhook', 'discord'), @('^gameoverlayrenderer', 'steam'), @('^nvspcap|^nvcamera|^nvshare|^nvgsync', 'nvidia'),
  @('^rtsshooks|^rtsscore', 'rtss'), @('^graphics-hook', 'obs'), @('medal', 'medal'), @('^owclient|overwolf|^ow-graphics', 'overwolf'),
  @('^eosovh', 'epic'), @('^igo(32|64)', 'ea'), @('^uplay_overlay|^upc_overlay|^overlay64', 'ubisoft'), @('^bnetoverlay|battle\.net.*overlay', 'battlenet'),
  @('^gamecapture|^ss-capture|steelseries', 'steelseries'), @('^razer', 'razer'), @('^amdrelivehook|^amdow', 'amd')
)
# برامج تسجّل أو ترسم بالخلفية: [اسم العملية، المعرّف]
$script:HookProcs = @(
  @('Discord', 'discord'), @('NVIDIA Overlay', 'nvidia'), @('nvcontainer', 'nvidia'), @('Medal', 'medal'), @('MedalEncoder', 'medal'),
  @('obs64', 'obs'), @('RTSS', 'rtss'), @('Overwolf', 'overwolf'), @('SteelSeriesGG', 'steelseries'), @('steam', 'steam'), @('EpicGamesLauncher', 'epic'),
  @('EADesktop', 'ea'), @('upc', 'ubisoft'), @('Battle.net', 'battlenet'), @('GameBar', 'gamebar'), @('XboxPcApp', 'gamebar'),
  @('wallpaper64', 'wallpaper'), @('wallpaper32', 'wallpaper'), @('Lively', 'wallpaper'), @('NZXT CAM', 'nzxt'), @('ArmouryCrate', 'armoury'), @('ArmouryCrateControlInterface', 'armoury'),
  @('lghub', 'ghub'), @('lghub_agent', 'ghub'), @('iCUE', 'icue'), @('XSplit.Core', 'xsplit'), @('Streamlabs OBS', 'streamlabs'), @('Streamlabs Desktop', 'streamlabs'),
  @('MSIAfterburner', 'afterburner'), @('RadeonSoftware', 'amd'), @('NVIDIA Share', 'nvidia'), @('OneDrive', 'onedrive'), @('Dropbox', 'dropbox'), @('GoogleDriveFS', 'gdrive'),
  @('SignalRgb', 'signalrgb'), @('RazerAppEngine', 'razer'), @('Razer Synapse 3', 'razer'), @('Spotify', 'spotify'),
  @('WhatsApp', 'whatsapp'), @('ms-teams', 'teams'), @('Teams', 'teams'), @('AnyDesk', 'anydesk'), @('Parsec', 'parsec')
)
# ما نعرضها أبد في "الثقيلين بالخلفية": ويندوز، الأنتي تشيت، التعريفات، برنامجنا
$script:HeavySkip = '^(idle|system|registry|smss|csrss|wininit|winlogon|services|lsass|svchost|dwm|explorer|fontdrvhost|memory compression|audiodg|msmpeng|nissrv|securityhealthservice|searchindexer|searchhost|startmenuexperiencehost|shellexperiencehost|textinputhost|runtimebroker|ctfmon|sihost|taskhostw|conhost|dllhost|wmiprvse|spoolsv|vgc|vgtray|easyanticheat.*|beservice|faceit.*|demset.*|electron|powershell|pwsh|nvcontainer|nvdisplay\.container|amdrsserv|atiesrxx|atieclxx|igfxem|wudfhost|lsaiso|vmmem.*)$'

function Get-ModuleNames([int]$procId) {
  try { return @((Get-Process -Id $procId -ErrorAction Stop).Modules | ForEach-Object { $_.ModuleName.ToLower() }) } catch { return $null }
}

# نلقى اللعبة: عملية لها نافذة وفيها DirectX 11/12 أو Vulkan، ومو من البرامج العادية
function Find-GameProcess {
  $skip = 'explorer|chrome|msedge|firefox|brave|opera|discord|steam|steamwebhelper|epicgameslauncher|battle\.net|code|demset|electron|nvidia|medal|obs64|spotify|claude|textinputhost|searchhost|shellexperiencehost|applicationframehost|systemsettings|windowsterminal|powershell|taskmgr|eadesktop|upc|overwolf|lively|wallpaper|razer|steelseries'
  $best = $null
  foreach ($p in (Get-Process | Where-Object { $_.MainWindowHandle -ne 0 -and $_.ProcessName -notmatch "^($skip)" })) {
    $m = Get-ModuleNames $p.Id
    if (-not $m) { continue }
    if ($m -contains 'd3d12.dll' -or $m -contains 'd3d11.dll' -or $m -contains 'vulkan-1.dll') {
      if (-not $best -or $p.WorkingSet64 -gt $best.WorkingSet64) { $best = $p }
    }
  }
  return $best
}

function Invoke-HookScan($cfg) {
  $res = @{ heavy = @(); game = $null; gameName = $null; protected = $false; injected = @(); running = @(); gamebar = $null; steamOverlay = $null; at = (Get-Date).ToString('s') }
  # 1) اللعبة نفسها
  $g = $null
  if ($cfg -and $cfg.pid) { $g = Get-Process -Id ([int]$cfg.pid) -ErrorAction SilentlyContinue }
  if (-not $g) { $g = Find-GameProcess }
  if ($g) {
    $res.game = $g.Id; $res.gameName = $(if ($g.MainWindowTitle) { $g.MainWindowTitle } else { $g.ProcessName })
    $mods = Get-ModuleNames $g.Id
    if ($null -eq $mods) { $res.protected = $true }
    else {
      $found = @{}
      foreach ($m in $mods) { foreach ($h in $script:HookDlls) { if ($m -match $h[0]) { if (-not $found[$h[1]]) { $found[$h[1]] = @() }; $found[$h[1]] += $m } } }
      $res.injected = @($found.Keys | ForEach-Object { @{ id = $_; dlls = @($found[$_] | Select-Object -Unique) } })
    }
  }
  # 2) البرامج اللي شغّالة
  $names = @(Get-Process -ErrorAction SilentlyContinue | ForEach-Object { $_.ProcessName })
  $run = @{}
  foreach ($h in $script:HookProcs) { if ($names -contains $h[0]) { $run[$h[1]] = $true } }
  $res.running = @($run.Keys)
  # 2.5) الثقيلين بالخلفية على هذا الجهاز (يختلفون من جهاز لجهاز): معالج خلال ثانية ونص + رام
  try {
    $known = @{}; foreach ($h in $script:HookProcs) { $known[$h[0].ToLower()] = $true }
    $gid = $(if ($g) { $g.Id } else { 0 })
    $a = @{}; foreach ($p in (Get-Process -ErrorAction SilentlyContinue)) { try { $a[$p.Id] = $p.TotalProcessorTime.TotalMilliseconds } catch {} }
    Start-Sleep -Milliseconds 1500
    $cores = [Environment]::ProcessorCount; $win = $env:windir.ToLower()
    $agg = @{}
    foreach ($p in (Get-Process -ErrorAction SilentlyContinue)) {
      $n = $p.ProcessName; $nl = $n.ToLower()
      if ($p.Id -eq $gid -or $p.Id -le 4 -or $nl -match $script:HeavySkip -or $known[$nl]) { continue }
      $path = $null; try { $path = $p.Path } catch {}
      if (-not $path -or $path.ToLower().StartsWith($win)) { continue }
      $cpu = 0.0; try { if ($a.ContainsKey($p.Id)) { $cpu = ($p.TotalProcessorTime.TotalMilliseconds - $a[$p.Id]) / 1500 / $cores * 100 } } catch {}
      if (-not $agg[$nl]) { $agg[$nl] = @{ name = $n; path = $path; cpu = 0.0; mb = 0.0; n = 0; win = $false } }
      $agg[$nl].cpu += $cpu; $agg[$nl].mb += $p.WorkingSet64 / 1MB; $agg[$nl].n++
      if ($p.MainWindowHandle -ne 0) { $agg[$nl].win = $true }
    }
    $res.heavy = @($agg.Values | Where-Object { $_.cpu -ge 1.5 -or $_.mb -ge 400 } | Sort-Object { $_.cpu * 40 + $_.mb } -Descending | Select-Object -First 8 | ForEach-Object {
      $desc = $null; try { $desc = (Get-Item -LiteralPath $_.path).VersionInfo.FileDescription } catch {}
      @{ name = $_.name; title = $(if ($desc) { $desc.Trim() } else { $_.name }); path = $_.path; cpu = [math]::Round($_.cpu, 1); mb = [int]$_.mb; count = $_.n; window = $_.win }
    })
  } catch {}
  # 3) Xbox Game Bar والتسجيل حقه
  try {
    $dvr = (Get-ItemProperty 'HKCU:\System\GameConfigStore' -ErrorAction SilentlyContinue).GameDVR_Enabled
    $cap = (Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -ErrorAction SilentlyContinue).AppCaptureEnabled
    $res.gamebar = @{ dvr = $dvr; capture = $cap; on = (($dvr -ne 0) -or ($cap -ne 0)) }
  } catch {}
  # 4) أوفرلاي Steam من إعداداتك (localconfig.vdf)
  try {
    $sp = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction Stop).SteamPath
    if ($sp) {
      $vals = @()
      foreach ($f in (Get-ChildItem -LiteralPath (Join-Path $sp 'userdata') -Directory -ErrorAction SilentlyContinue)) {
        $lc = Join-Path $f.FullName 'config\localconfig.vdf'
        if (Test-Path -LiteralPath $lc) { $m = [regex]::Match((Get-Content -LiteralPath $lc -Raw -Encoding UTF8), '"EnableGameOverlay"\s+"(\d)"'); if ($m.Success) { $vals += [int]$m.Groups[1].Value } }
      }
      $res.steamOverlay = $(if ($vals.Count) { [bool]($vals | Measure-Object -Maximum).Maximum } else { $null })
    }
  } catch {}
  Emit 'hooks' (ConvertTo-Json -InputObject $res -Compress -Depth 5)
}

function Stop-Recorder($cfg) {
  # عملية بالاسم (من قائمة الثقيلين) — بس لو مو من ويندوز
  if ($cfg.name) {
    $n = 0; $win = $env:windir.ToLower()
    foreach ($p in (Get-Process -Name $cfg.name -ErrorAction SilentlyContinue)) {
      $pp = $null; try { $pp = $p.Path } catch {}
      if (-not $pp -or $pp.ToLower().StartsWith($win) -or $p.ProcessName -match $script:HeavySkip) { continue }
      try { $p.Kill(); $n++ } catch {}
    }
    Log ('  سكّرت ' + $n + ' عملية (' + $cfg.name + ')')
    Emit 'hooks' (@{ stopped = $n } | ConvertTo-Json -Compress); return
  }
  $map = @{ wallpaper = @('wallpaper64', 'wallpaper32', 'Lively'); nzxt = @('NZXT CAM'); xsplit = @('XSplit.Core'); streamlabs = @('Streamlabs OBS', 'Streamlabs Desktop'); afterburner = @('MSIAfterburner'); signalrgb = @('SignalRgb'); spotify = @('Spotify'); whatsapp = @('WhatsApp'); teams = @('ms-teams', 'Teams'); parsec = @('Parsec'); anydesk = @('AnyDesk'); onedrive = @('OneDrive'); dropbox = @('Dropbox'); gdrive = @('GoogleDriveFS');
    medal = @('Medal', 'MedalEncoder'); overwolf = @('Overwolf', 'OverwolfBrowser', 'OverwolfHelper', 'OverwolfHelper64'); obs = @('obs64'); rtss = @('RTSS', 'RTSSHooksLoader64'); steelseries = @('SteelSeriesGG', 'SteelSeriesGGClient') }
  $n = 0
  foreach ($p in @($map[$cfg.id])) { Get-Process -Name $p -ErrorAction SilentlyContinue | ForEach-Object { try { $_.Kill(); $n++ } catch {} } }
  Log ("  سكّرت " + $n + " عملية (" + $cfg.id + ")")
  Emit 'hooks' (@{ stopped = $n } | ConvertTo-Json -Compress)
}
