﻿# Restore only service baselines recorded by Demset. No stop/kill operation lives
# in this module. Application relationships are evidence, not a universal graph.
function Get-CompatExe([string]$command) {
  $s = [Environment]::ExpandEnvironmentVariables($command).Trim()
  if ($s -match '^"([^"\r\n]+\.exe)"(?:\s|$)') { $s = $Matches[1] }
  elseif ($s -match '^([^"\r\n]+?\.exe)(?:\s|$)') { $s = $Matches[1] }
  else { return $null }
  try { if (-not [IO.Path]::IsPathRooted($s)) { return $null }; return [IO.Path]::GetFullPath($s) } catch { return $null }
}
function Test-CompatWithin([string]$path,[string]$root) {
  if (-not $path -or -not $root) { return $false }
  return $path.StartsWith($root.TrimEnd('\') + '\',[StringComparison]::OrdinalIgnoreCase)
}
function Test-CompatAppRoot([string]$root) {
  if (-not $root -or $root -notmatch '^[A-Za-z]:\\') { return $false }
  $r = $root.TrimEnd('\')
  foreach ($base in @($env:windir,$env:ProgramFiles,${env:ProgramFiles(x86)},$env:ProgramData,$env:APPDATA,$env:LOCALAPPDATA,$env:USERPROFILE,$env:PUBLIC,($env:ProgramFiles+'\Common Files'),(${env:ProgramFiles(x86)}+'\Common Files'))) {
    if ($base -and $r -ieq $base.TrimEnd('\')) { return $false }
  }
  if (Test-CompatWithin ($r+'\x') $env:windir) { return $false }
  return ($r.Length -gt 3)
}
function Get-CompatAppRoot([string]$exe,$installs) {
  if (-not $exe) { return $null }
  $matching = @($installs | Where-Object { Test-CompatWithin $exe $_.root } | Sort-Object { $_.root.Length } -Descending)
  if ($matching.Count) { return $matching[0].root }
  $root = Split-Path -Parent $exe
  if (Test-CompatAppRoot $root) { return $root }; return $null
}
function Get-CompatStartupApps {
  $out = @()
  $runRoots = @('HKCU:\Software\Microsoft\Windows\CurrentVersion','HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion')
  foreach ($root in $runRoots) {
    $key = Get-Item -LiteralPath ($root+'\Run') -ErrorAction SilentlyContinue
    if (-not $key) { continue }
    foreach ($name in $key.GetValueNames()) {
      $approvedPath=if($root -match '\\WOW6432Node\\'){($root -replace '\\WOW6432Node','')+'\Explorer\StartupApproved\Run32'}else{$root+'\Explorer\StartupApproved\Run'}
      $approved = Get-ItemProperty -LiteralPath $approvedPath -Name $name -ErrorAction SilentlyContinue
      $bytes = if ($approved) { $approved.$name } else { $null }
      if ($bytes -and ($bytes[0] -band 1) -ne 0) { continue }
      $exe = Get-CompatExe ([string]$key.GetValue($name))
      if ($exe -and (Test-Path -LiteralPath $exe -PathType Leaf)) { $out += @{name=$name;path=$exe;source='startup-run'} }
    }
    $key.Close()
  }
  $shell = $null
  foreach ($dir in @([Environment]::GetFolderPath('Startup'),[Environment]::GetFolderPath('CommonStartup'))) {
    if (-not $dir) { continue }
    foreach ($f in @(Get-ChildItem -LiteralPath $dir -File -ErrorAction SilentlyContinue)) {
      $hive=if($dir -eq [Environment]::GetFolderPath('CommonStartup')){'HKLM'}else{'HKCU'}
      $approved=Get-ItemProperty -LiteralPath ($hive+':\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder') -Name $f.Name -ErrorAction SilentlyContinue
      $bytes=if($approved){$approved.($f.Name)}else{$null}
      if($bytes -and ($bytes[0] -band 1) -ne 0){continue}
      $exe = $null
      if ($f.Extension -ieq '.exe') { $exe = $f.FullName }
      elseif ($f.Extension -ieq '.lnk') {
        try { if (-not $shell) { $shell=New-Object -ComObject WScript.Shell }; $exe=Get-CompatExe ('"'+$shell.CreateShortcut($f.FullName).TargetPath+'"') } catch {}
      }
      if ($exe -and (Test-Path -LiteralPath $exe -PathType Leaf)) { $out += @{name=$f.BaseName;path=$exe;source='startup-folder'} }
    }
  }
  if ($shell) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($shell) }
  # Logon/boot tasks count as startup only when enabled, not arbitrary schedules.
  try {
    foreach ($task in @(Get-ScheduledTask -ErrorAction Stop)) {
      if ($task.State -eq 'Disabled' -or $task.TaskPath -like '\Microsoft\*') { continue }
      $boot = @($task.Triggers | Where-Object { $_.CimClass.CimClassName -in @('MSFT_TaskLogonTrigger','MSFT_TaskBootTrigger') })
      if (-not $boot.Count) { continue }
      foreach ($action in @($task.Actions)) {
        $exe = Get-CompatExe ('"'+$action.Execute+'"')
        if ($exe -and (Test-Path -LiteralPath $exe -PathType Leaf)) { $out += @{name=$task.TaskName;path=$exe;source='startup-task'} }
      }
    }
  } catch {}
  return $out
}
function Get-CompatInventory {
  if ($script:compatInventory -and ([DateTime]::UtcNow-$script:compatInventory.at).TotalSeconds -lt 60) { return $script:compatInventory }
  $installs = @()
  foreach ($base in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall')) {
    foreach ($item in @(Get-ChildItem -LiteralPath $base -ErrorAction SilentlyContinue)) {
      $p=Get-ItemProperty -LiteralPath $item.PSPath -ErrorAction SilentlyContinue
      if (-not $p.DisplayName -or -not $p.InstallLocation) { continue }
      try { $root=[IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables([string]$p.InstallLocation).Trim('"')).TrimEnd('\'); if (Test-CompatAppRoot $root) { $installs += @{name=[string]$p.DisplayName;root=$root} } } catch {}
    }
  }
  $services = @(Get-CimInstance Win32_Service -Property Name,PathName,StartMode,State,ProcessId -ErrorAction Stop | ForEach-Object { @{name=$_.Name;path=(Get-CompatExe $_.PathName);mode=$_.StartMode;running=($_.State -eq 'Running');pid=[int]$_.ProcessId} })
  $script:compatInventory=@{at=[DateTime]::UtcNow;services=$services;installs=$installs;startup=@(Get-CompatStartupApps)}
  return $script:compatInventory
}
function Get-CompatRuntime {
  return @(Get-CimInstance Win32_Process -Property ProcessId,Name,ExecutablePath,ParentProcessId -ErrorAction Stop | Where-Object { $_.ExecutablePath } | ForEach-Object { @{name=$_.Name;path=$_.ExecutablePath;pid=[int]$_.ProcessId;parent=[int]$_.ParentProcessId;source='running'} })
}
function Get-CompatService([string]$name) {
  $s=Get-Service -Name $name -ErrorAction Stop
  $mode=switch ([string]$s.StartType) { 'Automatic' {2}; 'Manual' {3}; 'Disabled' {4}; default {-1} }
  return @{name=$s.Name;mode=$mode;running=($s.Status -eq 'Running');required=@($s.ServicesDependedOn | ForEach-Object {$_.Name});dependents=@($s.DependentServices | Where-Object {$_.Status -eq 'Running'} | ForEach-Object {$_.Name})}
}
function Set-CompatServiceMode([string]$name,[int]$mode) {
  if ($mode -notin @(2,3)) { throw 'Only backed-up automatic/manual modes are supported' }
  Set-Service -Name $name -StartupType $(if($mode -eq 2){'Automatic'}else{'Manual'}) -ErrorAction Stop
}
function Start-CompatService([string]$name) { Start-Service -Name $name -ErrorAction Stop }
function Get-CompatBaselines($cfg) {
  $all=@{}
  if (-not $cfg.backupDir -or -not [IO.Path]::IsPathRooted([string]$cfg.backupDir)) { return $all }
  $files=@()
  foreach ($id in @($cfg.ids)) {
    if ([string]$id -notmatch '^[a-zA-Z0-9_-]+$') { continue }
    $file=Join-Path $cfg.backupDir ($id+'.json')
    if (Test-Path -LiteralPath $file -PathType Leaf) { $files += @{id=[string]$id;file=$file;at=(Get-Item -LiteralPath $file).CreationTimeUtc} }
  }
  foreach ($f in @($files | Sort-Object at)) {
    try { $records=Get-Content -LiteralPath $f.file -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop } catch { continue }
    foreach ($r in $records) {
      if ($r.t -ne 'reg' -or $r.n -ine 'Start' -or $r.k -notmatch '^HKLM\\SYSTEM\\CurrentControlSet\\Services\\([^\\]+)$' -or -not $r.prior.exists -or $r.prior.kind -ine 'DWord') { continue }
      $name=$Matches[1];$key=$name.ToLowerInvariant()
      if (-not $all.ContainsKey($key)) { $all[$key]=@{name=$name;mode=[int]$r.prior.value;ids=@($f.id);key=[string]$r.k;source='tweak-backup'} }
      elseif ($all[$key].ids -notcontains $f.id) { $all[$key].ids += $f.id }
    }
  }
  foreach($entry in @($cfg.startupOff)){
    if($entry.type -ne 'service' -or -not $entry.name -or -not $entry.exe){continue}
    $name=[string]$entry.name;$key=$name.ToLowerInvariant()
    if($all.ContainsKey($key)){continue}
    $regKey='HKLM\SYSTEM\CurrentControlSet\Services\'+$name
    try{$marker=Get-RegState $regKey 'DemsetStartupOff'}catch{continue}
    if(-not $marker.exists -or [int]$marker.value -ne 1){continue}
    # Legacy startup UI enumerated only Automatic third-party services before
    # changing them to Manual and writing this marker. New entries carry originalStart.
    $mode=if($entry.originalStart -in @(2,3)){[int]$entry.originalStart}else{2}
    $all[$key]=@{name=$name;mode=$mode;ids=@('startup-service:'+ $name);key=$regKey;source='startup-service';exe=[string]$entry.exe}
  }
  # Preview is read-only evidence used before a first apply. It is never accepted
  # as a recovery baseline: restore actions still require a real Demset record.
  if($cfg.action -eq 'audit'){
    foreach($preview in @($cfg.previewServices)){
      $name=[string]$preview.name
      if($name -notmatch '^[A-Za-z0-9_. -]+$'){continue}
      $key=$name.ToLowerInvariant();if($all.ContainsKey($key)){continue}
      try{$state=Get-CompatService $name}catch{continue}
      if($state.mode -notin @(2,3)){continue}
      $all[$key]=@{name=$name;mode=[int]$state.mode;ids=@([string]$preview.id);key=('HKLM\SYSTEM\CurrentControlSet\Services\'+$name);source='preview'}
    }
  }
  return $all
}
function Get-CompatKnownApps($known,[string]$service) {
  if ($known -is [Collections.IDictionary]) { return @($known[$service]) }
  if ($known) { $p=$known.PSObject.Properties[$service]; if($p){return @($p.Value)} }; return @()
}
function Get-CompatPlan($cfg,$inventory,$runtime,$baselines) {
  $apps=@($runtime)+@($inventory.startup)
  $required=@{};$states=@{};$manual=@()
  foreach ($key in $baselines.Keys) {
    $b=$baselines[$key];$sv=@($inventory.services | Where-Object {$_.name -ieq $b.name}) | Select-Object -First 1
    if (-not $sv) { continue }
    try {$state=Get-CompatService $b.name;$states[$key]=$state} catch {continue}
    $reasons=@();$hits=@();$live=$false
    $baseName=$b.name -replace '_[a-fA-F0-9]+$',''
    $known=@(Get-CompatKnownApps $cfg.knownNeeds $baseName)
    $root=Get-CompatAppRoot $sv.path $inventory.installs
    foreach($app in $apps){
      if (-not $app.path) {continue}
      if ($app.path -ieq $sv.path) {continue} # The service itself is not evidence of a dependent app.
      $reason=$null
      if ($known -contains [IO.Path]::GetFileName($app.path)) {$reason='known-app'}
      elseif ($root -and (Test-CompatWithin $app.path $root)) {$reason='same-installation'}
      if ($reason) {$hits += [IO.Path]::GetFileName($app.path);$reasons += ($reason+':'+$app.source);if($app.source -eq 'running'){$live=$true}}
    }
    if ($state.dependents.Count) {$reasons+='native-running-dependent';$hits+=@($state.dependents);$live=$true}
    if (@($cfg.persistent) -icontains $b.name) {$reasons+='persistent-app-exclusion'}
    if (-not $reasons.Count) {continue}
    if ($b.mode -notin @(2,3)) {$manual+=@{name=$b.name;reason='Original service mode was not Automatic or Manual; not enabled automatically';ids=$b.ids};continue}
    $required[$key]=@{name=$b.name;mode=$b.mode;running=$state.running;apps=@($hits|Select-Object -Unique);reasons=@($reasons|Select-Object -Unique);ids=$b.ids;source=$b.source;start=$live;depth=0}
  }
  # Add only backed-up prerequisites. Never rewrite a service modified by another program.
  $queue=New-Object Collections.Queue
  foreach($key in @($required.Keys)){$queue.Enqueue($key)}
  while($queue.Count){
    $key=[string]$queue.Dequeue();$item=$required[$key]
    if(-not $states.ContainsKey($key)){try{$states[$key]=Get-CompatService $item.name}catch{continue}}
    foreach($dep in @($states[$key].required)){
      $dk=([string]$dep).ToLowerInvariant()
      if(-not $baselines.ContainsKey($dk) -or $baselines[$dk].mode -notin @(2,3)){continue}
      if($required.ContainsKey($dk)){$required[$dk].start=$required[$dk].start -or $item.start;continue}
      $b=$baselines[$dk];try{$states[$dk]=Get-CompatService $b.name}catch{continue}
      $required[$dk]=@{name=$b.name;mode=$b.mode;running=$states[$dk].running;apps=@($item.apps);reasons=@('native-prerequisite:'+ $item.name);ids=$b.ids;source=$b.source;start=$item.start;depth=($item.depth+1)}
      $queue.Enqueue($dk)
    }
  }
  return @{required=@($required.Values | Sort-Object depth -Descending);manual=$manual;states=$states}
}
function Test-CompatAuthenticPair([string]$helper,[string]$app){
  try{
    $a=Get-AuthenticodeSignature -LiteralPath $helper -ErrorAction Stop;$b=Get-AuthenticodeSignature -LiteralPath $app -ErrorAction Stop
    return ($a.Status -eq 'Valid' -and $b.Status -eq 'Valid' -and $a.SignerCertificate.Thumbprint -eq $b.SignerCertificate.Thumbprint)
  }catch{return $false}
}
function Start-CompatHelper([string]$path){Start-AsUser $path '' | Out-Null}
function Get-CompatHelperPeer([string]$path,$runtime){
  # Standalone no-argument agent, with a known front end. Chromium renderers,
  # launchers and helper processes requiring IPC tokens are never replayed.
  $known=@{'lghub_agent.exe'=@('lghub.exe')}
  $leaf=[IO.Path]::GetFileName($path).ToLowerInvariant()
  if(-not $known.ContainsKey($leaf)){return $null}
  $dir=Split-Path -Parent $path
  return @($runtime|Where-Object{[IO.Path]::GetFileName($_.path) -iin $known[$leaf] -and (Split-Path -Parent $_.path) -ieq $dir})|Select-Object -First 1
}
function Invoke-AppCompatibility($cfg) {
  $out=@{ok=$true;at=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds();required=@();restored=@();failed=@();helpers=@();manual=@();limited=$true}
  try {
    if ($cfg.action -notin @('audit','restore')) {throw 'Unknown app compatibility action'}
    $baselines=Get-CompatBaselines $cfg
    if (-not $baselines.Count -and -not @($cfg.killed).Count) {Emit 'appcompat' ($out|ConvertTo-Json -Depth 10 -Compress);return}
    $inventory=Get-CompatInventory;$runtime=@(Get-CompatRuntime)
    $plan=Get-CompatPlan $cfg $inventory $runtime $baselines
    $out.required=@($plan.required);$out.manual=@($plan.manual)
    if($cfg.action -eq 'restore'){
      foreach($item in $plan.required){
        try{
          $before=Get-CompatService $item.name;$changed=$false
          if($before.mode -ne $item.mode){Set-CompatServiceMode $item.name $item.mode;$changed=$true}
          $now=Get-CompatService $item.name
          if($now.mode -ne $item.mode){throw 'SCM startup-mode verification failed'}
          if($item.start -and -not $now.running){Start-CompatService $item.name;$now=Get-CompatService $item.name;if(-not $now.running){throw 'SCM did not report Running'};$changed=$true}
          $item.running=[bool]$now.running
          if($item.source -eq 'startup-service'){Remove-RegValueDirect ('HKLM\SYSTEM\CurrentControlSet\Services\'+$item.name) 'DemsetStartupOff'}
          if($changed){$out.restored+=@{name=$item.name;mode=$now.mode;running=$now.running;apps=$item.apps;ids=$item.ids;source=$item.source}}
        }catch{$out.failed+=@{name=$item.name;error=$_.Exception.Message}}
      }
    }
    # Arbitrary command-line replays (e.g. --type=renderer) cannot safely reconstruct
    # helpers. Report saved paths for manual recovery unless a native service did it.
    foreach($entry in @($cfg.killed)){
      if(-not $entry.path -or $entry.restored){continue}
      $root=Get-CompatAppRoot ([string]$entry.path) $inventory.installs
      $live=@($runtime|Where-Object {$_.path -ine $entry.path -and $root -and (Test-CompatWithin $_.path $root)})
      if(-not $live.Count){continue}
      $already=@($runtime|Where-Object {$_.path -ieq $entry.path})
      if($already.Count){$out.helpers+=@{id=$entry.id;path=$entry.path;ok=$true;alreadyRunning=$true};continue}
      $peer=Get-CompatHelperPeer ([string]$entry.path) $runtime
      if($cfg.action -eq 'restore' -and $peer -and (Test-Path -LiteralPath $entry.path -PathType Leaf) -and (Test-CompatAuthenticPair $entry.path $peer.path)){
        if(-not $script:compatHelperAttempts){$script:compatHelperAttempts=@{}}
        $helperKey=([string]$entry.path).ToLowerInvariant()
        if($script:compatHelperAttempts.ContainsKey($helperKey) -and ([DateTime]::UtcNow-$script:compatHelperAttempts[$helperKey]).TotalSeconds -lt 60){continue}
        $script:compatHelperAttempts[$helperKey]=[DateTime]::UtcNow
        try{Start-CompatHelper $entry.path;Start-Sleep -Milliseconds 500;$verified=@(Get-CompatRuntime|Where-Object{$_.path -ieq $entry.path});if(-not $verified.Count){throw 'Helper process did not appear at its recorded path'};$out.helpers+=@{id=$entry.id;path=$entry.path;ok=$true;verified=$true}}
        catch{$out.failed+=@{id=$entry.id;path=$entry.path;error=$_.Exception.Message}}
      }else{$out.manual+=@{id=$entry.id;path=$entry.path;reason='Related application is running, but this helper needs explicit recovery or does not have a verified no-argument launch relationship. Saved arbitrary command lines are never run automatically.'}}
    }
    $out.ok=($out.failed.Count -eq 0)
  }catch{$out.ok=$false;$out.error=$_.Exception.Message}
  Emit 'appcompat' ($out|ConvertTo-Json -Depth 10 -Compress)
}
function Invoke-AppCompatibilityWatch([string]$policyFile) {
  while($true){
    try{
      $cfg=Get-Content -LiteralPath $policyFile -Raw -Encoding UTF8 -ErrorAction Stop|ConvertFrom-Json -ErrorAction Stop
      if($cfg.enabled -eq $false){return}
      if($cfg.parentPid){$parentProcess=Get-Process -Id ([int]$cfg.parentPid) -ErrorAction SilentlyContinue;if(-not $parentProcess){return};if($cfg.parentStartTicks -and $parentProcess.StartTime.ToUniversalTime().Ticks -ne [int64]$cfg.parentStartTicks){return}}
      Invoke-AppCompatibility $cfg
    }catch{Emit 'appcompat' (@{ok=$false;error=$_.Exception.Message;at=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()}|ConvertTo-Json -Compress)}
    Start-Sleep -Seconds 10
  }
}
