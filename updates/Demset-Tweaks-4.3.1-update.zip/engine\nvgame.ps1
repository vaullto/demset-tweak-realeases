﻿# Per-executable NVIDIA power policy. No global settings or clocks are changed.
# Layouts and interface IDs: https://github.com/NVIDIA/nvapi (nvapi.h,
# nvapi_interface.h, nvapi_lite_common.h, NvApiDriverSettings.h).
# Only PREFERRED_PSTATE_ID=0x1057EB71, PREFER_MAX=1 is writable here.
if (-not ('DemsetNvGame' -as [type])) {
  Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Text;
public sealed class DemsetNvGameState {
  public bool profileExists, predefinedProfile, globalProfile, settingExists, explicitSetting, currentPredefined;
  public string profileName = "", applicationName = "";
  public uint appCount, settingCount, value;
  public int type = -1, location = -1;
}
public static class DemsetNvGame {
  const uint PowerId = 0x1057EB71;
  const int AppSize = 12296, ProfileSize = 4116, SettingSize = 12320;
  [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
  [DllImport("nvapi64.dll", EntryPoint="nvapi_QueryInterface", CallingConvention=CallingConvention.Cdecl)]
  static extern IntPtr Query(uint id);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int F0();
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FOut(out IntPtr handle);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FH(IntPtr handle);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FHOut(IntPtr session, out IntPtr handle);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FFindApp(IntPtr session, IntPtr name, out IntPtr profile, IntPtr application);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FFindProfile(IntPtr session, IntPtr name, out IntPtr profile);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FCreateProfile(IntPtr session, IntPtr info, out IntPtr profile);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FProfile(IntPtr session, IntPtr profile);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FBuffer(IntPtr session, IntPtr profile, IntPtr buffer);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FGetSetting(IntPtr session, IntPtr profile, uint id, IntPtr buffer);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FDeleteSetting(IntPtr session, IntPtr profile, uint id);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FDeleteApp(IntPtr session, IntPtr profile, IntPtr name);
  static T Fn<T>(uint id) where T:class { IntPtr p=Query(id); if(p==IntPtr.Zero)throw new Exception("NVAPI interface unavailable: 0x"+id.ToString("X8")); return Marshal.GetDelegateForFunctionPointer(p,typeof(T)) as T; }
  static void Check(int code,string op) { if(code!=0)throw new Exception(op+"="+code); }
  static IntPtr Buffer(int size) { IntPtr p=Marshal.AllocHGlobal(size); for(int i=0;i<size;i++)Marshal.WriteByte(p,i,0); return p; }
  static IntPtr Versioned(int size) { IntPtr p=Buffer(size); Marshal.WriteInt32(p,size|(1<<16)); return p; }
  static void Text(IntPtr p,int offset,string value) { if(value==null || value.Length>=2048 || value.IndexOf('\0')>=0)throw new Exception("Invalid NVAPI Unicode string"); byte[] bytes=Encoding.Unicode.GetBytes(value+"\0"); Marshal.Copy(bytes,0,IntPtr.Add(p,offset),bytes.Length); }
  static IntPtr Unicode(string value) { IntPtr p=Buffer(4096); try {Text(p,0,value);return p;}catch{Marshal.FreeHGlobal(p);throw;} }
  static IntPtr Open() {
    Check(Fn<F0>(0x0150E828)(),"Initialize"); IntPtr s; Check(Fn<FOut>(0x0694D52E)(out s),"CreateSession");
    try {Check(Fn<FH>(0x375DBD6B)(s),"LoadSettings");return s;} catch {Close(s);throw;}
  }
  static void Close(IntPtr s) {try{Fn<FH>(0xDAD9CFF8)(s);}catch{}}
  static IntPtr ProfileByName(IntPtr s,string name) { IntPtr p, n=Unicode(name); try {int r=Fn<FFindProfile>(0x7E4A9A0B)(s,n,out p);if(r==-163)return IntPtr.Zero;Check(r,"FindProfileByName");return p;}finally{Marshal.FreeHGlobal(n);} }
  static void ProfileInfo(IntPtr s,IntPtr p,DemsetNvGameState state) {
    IntPtr b=Versioned(ProfileSize);
    try {Check(Fn<FBuffer>(0x61CD6FD6)(s,p,b),"GetProfileInfo");state.profileExists=true;state.profileName=Marshal.PtrToStringUni(IntPtr.Add(b,4))??"";state.predefinedProfile=Marshal.ReadInt32(b,4104)!=0;state.appCount=(uint)Marshal.ReadInt32(b,4108);state.settingCount=(uint)Marshal.ReadInt32(b,4112);IntPtr baseProfile;Check(Fn<FHOut>(0xDA8466A0)(s,out baseProfile),"GetBaseProfile");state.globalProfile=p==baseProfile || p.ToInt64()==-1;}
    finally {Marshal.FreeHGlobal(b);}
  }
  static void SettingInfo(IntPtr s,IntPtr p,DemsetNvGameState state) {
    IntPtr b=Versioned(SettingSize);
    try {int r=Fn<FGetSetting>(0x73BF8338)(s,p,PowerId,b);if(r==-160)return;Check(r,"GetSetting");state.settingExists=true;state.type=Marshal.ReadInt32(b,4104);state.location=Marshal.ReadInt32(b,4108);state.currentPredefined=Marshal.ReadInt32(b,4112)!=0;state.explicitSetting=state.location==0 && !state.currentPredefined;state.value=(uint)Marshal.ReadInt32(b,8220);}
    finally {Marshal.FreeHGlobal(b);}
  }
  static DemsetNvGameState Read(IntPtr s,string exe,out IntPtr profile) {
    var state=new DemsetNvGameState(); IntPtr name=Unicode(exe), b=Versioned(AppSize);profile=IntPtr.Zero;
    try {int r=Fn<FFindApp>(0xEEE566B2)(s,name,out profile,b);if(r==-166){profile=IntPtr.Zero;return state;}Check(r,"FindApplicationByName");state.applicationName=Marshal.PtrToStringUni(IntPtr.Add(b,8))??"";ProfileInfo(s,profile,state);SettingInfo(s,profile,state);return state;}
    finally {Marshal.FreeHGlobal(name);Marshal.FreeHGlobal(b);}
  }
  public static DemsetNvGameState Read(string exe) {IntPtr s=Open();try{IntPtr p;return Read(s,exe,out p);}finally{Close(s);} }
  static void Scope(DemsetNvGameState state) {if(state.globalProfile)throw new Exception("Global NVIDIA profiles are not writable");if(state.profileExists && state.appCount!=1)throw new Exception("Shared NVIDIA profile: other applications would be affected");if(state.settingExists && state.type!=0)throw new Exception("NVIDIA power policy is not a DWORD");}
  static void SetPower(IntPtr s,IntPtr p,uint value) {IntPtr b=Versioned(SettingSize);try{Marshal.WriteInt32(b,4100,(int)PowerId);Marshal.WriteInt32(b,4104,0);Marshal.WriteInt32(b,8220,unchecked((int)value));Check(Fn<FBuffer>(0x577DD202)(s,p,b),"SetSetting");}finally{Marshal.FreeHGlobal(b);} }
  static void DeletePower(IntPtr s,IntPtr p) {int r=Fn<FDeleteSetting>(0xE4A26362)(s,p,PowerId);if(r!=-160)Check(r,"DeleteProfileSetting");}
  static bool Baseline(DemsetNvGameState state,bool oldExplicit,uint oldValue,bool oldPredefined) {return state.explicitSetting==oldExplicit && (!oldExplicit || state.value==oldValue) && (oldExplicit || !oldPredefined || state.currentPredefined);}
  public static void Apply(string exe,string profileName,bool existed,bool oldExplicit,uint oldValue,bool oldPredefined) {
    IntPtr s=Open();
    try {
      IntPtr p;var current=Read(s,exe,out p);Scope(current);
      if(current.profileExists!=existed || (existed && !String.Equals(current.profileName,profileName,StringComparison.Ordinal)) || (existed && !Baseline(current,oldExplicit,oldValue,oldPredefined)))throw new Exception("NVIDIA profile changed after backup; no changes saved");
      if(!existed) {
        if(ProfileByName(s,profileName)!=IntPtr.Zero)throw new Exception("Reserved Demset profile already exists; use recovery first");
        IntPtr profile=Versioned(ProfileSize),app=Versioned(AppSize);
        try {Text(profile,4,profileName);Check(Fn<FCreateProfile>(0xCC176068)(s,profile,out p),"CreateProfile");Text(app,8,exe);Text(app,4104,System.IO.Path.GetFileNameWithoutExtension(exe));Check(Fn<FBuffer>(0x4347A9DE)(s,p,app),"CreateApplication");}
        finally{Marshal.FreeHGlobal(profile);Marshal.FreeHGlobal(app);}
      }
      SetPower(s,p,1);Check(Fn<FH>(0xFCBC7E14)(s),"SaveSettings");
    }finally{Close(s);}
  }
  public static void Revert(string exe,string profileName,bool created,bool oldExplicit,uint oldValue,bool oldPredefined) {
    IntPtr s=Open();
    try {
      IntPtr associated;var current=Read(s,exe,out associated);
      if(current.profileExists && !String.Equals(current.profileName,profileName,StringComparison.Ordinal))throw new Exception("Application association changed externally; backup retained");
      IntPtr p=ProfileByName(s,profileName);
      if(p==IntPtr.Zero){if(created)return;throw new Exception("Original NVIDIA profile is missing; backup retained");}
      var info=new DemsetNvGameState();ProfileInfo(s,p,info);SettingInfo(s,p,info);
      if(info.globalProfile)throw new Exception("Refusing to restore a global profile");
      if(!created) {
        Scope(info);
        if(!Baseline(info,oldExplicit,oldValue,oldPredefined) && !(info.explicitSetting && info.type==0 && info.value==1))throw new Exception("Power policy changed externally; backup retained");
        if(oldExplicit)SetPower(s,p,oldValue);else if(oldPredefined){int r=Fn<FDeleteSetting>(0x53F0381E)(s,p,PowerId);if(r!=-160)Check(r,"RestoreProfileDefaultSetting");}else DeletePower(s,p);
      } else {
        if(info.predefinedProfile || !profileName.StartsWith("Demset GPU ",StringComparison.Ordinal))throw new Exception("Owned profile identity changed; backup retained");
        // Never clear other applications/settings added after our transaction.
        if(info.appCount==0 || (current.profileExists && info.appCount==1)) {
          if(info.explicitSetting && (info.type!=0 || info.value!=1))throw new Exception("Owned power policy changed externally; backup retained");
          if(info.explicitSetting)DeletePower(s,p);
        }
        if(current.profileExists) {
          IntPtr appName=Unicode(current.applicationName);
          try {Check(Fn<FDeleteApp>(0x2C694BC6)(s,p,appName),"DeleteApplication");}finally{Marshal.FreeHGlobal(appName);}
        }
        var remaining=new DemsetNvGameState();ProfileInfo(s,p,remaining);
        if(remaining.appCount==0 && remaining.settingCount==0)Check(Fn<FProfile>(0x17093206)(s,p),"DeleteProfile");
      }
      Check(Fn<FH>(0xFCBC7E14)(s),"SaveSettings");
    }finally{Close(s);}
  }
}
'@
}

function Get-NvGameNative([string]$exe) { return [DemsetNvGame]::Read($exe) }
function Set-NvGameNative([string]$exe,$b) { [DemsetNvGame]::Apply($exe,$b.profileName,[bool]$b.original.profileExists,[bool]$b.original.explicitSetting,[uint32]$b.original.value,[bool]$b.original.currentPredefined) }
function Restore-NvGameNative([string]$exe,$b) { [DemsetNvGame]::Revert($exe,$b.profileName,[bool]$b.createdProfile,[bool]$b.original.explicitSetting,[uint32]$b.original.value,[bool]$b.original.currentPredefined) }
function Get-NvGameBackupFile([string]$dir,[string]$exe) {
  $hash=[Security.Cryptography.SHA256]::Create()
  try {$name='nvgame-'+([BitConverter]::ToString($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($exe.ToLowerInvariant()))).Replace('-','').Substring(0,24))+'.json';return Join-Path $dir $name}finally{$hash.Dispose()}
}
function Save-NvGameBackup([string]$file,$value) {
  [void][IO.Directory]::CreateDirectory((Split-Path -Parent $file));$tmp=$file+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
  try {
    $bytes=(New-Object Text.UTF8Encoding($false)).GetBytes((ConvertTo-Json -InputObject $value -Depth 12))
    $stream=New-Object IO.FileStream($tmp,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None,4096,[IO.FileOptions]::WriteThrough)
    try{$stream.Write($bytes,0,$bytes.Length);$stream.Flush($true)}finally{$stream.Dispose()}
    if(Test-Path -LiteralPath $file){[IO.File]::Replace($tmp,$file,[NullString]::Value)}else{[IO.File]::Move($tmp,$file)}
  }finally{if(Test-Path -LiteralPath $tmp){Remove-Item -LiteralPath $tmp -Force}}
}
function Read-NvGameBackup([string]$file,[string]$exe) {
  if(-not(Test-Path -LiteralPath $file)){return $null}
  $b=Get-Content -LiteralPath $file -Raw -Encoding UTF8 -ErrorAction Stop|ConvertFrom-Json -ErrorAction Stop
  if($b.schema -ne 1 -or $b.exe -ine $exe -or $b.settingId -ne 0x1057EB71 -or $b.wanted -ne 1 -or $b.active -isnot [bool] -or $b.createdProfile -isnot [bool] -or $null -eq $b.original -or $b.original.profileExists -isnot [bool] -or $b.original.explicitSetting -isnot [bool] -or $b.original.currentPredefined -isnot [bool] -or -not $b.profileName){throw 'Invalid NVIDIA game backup; no settings changed'}
  if($b.createdProfile){$expected='Demset GPU '+([IO.Path]::GetFileNameWithoutExtension($file)-replace '^nvgame-','');if($b.profileName -cne $expected -or $b.original.profileExists){throw 'Owned NVIDIA profile does not match backup identity'}}
  elseif(-not $b.original.profileExists -or $b.profileName -cne $b.original.profileName -or $b.original.type -notin @(-1,0)){throw 'Original NVIDIA profile snapshot is invalid'}
  return $b
}
function Get-NvGameScopeReason($state) {
  if($state.globalProfile){return 'لا نعدّل ملف NVIDIA العام من بوست لعبة واحدة.'}
  if($state.profileExists -and $state.appCount -ne 1){return 'ملف NVIDIA مشترك بين عدة تطبيقات؛ تركناه كما هو حتى لا يؤثر البوست على الألعاب الأخرى.'}
  if($state.settingExists -and $state.type -ne 0){return 'تعريف NVIDIA لا يعرض إعداد الطاقة بنوع DWORD المدعوم.'}
  return ''
}
function Get-NvGameResult($state,$backup,[bool]$changed=$false) {
  $reason=Get-NvGameScopeReason $state
  $active=[bool]($backup -and $backup.active)
  $matches=[bool]($state.profileExists -and $state.settingExists -and $state.type -eq 0 -and $state.value -eq 1)
  return @{ok=$true;supported=(-not[bool]$reason);reason=$reason;applied=($active -and $matches -and $state.explicitSetting -and $state.profileName -ceq $backup.profileName);matches=$matches;backup=$active;changed=$changed;profile=$state.profileName;current=$state;setting='PREFERRED_PSTATE';settingId=0x1057EB71;wanted=1}
}
function Invoke-NvGameProfilesRead($cfg) {
  $results=@{}
  try {
    $executables=@($cfg.executables)
    if($executables.Count -gt 100){throw 'NVIDIA read batch is limited to 100 executables'}
    if(-not$cfg.backupDir -or -not[IO.Path]::IsPathRooted([string]$cfg.backupDir)){throw 'Absolute NVIDIA backup directory required'}
    $dir=[IO.Path]::GetFullPath([string]$cfg.backupDir)
    foreach($candidate in $executables){
      if($null -eq $candidate){continue}
      $key=[string]$candidate;$b=$null
      try {
        if(-not[IO.Path]::IsPathRooted($key)){throw 'Absolute game executable required'}
        $exe=[IO.Path]::GetFullPath($key)
        if([IO.Path]::GetExtension($exe) -ine '.exe' -or $exe.Length -ge 2048){throw 'Invalid game executable'}
        # No directories, profiles or baseline files are created during a scan.
        $b=Read-NvGameBackup (Get-NvGameBackupFile $dir $exe) $exe
        $state=Get-NvGameNative $exe
        $item=Get-NvGameResult $state $b
        $item.matchesEffective=$item.matches
        $results[$key]=$item
      } catch {
        $results[$key]=@{ok=$false;supported=$false;matches=$false;matchesEffective=$false;applied=$false;backup=[bool]($b -and $b.active);reason='تعذّرت قراءة إعداد NVIDIA لهذه اللعبة؛ لم نغيّر أي إعداد.';error=$_.Exception.Message}
      }
    }
  } catch {$results=@{ok=$false;error=$_.Exception.Message}}
  Emit 'nvgames' (ConvertTo-Json -InputObject $results -Depth 12 -Compress)
}
function Invoke-NvGameProfile($cfg) {
  $file=$null;$b=$null
  try {
    if($cfg.action -notin @('get','apply','revert')){throw 'Unknown NVIDIA game action'}
    if(-not $cfg.exe -or -not[IO.Path]::IsPathRooted([string]$cfg.exe) -or -not $cfg.backupDir -or -not[IO.Path]::IsPathRooted([string]$cfg.backupDir)){throw 'Absolute game and backup paths required'}
    $exe=[IO.Path]::GetFullPath([string]$cfg.exe)
    if([IO.Path]::GetExtension($exe) -ine '.exe' -or $exe.Length -ge 2048){throw 'Invalid game executable'}
    if($cfg.action -eq 'apply' -and -not(Test-Path -LiteralPath $exe -PathType Leaf)){throw 'Game executable not found'}
    $file=Get-NvGameBackupFile ([IO.Path]::GetFullPath([string]$cfg.backupDir)) $exe
    $b=Read-NvGameBackup $file $exe
    $state=Get-NvGameNative $exe
    if($cfg.action -eq 'get'){$result=Get-NvGameResult $state $b}
    elseif($cfg.action -eq 'apply') {
      $reason=Get-NvGameScopeReason $state
      if($reason){$result=Get-NvGameResult $state $b;$result.ok=$false;$result.error=$reason}
      elseif($state.settingExists -and $state.type -eq 0 -and $state.value -eq 1){$result=Get-NvGameResult $state $b}
      else {
        if($b -and $b.active){throw 'NVIDIA game profile changed after applying; restore the saved baseline first'}
        $profileName=if($state.profileExists){$state.profileName}else{'Demset GPU '+([IO.Path]::GetFileNameWithoutExtension($file)-replace '^nvgame-','')}
        $b=@{schema=1;exe=$exe;settingId=0x1057EB71;wanted=1;profileName=$profileName;createdProfile=(-not$state.profileExists);original=$state;active=$true;phase='prepared';at=[DateTime]::UtcNow.ToString('o')}
        Save-NvGameBackup $file $b
        Set-NvGameNative $exe $b
        $after=Get-NvGameNative $exe
        if(-not$after.profileExists -or $after.profileName -cne $profileName -or -not$after.explicitSetting -or $after.type -ne 0 -or $after.value -ne 1){throw 'NVIDIA game readback did not match the requested DWORD setting; backup retained'}
        $b.phase='applied';Save-NvGameBackup $file $b
        $result=Get-NvGameResult $after $b $true
      }
    } else {
      if(-not$b -or -not$b.active){$result=Get-NvGameResult $state $b}
      else {
        Restore-NvGameNative $exe $b
        $after=Get-NvGameNative $exe
        if($b.createdProfile){if($after.profileExists -and $after.profileName -ceq $b.profileName){throw 'Owned NVIDIA application association was not removed; backup retained'}}
        elseif(-not$after.profileExists -or $after.profileName -cne $b.profileName -or $after.explicitSetting -ne $b.original.explicitSetting -or ($b.original.explicitSetting -and $after.value -ne $b.original.value) -or (-not$b.original.explicitSetting -and $b.original.currentPredefined -and -not$after.currentPredefined)){throw 'NVIDIA game restoration readback differs from original profile; backup retained'}
        $b.active=$false;$b.phase='restored';Save-NvGameBackup $file $b
        $result=Get-NvGameResult $after $b $true
      }
    }
  } catch {$result=@{ok=$false;supported=$false;applied=$false;backup=[bool]($b -and $b.active);error=$_.Exception.Message}}
  Emit 'nvgame' (ConvertTo-Json -InputObject $result -Depth 12 -Compress)
}
