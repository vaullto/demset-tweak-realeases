﻿# سكربت تركيب التحديث — ينشحن داخل ملف التحديث نفسه، فأي إصلاح له يوصل مع التحديث.
# يطلع نافذة صغيرة فيها شريط تقدّم (0 ← 100٪)، يبدّل الملفات مع نسخة احتياطية، يتأكد إنها انكتبت صح، ويشغّل البرنامج.
param([string]$res, [string]$exe, [string]$tmp, [string]$log, [int]$mainPid, [switch]$TestMode)
$ErrorActionPreference = 'Stop'
function Resolve-UpdaterDirectory([string]$path) {
  if (-not $path -or -not [IO.Path]::IsPathRooted($path)) { throw 'Updater requires an absolute directory' }
  $full = [IO.Path]::GetFullPath($path).TrimEnd('\')
  if (-not $full -or $full -eq [IO.Path]::GetPathRoot($full).TrimEnd('\')) { throw 'Updater cannot target a drive root' }
  return $full
}
function Assert-UpdaterChild([string]$path,[string]$parent) {
  $base = Resolve-UpdaterDirectory $parent
  $full = [IO.Path]::GetFullPath($path).TrimEnd('\')
  if (-not $full.StartsWith($base + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Updater path escapes its intended directory' }
  $probe = $full
  while ($probe) {
    if (Test-Path -LiteralPath $probe) {
      $node = Get-Item -LiteralPath $probe -Force
      if ($node.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Updater will not follow a junction or redirected path' }
    }
    $parentProbe = Split-Path -Parent $probe
    if (-not $parentProbe -or $parentProbe -eq $probe) { break }
    $probe = $parentProbe
  }
  return $full
}
function Test-UpdaterProcess($proc,[string]$installRoot,[string]$resourceDir) {
  $rootPath = (Resolve-UpdaterDirectory $installRoot) + '\'
  if ($proc.ExecutablePath) {
    try { if ([IO.Path]::GetFullPath($proc.ExecutablePath).StartsWith($rootPath,[StringComparison]::OrdinalIgnoreCase)) { return $true } } catch {}
  }
  return ($proc.CommandLine -and $proc.CommandLine -match ([regex]::Escape($resourceDir.TrimEnd('\')) + '(?:\\|"|''|\s|$)'))
}
function Copy-UpdaterPayload([string]$source,[string]$destination) {
  Retry $destination { Copy-Item -LiteralPath $source -Destination $destination -Force; if (-not (Same $source $destination)) { throw 'Copied payload hash mismatch' } }
}
function Invoke-UpdaterTransaction([string]$resourceDir,[string]$payloadDir) {
  $resourceDir = Resolve-UpdaterDirectory $resourceDir
  if ((Split-Path -Leaf $resourceDir) -ine 'resources') { throw 'Expected the application resources directory' }
  $installRoot = Resolve-UpdaterDirectory (Split-Path -Parent $resourceDir)
  [void](Assert-UpdaterChild $resourceDir $installRoot)
  $payloadDir = Resolve-UpdaterDirectory $payloadDir
  if ((Split-Path -Leaf $payloadDir) -ine 'x') { throw 'Expected the extracted update directory named x' }
  $payloadParent = Resolve-UpdaterDirectory (Split-Path -Parent $payloadDir)
  [void](Assert-UpdaterChild $payloadDir $payloadParent)
  if ($payloadDir.StartsWith($installRoot + '\',[StringComparison]::OrdinalIgnoreCase) -or $installRoot.StartsWith($payloadDir + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Update payload and installation directories must not overlap' }
  $asarNew = Assert-UpdaterChild (Join-Path $payloadDir 'app.asar') $payloadDir
  $engineNew = Assert-UpdaterChild (Join-Path $payloadDir 'engine') $payloadDir
  $asarDst = Assert-UpdaterChild (Join-Path $resourceDir 'app.asar') $resourceDir
  $engineDst = Assert-UpdaterChild (Join-Path $resourceDir 'engine') $resourceDir
  $appDir = Assert-UpdaterChild (Join-Path $resourceDir 'app') $resourceDir
  $bak = Assert-UpdaterChild (Join-Path $resourceDir '_update_backup') $resourceDir
  $oldApp = Assert-UpdaterChild (Join-Path $resourceDir ('_old_app_' + [guid]::NewGuid().ToString('N'))) $resourceDir
  $hadAsar = Test-Path -LiteralPath $asarDst -PathType Leaf
  $hadEngine = Test-Path -LiteralPath $engineDst -PathType Container
  $hadApp = Test-Path -LiteralPath $appDir -PathType Container
  $backedUp = $false
  try {
    if (-not (Test-Path -LiteralPath $asarNew -PathType Leaf) -or (Get-Item -LiteralPath $asarNew).Length -eq 0) { throw 'Update app.asar is missing or empty' }
    foreach ($name in @('appcompat.ps1','nvgame.ps1','vpn-gate.ps1','uninstall-backup.ps1','registry.ps1','oneclick.ps1','engine.ps1','system.ps1','repair.ps1','tools.ps1','doctor.ps1','purity.ps1','gpuoc.ps1','diskscan.cs')) {
      $file = Assert-UpdaterChild (Join-Path $engineNew $name) $engineNew
      if (-not (Test-Path -LiteralPath $file -PathType Leaf) -or (Get-Item -LiteralPath $file).Length -eq 0) { throw ('Update engine is incomplete: ' + $name) }
    }
    P 25 'ياخذ نسخة احتياطية…'
    # Resolve and contain every recursive operation before invoking it.
    [void](Assert-UpdaterChild $bak $resourceDir)
    if (Test-Path -LiteralPath $bak) { Remove-Item -LiteralPath $bak -Recurse -Force }
    [void](New-Item -ItemType Directory -Path $bak -Force)
    if ($hadAsar) { Copy-Item -LiteralPath $asarDst -Destination (Join-Path $bak 'app.asar') -Force }
    if ($hadEngine) { Copy-Item -LiteralPath $engineDst -Destination (Join-Path $bak 'engine') -Recurse -Force }
    if ($hadApp) { Copy-Item -LiteralPath $appDir -Destination (Join-Path $bak 'app') -Recurse -Force }
    $backedUp = $true
    L 'backup complete, including legacy resources/app'
    if ($hadApp) {
      P 35 'يجهّز ملفات النسخة القديمة…'
      [void](Assert-UpdaterChild $appDir $resourceDir); [void](Assert-UpdaterChild $oldApp $resourceDir)
      Retry 'rename legacy app' { Rename-Item -LiteralPath $appDir -NewName (Split-Path -Leaf $oldApp) }
    }
    P 50 'ينسخ البرنامج الجديد…'
    Copy-UpdaterPayload $asarNew $asarDst
    P 75 'ينسخ المحرك…'
    if (-not (Test-Path -LiteralPath $engineDst)) { [void](New-Item -ItemType Directory -Path $engineDst -Force) }
    foreach ($file in @(Get-ChildItem -LiteralPath $engineNew -File)) {
      $target = Assert-UpdaterChild (Join-Path $engineDst $file.Name) $engineDst
      Copy-UpdaterPayload $file.FullName $target
    }
    if (Test-Path -LiteralPath $appDir) { throw 'Legacy resources/app still shadows app.asar' }
    # The renamed original remains available until every payload hash passed.
    [void](Assert-UpdaterChild $oldApp $resourceDir)
    if (Test-Path -LiteralPath $oldApp) { Remove-Item -LiteralPath $oldApp -Recurse -Force -ErrorAction SilentlyContinue }
    [void](Assert-UpdaterChild $payloadDir $payloadParent)
    Remove-Item -LiteralPath $payloadDir -Recurse -Force -ErrorAction SilentlyContinue
    L 'update committed'
    return @{ok=$true;error='';backup=$bak}
  } catch {
    $why = $_.Exception.Message; $rollbackErrors = @()
    L ('update failed: ' + $why)
    if ($backedUp) {
      P 90 'صار خطأ — يرجّع النسخة السابقة…'
      try {
        [void](Assert-UpdaterChild $asarDst $resourceDir)
        if ($hadAsar) { Copy-Item -LiteralPath (Join-Path $bak 'app.asar') -Destination $asarDst -Force }
        elseif (Test-Path -LiteralPath $asarDst) { Remove-Item -LiteralPath $asarDst -Force }
      } catch { $rollbackErrors += $_.Exception.Message }
      try {
        [void](Assert-UpdaterChild $engineDst $resourceDir)
        if (Test-Path -LiteralPath $engineDst) { Remove-Item -LiteralPath $engineDst -Recurse -Force }
        if ($hadEngine) { Copy-Item -LiteralPath (Join-Path $bak 'engine') -Destination $engineDst -Recurse -Force }
      } catch { $rollbackErrors += $_.Exception.Message }
      try {
        [void](Assert-UpdaterChild $appDir $resourceDir); [void](Assert-UpdaterChild $oldApp $resourceDir)
        if ($hadApp -and -not (Test-Path -LiteralPath $appDir)) {
          if (Test-Path -LiteralPath $oldApp) { Move-Item -LiteralPath $oldApp -Destination $appDir }
          else { Copy-Item -LiteralPath (Join-Path $bak 'app') -Destination $appDir -Recurse -Force }
        }
      } catch { $rollbackErrors += $_.Exception.Message }
    }
    if ($rollbackErrors.Count) { $why += '; rollback incomplete: ' + ($rollbackErrors -join ' / ') }
    return @{ok=$false;error=$why;rollbackErrors=$rollbackErrors;backup=$bak}
  }
}
# Tests dot-source only these functions. They never open UI, kill processes,
# install an update, or relaunch the user's application.
if ($TestMode) { return }
function L($m) { "$(Get-Date -Format 'HH:mm:ss') $m" | Out-File $log -Append -Encoding utf8 }
$res = Resolve-UpdaterDirectory $res
$root = Resolve-UpdaterDirectory (Split-Path -Parent $res)
if ((Split-Path -Leaf $res) -ine 'resources') { throw 'Expected the application resources directory' }
[void](Assert-UpdaterChild $res $root)
[void](Assert-UpdaterChild $exe $root)
if ([IO.Path]::GetExtension($exe) -ine '.exe' -or -not (Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'Application executable is missing' }
L "updater v2: root=$root"

# ---------- نافذة التقدّم ----------
$ui = $null
try {
  Add-Type -AssemblyName System.Windows.Forms, System.Drawing
  [System.Windows.Forms.Application]::EnableVisualStyles()
  $f = New-Object System.Windows.Forms.Form
  $f.Text = 'Demset Tweaks'; $f.Size = New-Object System.Drawing.Size(420, 170); $f.StartPosition = 'CenterScreen'
  $f.FormBorderStyle = 'FixedDialog'; $f.MaximizeBox = $false; $f.MinimizeBox = $false; $f.ControlBox = $false; $f.TopMost = $true
  $f.BackColor = [System.Drawing.Color]::FromArgb(13, 7, 32); $f.ForeColor = [System.Drawing.Color]::FromArgb(242, 238, 255)
  $f.RightToLeft = 'Yes'; $f.RightToLeftLayout = $true
  try { $f.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($exe) } catch {}
  $t = New-Object System.Windows.Forms.Label; $t.Text = 'يحدّث Demset Tweaks…'; $t.Font = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
  $t.AutoSize = $false; $t.Size = New-Object System.Drawing.Size(380, 28); $t.Location = New-Object System.Drawing.Point(16, 14); $f.Controls.Add($t)
  $s = New-Object System.Windows.Forms.Label; $s.Text = 'يجهّز…'; $s.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
  $s.ForeColor = [System.Drawing.Color]::FromArgb(174, 166, 208); $s.AutoSize = $false; $s.Size = New-Object System.Drawing.Size(300, 22); $s.Location = New-Object System.Drawing.Point(16, 48); $f.Controls.Add($s)
  $pc = New-Object System.Windows.Forms.Label; $pc.Text = '0%'; $pc.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
  $pc.ForeColor = [System.Drawing.Color]::FromArgb(62, 230, 200); $pc.AutoSize = $false; $pc.TextAlign = 'MiddleLeft'; $pc.Size = New-Object System.Drawing.Size(70, 22); $pc.Location = New-Object System.Drawing.Point(326, 48); $f.Controls.Add($pc)
  $pb = New-Object System.Windows.Forms.ProgressBar; $pb.Minimum = 0; $pb.Maximum = 100; $pb.Value = 0; $pb.Style = 'Continuous'
  $pb.Size = New-Object System.Drawing.Size(380, 16); $pb.Location = New-Object System.Drawing.Point(16, 82); $f.Controls.Add($pb)
  $f.Show(); [System.Windows.Forms.Application]::DoEvents()
  $ui = @{ f = $f; s = $s; pb = $pb; pc = $pc; t = $t }
} catch { L "ui: $($_.Exception.Message)" }
function P([int]$p, [string]$msg) {
  L "$p% $msg"
  if (-not $ui) { return }
  try { $ui.pb.Value = [Math]::Min(100, [Math]::Max(0, $p)); $ui.pc.Text = "$p%"; $ui.s.Text = $msg; [System.Windows.Forms.Application]::DoEvents() } catch {}
}
function Pause-UI([int]$ms) { $end = (Get-Date).AddMilliseconds($ms); while ((Get-Date) -lt $end) { if ($ui) { try { [System.Windows.Forms.Application]::DoEvents() } catch {} }; Start-Sleep -Milliseconds 50 } }

# ---------- 1) نسكّر كل شي شغّال من مجلد البرنامج ----------
P 5 'يقفل البرنامج…'
$deadline = (Get-Date).AddSeconds(20)
do {
  $procs = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessId -ne $PID -and (Test-UpdaterProcess $_ $root $res) })
  if (-not $procs.Count) { break }
  if ((Get-Date) -gt $deadline.AddSeconds(-14)) { foreach ($p in $procs) { try { Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop; L "killed $($p.Name) $($p.ProcessId)" } catch {} } }
  Pause-UI 500
} while ((Get-Date) -lt $deadline)
Pause-UI 800
P 15 'يتأكد من الملفات…'

function Retry([string]$what, [scriptblock]$b) { for ($i = 0; $i -lt 15; $i++) { try { & $b; return } catch { if ($i -eq 14) { L "FAILED $what : $($_.Exception.Message)"; throw }; Pause-UI 700 } } }
function Same([string]$a, [string]$b) { try { return (Get-FileHash -LiteralPath $a -Algorithm SHA256).Hash -eq (Get-FileHash -LiteralPath $b -Algorithm SHA256).Hash } catch { return $false } }

try { $transaction = Invoke-UpdaterTransaction $res $tmp }
catch { $transaction = @{ok=$false;error=$_.Exception.Message} }
$ok = [bool]$transaction.ok; $why = [string]$transaction.error
# نتيجة يقراها البرنامج أول ما يفتح (عشان يقول للمستخدم لو التحديث ما انطبق ووش السبب)
try { (@{ ok = $ok; error = $why; at = (Get-Date -Format s) } | ConvertTo-Json -Compress) | Out-File (Join-Path (Split-Path -Parent $log) 'result.json') -Encoding utf8 } catch {}
if ($ok) { P 100 'خلص — يشغّل البرنامج…' } else { P 100 'ما انطبق التحديث — يشغّل النسخة السابقة' }
Pause-UI 900
Start-Process -FilePath $exe
L 'started app'
if ($ui) { try { $ui.f.Close() } catch {} }
