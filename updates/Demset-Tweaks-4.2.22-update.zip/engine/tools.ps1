﻿# =============================================================
#  الأدوات: إزالة البرامج من جذورها، VPN (Cloudflare WARP)، شريط المهام
# =============================================================

# ---------------- قائمة البرامج المثبتة (مفصّلة) ----------------
function Get-UninstallList {
  $roots = @(
    @{ p = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'; s = 'HKLM' },
    @{ p = 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'; s = 'HKLM32' },
    @{ p = 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'; s = 'HKCU' }
  )
  $out = @()
  foreach ($r in $roots) {
    foreach ($k in (Get-ChildItem $r.p -ErrorAction SilentlyContinue)) {
      $p = Get-ItemProperty $k.PSPath -ErrorAction SilentlyContinue
      if (-not $p.DisplayName -or $p.SystemComponent -eq 1 -or $p.ParentKeyName -or "$($p.ReleaseType)" -match 'Update|Hotfix') { continue }
      if (-not $p.UninstallString -and -not $p.QuietUninstallString) { continue }
      $icon = "$($p.DisplayIcon)" -replace '^"|"?,\s*-?\d+$|"$', ''
      $date = $null; if ("$($p.InstallDate)" -match '^\d{8}$') { $date = "$($p.InstallDate)" }
      $out += @{ name = "$($p.DisplayName)".Trim(); publisher = "$($p.Publisher)".Trim(); version = "$($p.DisplayVersion)"; date = $date
        sizeKB = [int64]("0$($p.EstimatedSize)"); loc = "$($p.InstallLocation)".Trim('"').TrimEnd('\'); icon = $icon
        uninstall = "$($p.UninstallString)"; quiet = "$($p.QuietUninstallString)"; key = ($k.Name -replace '^HKEY_LOCAL_MACHINE', 'HKLM' -replace '^HKEY_CURRENT_USER', 'HKCU'); scope = $r.s; msi = ("$($p.UninstallString)" -match 'msiexec') }
    }
  }
  return $out
}

# ---------------- البحث عن البقايا ----------------
# قواعد الأمان: ما نقترح أي مسار أساسي، ولا مجلدات ناشرين مشتركة (Microsoft، Common Files...)، والمطابقة لازم تكون بالاسم الكامل.
function Get-NameKeys($app) {
  $n = "$($app.name)" -replace '\s*\(.*?\)', '' -replace '\s+v?\d+(\.\d+)+.*$', '' -replace '\s+(x64|x86|64-bit|32-bit)$', ''
  $n = $n.Trim()
  $keys = @($n)
  $nn = $n -replace '[^A-Za-z0-9]', ''
  if ($nn -and $nn -ne $n) { $keys += $nn }
  $pub = ("$($app.publisher)" -replace ',?\s*(Inc|LLC|Ltd|Corporation|Corp|GmbH|Co|PBC|S\.A|AB)\.?$', '').Trim()
  return @{ names = @($keys | Where-Object { $_.Length -ge 3 } | Select-Object -Unique); pub = $pub }
}
$script:NEVER = @('microsoft', 'windows', 'common files', 'windowsapps', 'internet explorer', 'windows defender', 'windows nt', 'packages', 'temp', 'programs', 'microsoft shared', 'reference assemblies', 'msbuild', 'dotnet', 'google', 'nvidia corporation', 'intel', 'amd', 'realtek')
function Test-SafeLeftoverPath([string]$p) {
  if (-not $p) { return $false }
  $l = $p.ToLower().TrimEnd('\')
  $win = $env:windir.ToLower()
  if ($l -eq $win -or $l.StartsWith($win + '\')) { return $false }
  $roots = @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:ProgramData, $env:APPDATA, $env:LOCALAPPDATA, ($env:LOCALAPPDATA + '\Programs'), $env:USERPROFILE, $env:PUBLIC, "$env:SystemDrive\", ($env:USERPROFILE + '\Documents'), ($env:USERPROFILE + '\Desktop')) | Where-Object { $_ } | ForEach-Object { $_.ToLower().TrimEnd('\') }
  if ($roots -contains $l) { return $false }
  $leaf = (Split-Path $l -Leaf)
  if ($script:NEVER -contains $leaf) { return $false }
  return $true
}
function Get-DirSize([string]$p) { try { return [int64]((Get-ChildItem -LiteralPath $p -Recurse -Force -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum) } catch { return 0 } }

function Find-Leftovers($app) {
  $k = Get-NameKeys $app
  $items = @()
  $seen = @{}
  function AddF($path, $reason, $strong) {
    if (-not (Test-Path -LiteralPath $path)) { return }
    if (-not (Test-SafeLeftoverPath $path)) { return }
    $key = $path.ToLower(); if ($seen.ContainsKey($key)) { return }; $seen[$key] = 1
    $script:found += @{ kind = 'folder'; path = $path; size = (Get-DirSize $path); reason = $reason; strong = [bool]$strong }
  }
  $script:found = @()
  # 1) مكان التثبيت نفسه إذا باقي
  if ($app.loc) { AddF $app.loc 'مكان التثبيت (باقي بعد الحذف)' $true }
  # 2) مجلدات باسم البرنامج أو الناشر\البرنامج
  $bases = @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:ProgramData, $env:APPDATA, $env:LOCALAPPDATA, (Join-Path $env:LOCALAPPDATA 'Programs'), (Join-Path $env:USERPROFILE 'Documents')) | Where-Object { $_ -and (Test-Path $_) }
  $docs = (Join-Path $env:USERPROFILE 'Documents').ToLower()
  foreach ($b in $bases) {
    $isDocs = $b.ToLower() -eq $docs
    foreach ($nm in $k.names) {
      if ($isDocs) { AddF (Join-Path $b $nm) 'مجلد بالمستندات — ممكن فيه ملفاتك أو حفظ الألعاب (راجعه قبل)' $false; continue }
      AddF (Join-Path $b $nm) "مجلد باسم البرنامج في $(Split-Path $b -Leaf)" $true
      if ($k.pub -and $k.pub -ne $nm) { AddF (Join-Path (Join-Path $b $k.pub) $nm) "مجلد الناشر\البرنامج في $(Split-Path $b -Leaf)" $true }
    }
    # مجلد الناشر نفسه: بس إذا اسم الناشر نفس اسم البرنامج (مثل Discord) — غير كذا ما نلمسه لأنه ممكن فيه برامج ثانية
    if ($k.pub -and ($k.names -contains $k.pub)) { AddF (Join-Path $b $k.pub) 'مجلد الناشر (نفس اسم البرنامج)' $true }
  }
  # 3) اختصارات قائمة ابدأ وسطح المكتب
  $lnkDirs = @((Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'), (Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs'), [Environment]::GetFolderPath('Desktop'), (Join-Path $env:PUBLIC 'Desktop'))
  foreach ($d in $lnkDirs) {
    if (-not (Test-Path $d)) { continue }
    foreach ($nm in $k.names) {
      $f = Join-Path $d $nm
      if (Test-Path -LiteralPath $f -PathType Container) { if (-not $seen.ContainsKey($f.ToLower())) { $seen[$f.ToLower()] = 1; $script:found += @{ kind = 'folder'; path = $f; size = (Get-DirSize $f); reason = 'مجلد اختصارات بقائمة ابدأ'; strong = $true } } }
      foreach ($l in (Get-ChildItem -LiteralPath $d -Filter "$nm*.lnk" -File -ErrorAction SilentlyContinue)) {
        if (-not $seen.ContainsKey($l.FullName.ToLower())) { $seen[$l.FullName.ToLower()] = 1; $script:found += @{ kind = 'file'; path = $l.FullName; size = $l.Length; reason = 'اختصار'; strong = $true } }
      }
    }
  }
  # 4) الريجستري: Software\<البرنامج> و Software\<الناشر>\<البرنامج>
  $regBases = @('HKCU\Software', 'HKLM\SOFTWARE', 'HKLM\SOFTWARE\WOW6432Node')
  foreach ($rb in $regBases) {
    foreach ($nm in $k.names) {
      foreach ($rk in @("$rb\$nm", $(if ($k.pub -and $k.pub -ne $nm) { "$rb\$($k.pub)\$nm" }))) {
        if (-not $rk) { continue }
        $leaf = (Split-Path $rk -Leaf).ToLower()
        if ($script:NEVER -contains $leaf -or $rk -match '\\(Microsoft|Classes|Policies|Wow6432Node)$') { continue }
        if (Test-RegKey $rk) { $script:found += @{ kind = 'regkey'; path = $rk; size = 0; reason = 'إعدادات البرنامج بالريجستري'; strong = $true } }
      }
    }
  }
  if ($app.key -and (Test-RegKey $app.key)) { $script:found += @{ kind = 'regkey'; path = $app.key; size = 0; reason = 'سجل إلغاء التثبيت (باقي بعد الحذف)'; strong = $true } }
  # 5) خدمات ومهام مجدولة وبدء تشغيل تشير لمكان البرنامج
  $locs = @(); if ($app.loc) { $locs += $app.loc.ToLower() }
  foreach ($f in $script:found) { if ($f.kind -eq 'folder' -and $f.path -notmatch 'Start Menu|Desktop') { $locs += $f.path.ToLower() } }
  $locs = @($locs | Select-Object -Unique)
  if ($locs.Count) {
    foreach ($sv in (Get-CimInstance Win32_Service -ErrorAction SilentlyContinue)) {
      $pn = "$($sv.PathName)".ToLower().Trim('"')
      if ($locs | Where-Object { $pn.StartsWith($_) -or $pn.StartsWith('"' + $_) }) { $script:found += @{ kind = 'service'; path = $sv.Name; display = $sv.DisplayName; size = 0; reason = "خدمة من مجلد البرنامج ($($sv.State))"; strong = $true } }
    }
    try {
      foreach ($t in (Get-ScheduledTask -ErrorAction Stop)) {
        if ($t.TaskPath -like '\Microsoft\*') { continue }
        $ex = (@($t.Actions | Where-Object { $_.Execute }) | ForEach-Object { [Environment]::ExpandEnvironmentVariables("$($_.Execute)".Trim('"')).ToLower() })
        if ($ex | Where-Object { $e2 = $_; $locs | Where-Object { $e2.StartsWith($_) } }) { $script:found += @{ kind = 'task'; path = $t.TaskPath + $t.TaskName; tname = $t.TaskName; tpath = $t.TaskPath; size = 0; reason = 'مهمة مجدولة تشغّل البرنامج'; strong = $true } }
      }
    } catch {}
    foreach ($rk in @('HKCU\Software\Microsoft\Windows\CurrentVersion\Run', 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run', 'HKLM\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run')) {
      $b = Split-RegPath $rk; $key = $b[0].OpenSubKey($b[1], $false); if (-not $key) { continue }
      foreach ($vn in $key.GetValueNames()) {
        $cmd = "$($key.GetValue($vn))".ToLower().Trim('"')
        if ($locs | Where-Object { $cmd.StartsWith($_) -or $cmd.Contains($_) }) { $script:found += @{ kind = 'runvalue'; path = "$rk|$vn"; size = 0; reason = 'تشغيل تلقائي يشير للبرنامج'; strong = $true } }
      }
      $key.Close()
    }
  }
  return $script:found
}

# ---------------- حذف البقايا (مع نسخة احتياطية) ----------------
function Remove-Leftovers($cfg) {
  Add-Type -AssemblyName Microsoft.VisualBasic
  $bk = $cfg.backup
  New-Item -ItemType Directory -Force -Path $bk | Out-Null
  $done = @(); $i = 0
  foreach ($it in @($cfg.items)) {
    $i++
    $res = @{ kind = $it.kind; path = $it.path; ok = $false }
    try {
      switch ($it.kind) {
        'folder' {
          if (-not (Test-SafeLeftoverPath $it.path)) { throw 'مسار محمي' }
          [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory($it.path, 'OnlyErrorDialogs', 'SendToRecycleBin'); $res.note = 'انتقل لسلة المحذوفات'
        }
        'file' { [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($it.path, 'OnlyErrorDialogs', 'SendToRecycleBin'); $res.note = 'انتقل لسلة المحذوفات' }
        'regkey' {
          $f = Join-Path $bk ("reg-$i.reg")
          & reg.exe export $it.path $f /y 2>&1 | Out-Null
          if (-not (Test-Path $f)) { throw 'ما قدرت أسوي نسخة احتياطية للمفتاح' }
          & reg.exe delete $it.path /f 2>&1 | Out-Null
          if (Test-RegKey $it.path) { throw 'المفتاح باقي' }
          $res.backup = $f; $res.note = 'انحذف (عندك نسخة .reg)'
        }
        'runvalue' {
          $parts = $it.path -split '\|', 2
          $f = Join-Path $bk ("run-$i.reg")
          & reg.exe export $parts[0] $f /y 2>&1 | Out-Null
          Remove-RegValue $parts[0] $parts[1]; $res.backup = $f; $res.note = 'انحذف من التشغيل التلقائي'
        }
        'service' {
          $sv = Get-CimInstance Win32_Service -Filter ("Name='" + $it.path + "'")
          @{ name = $sv.Name; display = $sv.DisplayName; path = $sv.PathName; start = $sv.StartMode } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $bk "svc-$i.json") -Encoding UTF8
          Stop-Service -Name $it.path -Force -ErrorAction SilentlyContinue
          & sc.exe delete $it.path 2>&1 | Out-Null
          $res.note = 'الخدمة انحذفت (معلوماتها محفوظة)'
        }
        'task' {
          Export-ScheduledTask -TaskName $it.tname -TaskPath $it.tpath | Set-Content -LiteralPath (Join-Path $bk "task-$i.xml") -Encoding Unicode
          Unregister-ScheduledTask -TaskName $it.tname -TaskPath $it.tpath -Confirm:$false -ErrorAction Stop
          $res.backup = (Join-Path $bk "task-$i.xml"); $res.note = 'المهمة انحذفت (عندك نسخة XML)'
        }
      }
      $res.ok = $true
      Log ("  ✓ " + $it.path + " — " + $res.note)
    } catch { $res.error = $_.Exception.Message; Warn ("  ✗ " + $it.path + ": " + $res.error) }
    $done += $res
  }
  Emit 'leftclean' (ConvertTo-Json -InputObject @($done) -Compress -Depth 3)
}
function Restore-UninstallBackup([string]$dir) {
  $n = 0
  foreach ($f in (Get-ChildItem -LiteralPath $dir -Filter '*.reg' -ErrorAction SilentlyContinue)) { & reg.exe import $f.FullName 2>&1 | Out-Null; if ($LASTEXITCODE -eq 0) { $n++; Log "  رجّعت $($f.Name)" } }
  foreach ($f in (Get-ChildItem -LiteralPath $dir -Filter 'task-*.xml' -ErrorAction SilentlyContinue)) {
    try { $x = [xml](Get-Content -LiteralPath $f.FullName -Raw); $uri = $x.Task.RegistrationInfo.URI; Register-ScheduledTask -Xml (Get-Content -LiteralPath $f.FullName -Raw) -TaskName (Split-Path $uri -Leaf) -TaskPath ((Split-Path $uri) + '\') -Force | Out-Null; $n++; Log "  رجّعت المهمة $uri" } catch { Warn "  $($_.Exception.Message)" }
  }
  Emit 'result' ("done:$n:0")
}

# ---------------- VPN: Cloudflare WARP (مجاني بدون حد) ----------------
function Get-WarpCli {
  foreach ($p in @("$env:ProgramFiles\Cloudflare\Cloudflare WARP\warp-cli.exe", "${env:ProgramFiles(x86)}\Cloudflare\Cloudflare WARP\warp-cli.exe")) { if (Test-Path $p) { return $p } }
  return $null
}
function Invoke-Vpn([string]$action) {
  $cli = Get-WarpCli
  if (-not $cli) { Emit 'vpn' (@{ installed = $false } | ConvertTo-Json -Compress); return }
  $run = { param($a) $o = (& $cli @a 2>&1 | Out-String).Trim(); return $o }
  switch ($action) {
    'connect' {
      $reg = & $run @('--accept-tos', 'registration', 'show')
      if ($reg -match '(?i)missing|not registered|error') { $o = & $run @('--accept-tos', 'registration', 'new'); Log "  التسجيل: $o" }
      & $run @('--accept-tos', 'mode', 'warp') | Out-Null
      $o = & $run @('--accept-tos', 'connect'); Log "  $o"
      $t = 0; while ($t -lt 15) { Start-Sleep -Milliseconds 700; $st = & $run @('--accept-tos', 'status'); if ($st -match '(?i)Connected' -and $st -notmatch '(?i)Disconnected|Connecting') { break }; $t++ }
    }
    'disconnect' {
      # "Always On" يرجّع WARP يتصل لحاله — نطفيه (الأمر يختلف بين نسخ warp-cli، فنجرب الاثنين)
      & $run @('--accept-tos', 'disable-always-on') | Out-Null
      & $run @('--accept-tos', 'always-on', 'false') | Out-Null
      $o = & $run @('--accept-tos', 'disconnect'); Log "  $o"
      $t = 0; while ($t -lt 15) { Start-Sleep -Milliseconds 700; $st = & $run @('--accept-tos', 'status'); if ($st -match '(?i)Disconnected') { break }; $t++ }
    }
  }
  $st = & $run @('--accept-tos', 'status')
  $state = $(if ($st -match '(?i)Disconnected') { 'disconnected' } elseif ($st -match '(?i)Connecting') { 'connecting' } elseif ($st -match '(?i)Connected') { 'connected' } else { 'unknown' })
  Emit 'vpn' (@{ installed = $true; state = $state; raw = $st } | ConvertTo-Json -Compress)
}

# ---------------- شريط المهام ----------------
function Invoke-Taskbar($cfg) {
  if (-not ('DemsetTaskbar' -as [type])) {
    Add-Type -TypeDefinition @'
  using System;
  using System.Runtime.InteropServices;
  public static class DemsetTaskbar {
    [StructLayout(LayoutKind.Sequential)] struct RECT { public int l, t, r, b; }
    [StructLayout(LayoutKind.Sequential)] struct APPBARDATA { public int cbSize; public IntPtr hWnd; public uint msg; public uint edge; public RECT rc; public IntPtr lParam; }
    [DllImport("shell32.dll")] static extern IntPtr SHAppBarMessage(uint msg, ref APPBARDATA d);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern IntPtr FindWindow(string c, string w);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern IntPtr FindWindowEx(IntPtr p, IntPtr a, string c, string w);
    [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int cmd);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
    [StructLayout(LayoutKind.Sequential)] struct ACCENT { public int state; public int flags; public uint color; public int anim; }
    [StructLayout(LayoutKind.Sequential)] struct WCAD { public int attr; public IntPtr data; public int size; }
    [DllImport("user32.dll")] static extern int SetWindowCompositionAttribute(IntPtr h, ref WCAD d);
    const uint ABM_GETSTATE = 4, ABM_SETSTATE = 10;
    public static bool GetAutoHide() { var d = new APPBARDATA(); d.cbSize = Marshal.SizeOf(d); d.hWnd = FindWindow("Shell_TrayWnd", null); return ((long)SHAppBarMessage(ABM_GETSTATE, ref d) & 1) != 0; }
    public static void SetAutoHide(bool on) { var d = new APPBARDATA(); d.cbSize = Marshal.SizeOf(d); d.hWnd = FindWindow("Shell_TrayWnd", null); d.lParam = (IntPtr)(on ? 1 : 2); SHAppBarMessage(ABM_SETSTATE, ref d); }
    static IntPtr[] Bars() {
      var list = new System.Collections.Generic.List<IntPtr>();
      var m = FindWindow("Shell_TrayWnd", null); if (m != IntPtr.Zero) list.Add(m);
      IntPtr s = IntPtr.Zero; while ((s = FindWindowEx(IntPtr.Zero, s, "Shell_SecondaryTrayWnd", null)) != IntPtr.Zero) list.Add(s);
      return list.ToArray();
    }
    public static bool IsHidden() { var m = FindWindow("Shell_TrayWnd", null); return m != IntPtr.Zero && !IsWindowVisible(m); }
    public static int SetHidden(bool hide) { int n = 0; foreach (var h in Bars()) { ShowWindow(h, hide ? 0 : 5); n++; } return n; }
    // يشتغل على ويندوز 10 (شريط ويندوز 11 الجديد يرسم خلفيته بنفسه)
    public static int SetAccent(int state, uint abgr) {
      int n = 0;
      foreach (var h in Bars()) {
        var a = new ACCENT { state = state, flags = 2, color = abgr };
        int sz = Marshal.SizeOf(a); IntPtr p = Marshal.AllocHGlobal(sz);
        try { Marshal.StructureToPtr(a, p, false); var d = new WCAD { attr = 19, data = p, size = sz }; SetWindowCompositionAttribute(h, ref d); n++; } finally { Marshal.FreeHGlobal(p); }
      }
      return n;
    }
  }
'@
  }

  switch ("$($cfg.action)") {
    'autohide' { [DemsetTaskbar]::SetAutoHide([bool]$cfg.on) }
    'hide' { [DemsetTaskbar]::SetHidden([bool]$cfg.on) | Out-Null }
    'restart-explorer' { Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue; Start-Sleep -Milliseconds 900; if (-not (Get-Process explorer -ErrorAction SilentlyContinue)) { Start-Process explorer.exe } }
  }
  Start-Sleep -Milliseconds 300
  $ttb = [bool](Get-Process TranslucentTB -ErrorAction SilentlyContinue)
  $ttbPath = $null
  try { $pk = Get-AppxPackage -Name '*TranslucentTB*' -ErrorAction SilentlyContinue | Select-Object -First 1; if ($pk) { $aid = @((Get-AppxPackageManifest $pk).Package.Applications.Application)[0].Id; $ttbPath = 'shell:AppsFolder\' + $pk.PackageFamilyName + '!' + $aid } } catch {}
  foreach ($p in @("$env:LOCALAPPDATA\Programs\TranslucentTB\TranslucentTB.exe", "$env:ProgramFiles\TranslucentTB\TranslucentTB.exe")) { if (Test-Path $p) { $ttbPath = $p } }
  $build = [int](Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion').CurrentBuildNumber
  Emit 'taskbar' (@{ autohide = [DemsetTaskbar]::GetAutoHide(); hidden = [DemsetTaskbar]::IsHidden(); ttbRunning = $ttb; ttbPath = $ttbPath; build = $build; win11 = ($build -ge 22000) } | ConvertTo-Json -Compress)
}

# =============================================================
#  اختبار Bufferbloat: كم يزيد البنق لما الخط مشغول (تحميل/رفع)
#  نقيس البنق والخط فاضي، بعدين وقت تحميل قوي من Cloudflare، بعدين وقت رفع.
#  الزيادة هي اللي تحس فيها كلاق لما أحد في البيت يحمّل أو يشوف يوتيوب.
# =============================================================
function Invoke-Bufferbloat($cfg) {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  [Net.ServicePointManager]::DefaultConnectionLimit = 32
  $target = $(if ($cfg -and $cfg.host) { "$($cfg.host)" } else { '1.1.1.1' })
  $secs = 9
  $ping = New-Object System.Net.NetworkInformation.Ping
  $pingFor = {
    param([double]$sec, [string]$label, [int]$p0, [int]$p1)
    $r = New-Object System.Collections.ArrayList; $lost = 0
    $sw = [Diagnostics.Stopwatch]::StartNew()
    while ($sw.Elapsed.TotalSeconds -lt $sec) {
      try { $x = $ping.Send($target, 1500); if ($x.Status -eq 'Success') { [void]$r.Add([int]$x.RoundtripTime) } else { $lost++ } } catch { $lost++ }
      Emit 'progress' (@{ p = [int]($p0 + ($p1 - $p0) * [math]::Min(1, $sw.Elapsed.TotalSeconds / $sec)); label = $label } | ConvertTo-Json -Compress)
      Start-Sleep -Milliseconds 250
    }
    return @{ list = @($r); lost = $lost }
  }
  $stats = {
    param($o)
    $l = @($o.list | Sort-Object)
    if (-not $l.Count) { return @{ med = $null; p90 = $null; n = 0; lost = $o.lost } }
    return @{ med = $l[[int][math]::Floor(($l.Count - 1) / 2)]; p90 = $l[[int][math]::Floor(($l.Count - 1) * 0.9)]; n = $l.Count; lost = $o.lost }
  }
  # شغل التحميل/الرفع في Runspaces عشان البنق يتقاس بنفس الوقت
  $worker = {
    param([string]$url, [double]$secs, [bool]$up)
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $bytes = [int64]0; $buf = New-Object byte[] 65536; $sw = [Diagnostics.Stopwatch]::StartNew()
    while ($sw.Elapsed.TotalSeconds -lt $secs) {
      $req = $null
      try {
        $req = [Net.HttpWebRequest]::Create($url); $req.Timeout = 10000; $req.ReadWriteTimeout = 10000; $req.UserAgent = 'DemsetTweaks'
        if ($up) {
          $req.Method = 'POST'; $req.SendChunked = $true; $req.AllowWriteStreamBuffering = $false; $req.ContentType = 'application/octet-stream'
          $st = $req.GetRequestStream()
          $sent = 0
          while ($sw.Elapsed.TotalSeconds -lt $secs -and $sent -lt 50MB) { $st.Write($buf, 0, $buf.Length); $bytes += $buf.Length; $sent += $buf.Length }
          $st.Close(); try { $req.GetResponse().Close() } catch {}
        } else {
          $resp = $req.GetResponse(); $st = $resp.GetResponseStream()
          while ($sw.Elapsed.TotalSeconds -lt $secs) { $n = $st.Read($buf, 0, $buf.Length); if ($n -le 0) { break }; $bytes += $n }
          $req.Abort()
        }
      } catch { if ($req) { try { $req.Abort() } catch {} }; Start-Sleep -Milliseconds 300 }
    }
    return $bytes
  }
  $load = {
    param([bool]$up, [string]$label, [int]$p0, [int]$p1)
    $pool = [runspacefactory]::CreateRunspacePool(1, 6); $pool.Open()
    $url = $(if ($up) { 'https://speed.cloudflare.com/__up' } else { 'https://speed.cloudflare.com/__down?bytes=100000000' })
    $jobs = foreach ($i in 1..4) { $ps = [powershell]::Create().AddScript($worker).AddArgument($url).AddArgument($secs).AddArgument($up); $ps.RunspacePool = $pool; @{ ps = $ps; h = $ps.BeginInvoke() } }
    Start-Sleep -Milliseconds 1500   # نخلي الخط يمتلي قبل نقيس
    $pg = & $pingFor ($secs - 2) $label $p0 $p1
    $total = [int64]0
    foreach ($j in $jobs) { try { $total += [int64](@($j.ps.EndInvoke($j.h))[0]) } catch {}; $j.ps.Dispose() }
    $pool.Close()
    return @{ ping = $pg; mbps = [math]::Round($total * 8 / 1e6 / $secs, 1) }
  }

  Log "▶ البنق والخط فاضي ($target)"
  $idle = & $stats (& $pingFor 5 'البنق والخط فاضي' 0 25)
  if (-not $idle.n) { Emit 'bloat' (@{ ok = $false; error = "ما فيه رد من $target — يمكن الجدار الناري يمنع ping" } | ConvertTo-Json -Compress); return }
  Log "  الفاضي: $($idle.med) ms"
  Log '▶ وقت التحميل'
  $dl = & $load $false 'البنق وقت التحميل' 25 62
  $dls = & $stats $dl.ping
  Log "  وقت التحميل: $($dls.med) ms · سرعة ~$($dl.mbps) Mbps"
  Log '▶ وقت الرفع'
  $ul = & $load $true 'البنق وقت الرفع' 62 100
  $uls = & $stats $ul.ping
  Log "  وقت الرفع: $($uls.med) ms · سرعة ~$($ul.mbps) Mbps"
  $inc = { param($a) if ($null -eq $a.med) { return $null }; return [math]::Max(0, $a.med - $idle.med) }
  $dInc = & $inc $dls; $uInc = & $inc $uls
  $worst = @($dInc, $uInc | Where-Object { $null -ne $_ } | Measure-Object -Maximum).Maximum
  $grade = $(if ($null -eq $worst) { '?' } elseif ($worst -lt 5) { 'A+' } elseif ($worst -lt 30) { 'A' } elseif ($worst -lt 60) { 'B' } elseif ($worst -lt 200) { 'C' } elseif ($worst -lt 400) { 'D' } else { 'F' })
  Emit 'bloat' (@{ ok = $true; host = $target; idle = $idle; down = @{ ping = $dls; inc = $dInc; mbps = $dl.mbps }; up = @{ ping = $uls; inc = $uInc; mbps = $ul.mbps }; grade = $grade; at = (Get-Date).ToString('s') } | ConvertTo-Json -Compress -Depth 5)
}

# =============================================================
#  كاش الشيدر (Shader Cache) لكروت الشاشة
#  مسحه يفيد بعد تحديث الدرايفر أو إذا لعبة صار فيها تقطيع/خربشة غريبة.
#  أول تشغيل بعد المسح ممكن يكون فيه تقطيع خفيف لين الكاش ينبني من جديد.
# =============================================================
function Get-ShaderCacheDirs {
  $la = $env:LOCALAPPDATA; $pd = $env:ProgramData
  $list = @(
    @{ v = 'NVIDIA'; n = 'DirectX'; p = "$la\NVIDIA\DXCache" }, @{ v = 'NVIDIA'; n = 'OpenGL/Vulkan'; p = "$la\NVIDIA\GLCache" },
    @{ v = 'NVIDIA'; n = 'قديم'; p = "$la\NVIDIA Corporation\NV_Cache" }, @{ v = 'NVIDIA'; n = 'قديم (عام)'; p = "$pd\NVIDIA Corporation\NV_Cache" },
    @{ v = 'AMD'; n = 'DirectX'; p = "$la\AMD\DxCache" }, @{ v = 'AMD'; n = 'DirectX 12'; p = "$la\AMD\DxcCache" },
    @{ v = 'AMD'; n = 'Vulkan'; p = "$la\AMD\VkCache" }, @{ v = 'AMD'; n = 'OpenGL'; p = "$la\AMD\GLCache" },
    @{ v = 'Intel'; n = 'Shader'; p = "$la\Intel\ShaderCache" },
    @{ v = 'Windows'; n = 'DirectX (D3DSCache)'; p = "$la\D3DSCache" }
  )
  foreach ($d in $list) { if (Test-Path -LiteralPath $d.p) { $d.size = Get-DirSize $d.p; $d } }
}
# PowerShell 5.1 ما يدعم Measure-Object بسكربت بلوك، فنجمع يدوي
function Get-SizeSum($list) { $t = [int64]0; foreach ($d in @($list)) { if ($d -and $d.size) { $t += [int64]$d.size } }; return $t }
function Invoke-ShaderCache($cfg) {
  $dirs = @(Get-ShaderCacheDirs)
  if (-not $cfg -or -not $cfg.clean) {
    Emit 'shader' (@{ dirs = $dirs; total = (Get-SizeSum $dirs) } | ConvertTo-Json -Compress -Depth 4); return
  }
  $before = (Get-SizeSum $dirs); $locked = 0
  foreach ($d in $dirs) {
    Log ("▶ " + $d.v + ' ' + $d.n)
    Get-ChildItem -LiteralPath $d.p -Recurse -Force -File -ErrorAction SilentlyContinue | ForEach-Object { try { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction Stop } catch { $locked++ } }
    Get-ChildItem -LiteralPath $d.p -Recurse -Force -Directory -ErrorAction SilentlyContinue | Sort-Object { $_.FullName.Length } -Descending | ForEach-Object { try { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction Stop } catch {} }
  }
  $after = @(Get-ShaderCacheDirs)
  $aft = (Get-SizeSum $after)
  if ($locked) { Warn "  $locked ملف مستخدم الحين (لعبة أو برنامج فاتح) — تخطيته" }
  Log ("  انمسح {0:N1} MB" -f (($before - $aft) / 1MB))
  Emit 'shader' (@{ cleaned = $true; before = $before; after = $aft; locked = $locked; dirs = $after; total = $aft } | ConvertTo-Json -Compress -Depth 4)
}
