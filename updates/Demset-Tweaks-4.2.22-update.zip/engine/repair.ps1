﻿# =============================================================
#  مركز الإصلاح: لكل مكوّن فحص حقيقي (يكتشف المشكلة) وإصلاح حقيقي
#  الفحص يعتمد على أكواد وخصائص ثابتة (مو نصوص مترجمة) عشان يشتغل بأي لغة ويندوز
# =============================================================

function RC($status, $detail, $extra) { $o = @{ status = $status; detail = "$detail" }; if ($extra) { foreach ($k in $extra.Keys) { $o[$k] = $extra[$k] } }; return $o }

function Get-PerfDiag {
  $o = @{ wmi = $false; pdh = $false; svc = ''; disabled = @() }
  try { $x = Get-CimInstance Win32_PerfFormattedData_PerfOS_System -ErrorAction Stop; $o.wmi = ([double]$x.Processes -gt 0) } catch {}
  try { $c = New-Object Diagnostics.PerformanceCounter('Processor', '% Processor Time', '_Total'); [void]$c.NextValue(); Start-Sleep -Milliseconds 300; [void]$c.NextValue(); $o.pdh = $true } catch { $o.pdhErr = "$($_.Exception.InnerException.Message)$(if (-not $_.Exception.InnerException) { $_.Exception.Message })" }
  try { $pl = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Perflib' -ErrorAction Stop; $o.lastCounter = $pl.'Last Counter'; $o.perflibOff = $pl.'Disable Performance Counters' } catch {}
  try { $o.c009 = @((Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Perflib\009' -ErrorAction Stop).Counter).Count } catch { $o.c009 = -1 }
  try { $o.svc = "$((Get-CimInstance Win32_Service -Filter "Name='WmiApSrv'").StartMode)" } catch {}
  # الخدمات اللي تحتاجها العدادات (برامج التسريع تطفيها)
  $o.svcOff = @(foreach ($n in 'PerfHost', 'WmiApSrv', 'pla') { $x = Get-CimInstance Win32_Service -Filter "Name='$n'" -ErrorAction SilentlyContinue; if ($x -and $x.StartMode -eq 'Disabled') { $n } })
  foreach ($k in Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Services' -ErrorAction SilentlyContinue) {
    $pk = Join-Path $k.PSPath 'Performance'
    try { $v = (Get-ItemProperty -LiteralPath $pk -Name 'Disable Performance Counters' -ErrorAction Stop).'Disable Performance Counters'; if ($v -and $v -ne 0) { $o.disabled += $k.PSChildName } } catch {}
  }
  return $o
}
function Test-RepairComponent([string]$id) {
  switch ($id) {
    'image' {
      $r = Repair-WindowsImage -Online -CheckHealth -ErrorAction Stop
      $st = "$($r.ImageHealthState)"
      if ($st -eq 'Healthy') { return (RC 'ok' 'صورة الويندوز سليمة (DISM CheckHealth: Healthy)') }
      return (RC 'problem' "DISM CheckHealth: $st — فيه تلف بمخزن مكونات الويندوز")
    }
    'disk' {
      $d = $env:SystemDrive.Substring(0, 1)
      $r = Repair-Volume -DriveLetter $d -Scan -ErrorAction Stop
      if ("$r" -eq 'NoErrorsFound') { return (RC 'ok' "القرص ${d}: ما فيه أخطاء بنظام الملفات (Repair-Volume -Scan)") }
      return (RC 'problem' "القرص ${d}: $r")
    }
    'wmi' {
      $out = (& winmgmt /verifyrepository 2>&1 | Out-String).Trim()
      if ($LASTEXITCODE -eq 0) { return (RC 'ok' "مستودع WMI سليم") }
      return (RC 'problem' "مستودع WMI فيه مشكلة (كود $LASTEXITCODE): $out")
    }
    'perf' {
      $d = Get-PerfDiag
      if ($d.wmi -and $d.pdh -and -not $d.disabled.Count) { return (RC 'ok' 'عدادات الأداء شغّالة (WMI و PDH)') }
      $why = @()
      if (-not $d.pdh) { $why += "العدادات الأساسية (PDH) ما ترد [$($d.pdhErr)] (أسماء العدادات: $($d.c009)، Last Counter: $($d.lastCounter)$(if ($d.perflibOff) { '، Perflib مطفي' }))" }
      if (-not $d.wmi) { $why += 'عدادات WMI ما ترد' }
      if ($d.svcOff.Count) { $why += ('خدمات مطفية: ' + ($d.svcOff -join '، ')) }
      if ($d.disabled.Count) { $why += ('مطفية بالريجستري (غالبًا من برنامج تسريع ثاني): ' + (($d.disabled | Select-Object -First 6) -join '، ')) }
      return (RC 'problem' ($why -join ' — ') @{ disabled = $d.disabled; svc = $d.svc })
    }
    'update' {
      $issues = @()
      foreach ($sn in @('wuauserv', 'bits', 'cryptsvc', 'msiserver')) {
        $sv = Get-CimInstance Win32_Service -Filter "Name='$sn'" -ErrorAction SilentlyContinue
        if (-not $sv) { $issues += "$sn مو موجودة" } elseif ($sv.StartMode -eq 'Disabled') { $issues += "$sn مطفية (Disabled)" }
      }
      $fails = 0
      try { $fails = @(Get-WinEvent -FilterHashtable @{ LogName = 'Microsoft-Windows-WindowsUpdateClient/Operational'; Id = 20, 31; StartTime = (Get-Date).AddDays(-14) } -ErrorAction Stop).Count } catch {}
      if ($fails -gt 0) { $issues += "$fails تحديث فشل تثبيته آخر 14 يوم" }
      $sd = 0; try { $sd = [math]::Round(((Get-ChildItem "$env:windir\SoftwareDistribution\Download" -Recurse -Force -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum) / 1MB) } catch {}
      if ($issues.Count) { return (RC 'problem' ($issues -join '، ') @{ cacheMB = $sd }) }
      return (RC 'ok' "خدمات التحديث سليمة، وما فيه تحديثات فاشلة آخر 14 يوم (كاش التحميل $sd ميجا)" @{ cacheMB = $sd })
    }
    'network' {
      $issues = @()
      $up = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object Status -eq 'Up')
      if (-not $up.Count) { $issues += 'ما فيه كرت شبكة متصل' }
      $p = New-Object Net.NetworkInformation.Ping
      $ok = 0; foreach ($i in 1..3) { try { if (($p.Send('1.1.1.1', 1500)).Status -eq 'Success') { $ok++ } } catch {} }
      if ($ok -eq 0) { $issues += 'ما فيه اتصال بالإنترنت (1.1.1.1 ما يرد)' }
      $dnsOk = $false; try { $dnsOk = [bool](Resolve-DnsName 'www.microsoft.com' -QuickTimeout -ErrorAction Stop) } catch {}
      if (-not $dnsOk) { $issues += 'الـ DNS ما يحل أسماء المواقع' }
      if ($issues.Count) { return (RC 'problem' ($issues -join '، ')) }
      return (RC 'ok' "الاتصال شغّال: $($up.Count) كرت متصل، ping $ok/3، والـ DNS يرد")
    }
    'time' {
      $sv = Get-Service w32time -ErrorAction SilentlyContinue
      $out = (& w32tm /stripchart /computer:time.windows.com /samples:1 /dataonly 2>&1 | Out-String)
      $m = [regex]::Match($out, '([+-]\d+[.,]\d+)s')
      if (-not $m.Success) { return (RC 'unknown' "ما قدرت أوصل لسيرفر الوقت (خدمة الوقت: $($sv.Status))") }
      $off = [double]($m.Groups[1].Value -replace ',', '.')
      if ([math]::Abs($off) -gt 2) { return (RC 'problem' ("ساعة الجهاز مختلفة عن الوقت الصحيح بـ {0:N1} ثانية" -f $off) @{ offset = $off }) }
      return (RC 'ok' ("الساعة مضبوطة (الفرق {0:N3} ثانية)" -f $off) @{ offset = $off })
    }
    'store' {
      $pkg = Get-AppxPackage -Name Microsoft.WindowsStore -ErrorAction SilentlyContinue
      if (-not $pkg) { return (RC 'problem' 'متجر مايكروسوفت مو مثبّت') }
      if ("$($pkg.Status)" -ne 'Ok') { return (RC 'problem' "حالة المتجر: $($pkg.Status)") }
      return (RC 'ok' "المتجر سليم (الإصدار $($pkg.Version))")
    }
    'defender' {
      try { $s = Get-MpComputerStatus -ErrorAction Stop } catch { return (RC 'unknown' 'Windows Defender مو متاح (ممكن عندك أنتي فايروس ثاني)') }
      # أنتي فايروس ثاني مسجّل بمركز الأمان؟ (لو موجود، Defender يطفي نفسه تلقائيًا وهذا طبيعي)
      $other = @(Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntiVirusProduct -ErrorAction SilentlyContinue | Where-Object { $_.displayName -notmatch 'Windows Defender|Microsoft Defender' } | ForEach-Object { $_.displayName })
      $age = [int]$s.AntivirusSignatureAge
      $ageTxt = if ($age -ge 65000) { 'غير معروف' } else { "$age يوم" }
      if ($other.Count -and (-not $s.RealTimeProtectionEnabled -or "$($s.AMRunningMode)" -match 'Passive|Not running|EDR')) {
        return (RC 'ok' "الحماية من $($other -join ' + ') — Defender مطفي تلقائيًا لأن عندك برنامج حماية ثاني")
      }
      $issues = @()
      if (-not $s.AMServiceEnabled) { $issues += 'خدمة Defender مطفية' }
      if (-not $s.RealTimeProtectionEnabled) { $issues += 'الحماية الفورية مطفية وما فيه برنامج حماية ثاني' }
      if ($age -ge 65000) { if ($s.RealTimeProtectionEnabled) { $issues += 'عمر التعريفات غير معروف' } }
      elseif ($age -gt 3) { $issues += "تعريفات الفايروسات قديمة ($age يوم)" }
      if ($issues.Count) { return (RC 'problem' ($issues -join '، ')) }
      return (RC 'ok' "الحماية شغّالة والتعريفات عمرها $ageTxt")
    }
    'iconcache' {
      $dir = Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Explorer'
      $mb = [math]::Round(((Get-ChildItem $dir -Filter '*cache*.db' -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum) / 1MB, 1)
      return (RC 'unknown' "كاش الأيقونات والصور المصغرة: $mb ميجا. ما له فحص تلف — أصلحه إذا الأيقونات تطلع بيضا أو غلط" @{ mb = $mb })
    }
    'search' {
      $sv = Get-Service WSearch -ErrorAction SilentlyContinue
      if (-not $sv) { return (RC 'unknown' 'خدمة البحث مو موجودة') }
      $sm = "$((Get-CimInstance Win32_Service -Filter "Name='WSearch'").StartMode)"
      if ($sm -eq 'Disabled') { return (RC 'unknown' 'خدمة البحث مطفية (ممكن بتويك) — ما فيه شي ينصلح') }
      if ($sv.Status -ne 'Running') { return (RC 'problem' "خدمة البحث مو شغّالة ($($sv.Status))") }
      return (RC 'ok' 'خدمة البحث شغّالة. إذا البحث بقائمة ابدأ ما يلقى ملفاتك، سوّ "إعادة بناء الفهرس"')
    }
    'events' {
      $since = (Get-Date).AddDays(-7); $f = @()
      $q = @(
        @{ n = 'إطفاء مفاجئ (Kernel-Power 41)'; h = @{ LogName = 'System'; ProviderName = 'Microsoft-Windows-Kernel-Power'; Id = 41; StartTime = $since } },
        @{ n = 'شاشة زرقا (BugCheck)'; h = @{ LogName = 'System'; ProviderName = 'Microsoft-Windows-WER-SystemErrorReporting'; Id = 1001; StartTime = $since } },
        @{ n = 'أخطاء هاردوير (WHEA)'; h = @{ LogName = 'System'; ProviderName = 'Microsoft-Windows-WHEA-Logger'; StartTime = $since; Level = 1, 2, 3 } },
        @{ n = 'أخطاء القرص'; h = @{ LogName = 'System'; ProviderName = 'disk'; Id = 7, 51, 153; StartTime = $since } },
        @{ n = 'تعريف كرت الشاشة علّق وانعاد تشغيله'; h = @{ LogName = 'System'; ProviderName = 'Display'; Id = 4101; StartTime = $since } }
      )
      foreach ($x in $q) { try { $c = @(Get-WinEvent -FilterHashtable $x.h -ErrorAction Stop).Count; if ($c) { $f += "$($x.n): $c" } } catch {} }
      if ($f.Count) { return (RC 'problem' ("آخر 7 أيام: " + ($f -join '، '))) }
      return (RC 'ok' 'آخر 7 أيام: ما فيه إطفاء مفاجئ ولا شاشة زرقا ولا أخطاء هاردوير أو قرص')
    }
    default { return (RC 'unknown' 'مكوّن غير معروف') }
  }
}

function Invoke-RepairCheck($ids) {
  $out = @{}; $i = 0; $all = @($ids)
  foreach ($id in $all) {
    $i++
    Emit 'progress' (@{ p = [int]($i * 100 / $all.Count); label = $id } | ConvertTo-Json -Compress)
    try { $out[$id] = Test-RepairComponent $id } catch { $out[$id] = RC 'unknown' ("ما قدرت أفحص: " + $_.Exception.Message) }
  }
  Emit 'repaircheck' ($out | ConvertTo-Json -Compress -Depth 4)
}

function Invoke-RepairFix([string]$id) {
  $script:progLabel = $id
  switch ($id) {
    'image' {
      # أسرع: نفحص المخزن أول (ثواني). لو سليم نتخطى DISM RestoreHealth (10-30 دقيقة) ونشغّل SFC بس.
      # ولو SFC لقى ملفات ما قدر يصلحها (من CBS.log — دايمًا إنجليزي، فيشتغل بأي لغة ويندوز) نشغّل DISM وبعده SFC مرة ثانية.
      $health = ''
      try { Log '▶ فحص سريع لمخزن المكونات (DISM CheckHealth)'; $health = "$((Repair-WindowsImage -Online -CheckHealth -ErrorAction Stop).ImageHealthState)"; Log "  النتيجة: $health" } catch { Warn "  ما قدرت أفحص: $($_.Exception.Message)" }
      $runDism = { Log '▶ DISM RestoreHealth (يصلح مخزن المكونات من Windows Update) — ممكن ياخذ 10 إلى 30 دقيقة'; $c = Invoke-Cmd 'DISM /Online /Cleanup-Image /RestoreHealth'; Log "  DISM انتهى بكود $c" }
      $runSfc = {
        Log '▶ SFC /scannow (يصلح ملفات النظام من المخزن)'
        $t0 = Get-Date
        $c2 = Invoke-Cmd 'sfc /scannow'
        Log "  SFC انتهى بكود $c2"
        $bad = 0
        try {
          foreach ($l in (Get-Content -LiteralPath "$env:windir\Logs\CBS\CBS.log" -Tail 30000 -ErrorAction Stop)) {
            if ($l -notmatch '\[SR\] Cannot repair member file') { continue }
            $ts = [datetime]::MinValue
            if ($l.Length -ge 19 -and [datetime]::TryParseExact($l.Substring(0, 19), 'yyyy-MM-dd HH:mm:ss', $null, 'None', [ref]$ts) -and $ts -ge $t0.AddSeconds(-5)) { $bad++ }
          }
        } catch {}
        return $bad
      }
      if ($health -eq 'Healthy') {
        Log '  المخزن سليم — نتخطى DISM RestoreHealth'
        $bad = & $runSfc
        if ($bad -gt 0) {
          Log "  SFC لقى $bad ملف ما قدر يصلحه — نصلح المخزن ونعيد"
          & $runDism; [void](& $runSfc)
        }
      } else {
        & $runDism; [void](& $runSfc)
      }
    }
    'disk' {
      $d = $env:SystemDrive.Substring(0, 1)
      Log "▶ إصلاح القرص ${d}: وهو شغّال (Spot Fix)"
      $r = Repair-Volume -DriveLetter $d -SpotFix -ErrorAction Stop
      Log "  النتيجة: $r"
    }
    'wmi' { Log '▶ إصلاح مستودع WMI'; $c = Invoke-Cmd 'winmgmt /salvagerepository'; Log "  انتهى بكود $c" }
    'perf' {
      Log '▶ إعادة بناء عدادات الأداء'
      $d = Get-PerfDiag
      # 1) العدادات اللي انطفت بالريجستري (برامج التسريع تسوي كذا) نرجّعها
      foreach ($n in $d.disabled) { try { Set-ItemProperty -LiteralPath ('HKLM:\SYSTEM\CurrentControlSet\Services\' + $n + '\Performance') -Name 'Disable Performance Counters' -Value 0 -ErrorAction Stop; Log "  شغّلت عدادات $n" } catch { Warn "  ${n}: $($_.Exception.Message)" } }
      # 2) خدمة WMI Performance Adapter (منها يقرا Task Manager و WMI)
      foreach ($n in $d.svcOff) { try { Set-Service $n -StartupType Manual -ErrorAction Stop; Log "  رجّعت خدمة $n (Manual)" } catch { Warn "  ${n}: $($_.Exception.Message)" } }
      # 3) إعادة بناء قوائم العدادات
      if ($d.perflibOff) { try { Set-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Perflib' -Name 'Disable Performance Counters' -Value 0 -ErrorAction Stop; Log '  شغّلت العدادات العامة (Perflib)' } catch { Warn "  Perflib: $($_.Exception.Message)" } }
      foreach ($dir in @('System32', 'SysWOW64')) { $out = (Invoke-Cmd "cd /d %windir%\$dir && lodctr /R") | Out-String; Log ("  lodctr /R ($dir): " + ($out -replace '\s+', ' ').Trim()) }
      foreach ($svc in @('PerfOS', 'PerfProc', 'PerfDisk', 'PerfNet', 'Tcpip')) { Invoke-Cmd "lodctr /E:$svc" | Out-Null }
      Invoke-Cmd 'winmgmt /resyncperf' | Out-Null
      Invoke-Cmd 'wmiadap /f' | Out-Null
      try { Start-Service WmiApSrv -ErrorAction SilentlyContinue } catch {}
      Start-Sleep -Seconds 2
    }
    'update' {
      Log '▶ إعادة ضبط Windows Update'
      foreach ($sn in @('wuauserv', 'bits', 'cryptsvc', 'msiserver')) { Stop-Service $sn -Force -ErrorAction SilentlyContinue }
      $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
      foreach ($p in @("$env:windir\SoftwareDistribution", "$env:windir\System32\catroot2")) {
        if (Test-Path $p) { try { Rename-Item $p ((Split-Path $p -Leaf) + ".bak-$stamp") -ErrorAction Stop; Log "  أعدت تسمية $p (نسخة احتياطية)" } catch { Warn "  ما قدرت أعيد تسمية ${p}: $($_.Exception.Message)" } }
      }
      $types = @{ wuauserv = 'Manual'; bits = 'Manual'; cryptsvc = 'Automatic'; msiserver = 'Manual' }
      foreach ($k in $types.Keys) { try { Set-Service $k -StartupType $types[$k] -ErrorAction Stop } catch {} }
      foreach ($sn in @('cryptsvc', 'bits', 'wuauserv')) { Start-Service $sn -ErrorAction SilentlyContinue }
      try { Start-Process "$env:windir\System32\UsoClient.exe" -ArgumentList 'StartScan' -WindowStyle Hidden } catch {}
      Log '  شغّلت الخدمات وطلبت بحث جديد عن التحديثات'
    }
    'network' {
      Log '▶ إصلاح الشبكة'
      Invoke-Cmd 'ipconfig /flushdns' | Out-Null
      Invoke-Cmd 'netsh winsock reset' | Out-Null
      Invoke-Cmd 'netsh int ip reset' | Out-Null
      Log '  مسحت كاش DNS وأعدت ضبط Winsock و TCP/IP — يحتاج ريستارت'
    }
    'time' {
      Log '▶ ضبط ساعة الجهاز'
      Set-Service w32time -StartupType Automatic -ErrorAction SilentlyContinue
      Start-Service w32time -ErrorAction SilentlyContinue
      Invoke-Cmd 'w32tm /config /manualpeerlist:"time.windows.com,0x9 time.cloudflare.com,0x9" /syncfromflags:manual /update' | Out-Null
      Invoke-Cmd 'w32tm /resync /force' | Out-Null
    }
    'store' {
      Log '▶ إصلاح متجر مايكروسوفت'
      $pkg = Get-AppxPackage -AllUsers -Name Microsoft.WindowsStore -ErrorAction SilentlyContinue | Select-Object -First 1
      if ($pkg) { try { Add-AppxPackage -DisableDevelopmentMode -Register (Join-Path $pkg.InstallLocation 'AppXManifest.xml') -ErrorAction Stop; Log '  أعدت تسجيل المتجر' } catch { Warn "  $($_.Exception.Message)" } }
      Start-Process "$env:windir\System32\wsreset.exe" -WindowStyle Hidden -Wait -ErrorAction SilentlyContinue
      Log '  مسحت كاش المتجر (wsreset)'
    }
    'defender' {
      Log '▶ تحديث تعريفات Windows Defender'
      try { Update-MpSignature -ErrorAction Stop; Log '  تم' } catch { Warn "  $($_.Exception.Message)" }
    }
    'iconcache' {
      Log '▶ إعادة بناء كاش الأيقونات والصور المصغرة'
      Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
      Start-Sleep -Milliseconds 800
      $dir = Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Explorer'
      $n = 0; foreach ($f in (Get-ChildItem $dir -Filter '*cache*.db' -Force -ErrorAction SilentlyContinue)) { try { Remove-Item $f.FullName -Force -ErrorAction Stop; $n++ } catch {} }
      Start-Process explorer.exe
      Log "  حذفت $n ملف كاش، والويندوز بيبنيها من جديد"
    }
    'search' {
      Log '▶ إعادة بناء فهرس البحث'
      Stop-Service WSearch -Force -ErrorAction SilentlyContinue
      Set-RegValue 'HKLM\SOFTWARE\Microsoft\Windows Search' 'SetupCompletedSuccessfully' 'DWORD' 0
      Start-Service WSearch -ErrorAction SilentlyContinue
      Log '  الفهرس بينبني من جديد بالخلفية (ياخذ وقت حسب عدد ملفاتك)'
    }
    'events' { Log '  هذا فحص بس — شوف التفاصيل لمعرفة السبب'; }
  }
  $after = $null
  try { $after = Test-RepairComponent $id } catch { $after = RC 'unknown' $_.Exception.Message }
  Emit 'repairfix' (@{ id = $id; after = $after } | ConvertTo-Json -Compress -Depth 4)
}
