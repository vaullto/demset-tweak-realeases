﻿# سكربت تركيب التحديث — ينشحن داخل ملف التحديث نفسه، فأي إصلاح له يوصل مع التحديث.
# يطلع نافذة صغيرة فيها شريط تقدّم (0 ← 100٪)، يبدّل الملفات مع نسخة احتياطية، يتأكد إنها انكتبت صح، ويشغّل البرنامج.
param([string]$res, [string]$exe, [string]$tmp, [string]$log, [int]$mainPid)
$ErrorActionPreference = 'Stop'
function L($m) { "$(Get-Date -Format 'HH:mm:ss') $m" | Out-File $log -Append -Encoding utf8 }
$root = Split-Path -Parent $res
L "updater v2: root=$root"

# ---------- نافذة التقدّم ----------
$ui = $null
try {
  Add-Type -AssemblyName System.Windows.Forms, System.Drawing
  [System.Windows.Forms.Application]::EnableVisualStyles()
  $f = New-Object System.Windows.Forms.Form
  $f.Text = 'Demset Tweaks'; $f.Size = New-Object System.Drawing.Size(420, 170); $f.StartPosition = 'CenterScreen'
  $f.FormBorderStyle = 'FixedDialog'; $f.MaximizeBox = $false; $f.MinimizeBox = $false; $f.ControlBox = $false; $f.TopMost = $true
  $f.BackColor = [System.Drawing.Color]::FromArgb(13, 7, 32); $f.ForeColor = [System.Drawing.Color]::FromArgb(242, 238, 255)
  $f.RightToLeft = 'Yes'; $f.RightToLeftLayout = $true
  try { $f.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($exe) } catch {}
  $t = New-Object System.Windows.Forms.Label; $t.Text = 'يحدّث Demset Tweaks…'; $t.Font = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
  $t.AutoSize = $false; $t.Size = New-Object System.Drawing.Size(380, 28); $t.Location = New-Object System.Drawing.Point(16, 14); $f.Controls.Add($t)
  $s = New-Object System.Windows.Forms.Label; $s.Text = 'يجهّز…'; $s.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
  $s.ForeColor = [System.Drawing.Color]::FromArgb(174, 166, 208); $s.AutoSize = $false; $s.Size = New-Object System.Drawing.Size(300, 22); $s.Location = New-Object System.Drawing.Point(16, 48); $f.Controls.Add($s)
  $pc = New-Object System.Windows.Forms.Label; $pc.Text = '0%'; $pc.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
  $pc.ForeColor = [System.Drawing.Color]::FromArgb(62, 230, 200); $pc.AutoSize = $false; $pc.TextAlign = 'MiddleLeft'; $pc.Size = New-Object System.Drawing.Size(70, 22); $pc.Location = New-Object System.Drawing.Point(326, 48); $f.Controls.Add($pc)
  $pb = New-Object System.Windows.Forms.ProgressBar; $pb.Minimum = 0; $pb.Maximum = 100; $pb.Value = 0; $pb.Style = 'Continuous'
  $pb.Size = New-Object System.Drawing.Size(380, 16); $pb.Location = New-Object System.Drawing.Point(16, 82); $f.Controls.Add($pb)
  $f.Show(); [System.Windows.Forms.Application]::DoEvents()
  $ui = @{ f = $f; s = $s; pb = $pb; pc = $pc; t = $t }
} catch { L "ui: $($_.Exception.Message)" }
function P([int]$p, [string]$msg) {
  L "$p% $msg"
  if (-not $ui) { return }
  try { $ui.pb.Value = [Math]::Min(100, [Math]::Max(0, $p)); $ui.pc.Text = "$p%"; $ui.s.Text = $msg; [System.Windows.Forms.Application]::DoEvents() } catch {}
}
function Pause-UI([int]$ms) { $end = (Get-Date).AddMilliseconds($ms); while ((Get-Date) -lt $end) { if ($ui) { try { [System.Windows.Forms.Application]::DoEvents() } catch {} }; Start-Sleep -Milliseconds 50 } }

# ---------- 1) نسكّر كل شي شغّال من مجلد البرنامج ----------
P 5 'يقفل البرنامج…'
$deadline = (Get-Date).AddSeconds(20)
do {
  $procs = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessId -ne $PID -and (($_.ExecutablePath -and $_.ExecutablePath.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) -or ($_.CommandLine -and $_.CommandLine.IndexOf($res, [StringComparison]::OrdinalIgnoreCase) -ge 0)) })
  if (-not $procs.Count) { break }
  if ((Get-Date) -gt $deadline.AddSeconds(-14)) { foreach ($p in $procs) { try { Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop; L "killed $($p.Name) $($p.ProcessId)" } catch {} } }
  Pause-UI 500
} while ((Get-Date) -lt $deadline)
Pause-UI 800
P 15 'يتأكد من الملفات…'

function Retry([string]$what, [scriptblock]$b) { for ($i = 0; $i -lt 15; $i++) { try { & $b; return } catch { if ($i -eq 14) { L "FAILED $what : $($_.Exception.Message)"; throw }; Pause-UI 700 } } }
function Same([string]$a, [string]$b) { try { return (Get-FileHash -LiteralPath $a -Algorithm SHA256).Hash -eq (Get-FileHash -LiteralPath $b -Algorithm SHA256).Hash } catch { return $false } }

$asarNew = Join-Path $tmp 'app.asar'; $asarDst = Join-Path $res 'app.asar'
$ok = $false; $why = ''; $backedUp = $false
$bak = Join-Path $res '_update_backup'
try {
  if (-not (Test-Path -LiteralPath $asarNew)) { throw 'ملف التحديث ناقص (ما فيه app.asar)' }
  # ---------- 2) نسخة احتياطية ----------
  P 25 'ياخذ نسخة احتياطية…'
  if (Test-Path $bak) { Remove-Item $bak -Recurse -Force -ErrorAction SilentlyContinue }
  New-Item -ItemType Directory -Path $bak -Force | Out-Null
  if (Test-Path $asarDst) { Copy-Item $asarDst $bak -Force }
  if (Test-Path (Join-Path $res 'engine')) { Copy-Item (Join-Path $res 'engine') (Join-Path $bak 'engine') -Recurse -Force }
  $backedUp = $true
  L 'backup ok'
  # ---------- 3) مجلد app القديم ----------
  # Electron يقرأ resources\app قبل app.asar — لو ظل موجود، البرنامج يشتغل على النسخة القديمة مهما بدّلنا app.asar.
  $appDir = Join-Path $res 'app'
  if (Test-Path -LiteralPath $appDir) {
    P 35 'يشيل ملفات النسخة القديمة…'
    $old = Join-Path $res ('_old_app_' + (Get-Date -Format 'yyyyMMddHHmmss'))
    Retry 'rename app' { Rename-Item -LiteralPath $appDir -NewName (Split-Path -Leaf $old) -Force }
    Remove-Item -LiteralPath $old -Recurse -Force -ErrorAction SilentlyContinue
    if (Test-Path -LiteralPath $appDir) { throw 'مجلد resources\app القديم ما انشال — البرنامج بيظل على النسخة القديمة' }
    L 'old app folder removed'
  }
  # ---------- 4) البرنامج نفسه ----------
  P 50 'ينسخ البرنامج الجديد…'
  Retry 'app.asar' { Copy-Item $asarNew $asarDst -Force; if (-not (Same $asarNew $asarDst)) { throw 'الملف انكتب ناقص' } }
  L 'app.asar ok (hash match)'
  # ---------- 5) المحرك ----------
  P 75 'ينسخ المحرك…'
  if (-not (Test-Path (Join-Path $res 'engine'))) { New-Item -ItemType Directory -Path (Join-Path $res 'engine') -Force | Out-Null }
  Get-ChildItem (Join-Path $tmp 'engine') -File | ForEach-Object { $fl = $_; Retry "engine\$($fl.Name)" { Copy-Item $fl.FullName (Join-Path $res "engine\$($fl.Name)") -Force } }
  L 'engine ok'
  Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
  Get-ChildItem -LiteralPath $res -Directory -Filter '_old_app_*' -ErrorAction SilentlyContinue | ForEach-Object { Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue }
  $ok = $true
  L 'ok'
} catch {
  $why = $_.Exception.Message
  L "fail: $why — restoring"
  P 90 'صار خطأ — يرجّع النسخة السابقة…'
  if ($backedUp) { # نرجّع بس من نسخة أخذناها هالمرة — مو من تحديث قديم
    try { if (Test-Path (Join-Path $bak 'app.asar')) { Copy-Item (Join-Path $bak 'app.asar') $asarDst -Force } } catch {}
  try { if (Test-Path (Join-Path $bak 'engine')) { Copy-Item (Join-Path $bak 'engine\*') (Join-Path $res 'engine') -Force } } catch {}
  }
}
# نتيجة يقراها البرنامج أول ما يفتح (عشان يقول للمستخدم لو التحديث ما انطبق ووش السبب)
try { (@{ ok = $ok; error = $why; at = (Get-Date -Format s) } | ConvertTo-Json -Compress) | Out-File (Join-Path (Split-Path -Parent $log) 'result.json') -Encoding utf8 } catch {}
if ($ok) { P 100 'خلص — يشغّل البرنامج…' } else { P 100 'ما انطبق التحديث — يشغّل النسخة السابقة' }
Pause-UI 900
Start-Process -FilePath $exe
L 'started app'
if ($ui) { try { $ui.f.Close() } catch {} }
