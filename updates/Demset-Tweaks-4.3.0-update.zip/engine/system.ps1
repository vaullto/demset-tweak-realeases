﻿# =============================================================
#  Demset Tweaks — قراءات النظام الدقيقة، الحساسات، العمليات، والفحص الشامل
#  كل القراءات هنا ما تعتمد على Performance Counters (عشان تشتغل حتى لو خربانة)
# =============================================================

if (-not ('PolarSys' -as [type])) {
  Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;

public static class PolarSys {
  [DllImport("kernel32.dll")] static extern bool GetSystemTimes(out long idle, out long kernel, out long user);
  [StructLayout(LayoutKind.Sequential)] struct MS { public uint len; public uint load; public ulong total, avail, tpf, apf, tv, av, aev; }
  [DllImport("kernel32.dll")] static extern bool GlobalMemoryStatusEx(ref MS m);
  [DllImport("ntdll.dll")] static extern int NtQuerySystemInformation(int cls, IntPtr buf, int len, out int ret);
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);

  // idle, kernel(includes idle), user  — 100ns units, summed over all CPUs
  public static long[] Times() { long i, k, u; GetSystemTimes(out i, out k, out u); return new long[] { i, k, u }; }
  public static double CpuBetween(long[] a, long[] b) {
    long idle = b[0] - a[0], tot = (b[1] - a[1]) + (b[2] - a[2]);
    if (tot <= 0) return 0;
    return Math.Max(0, Math.Min(100, 100.0 * (tot - idle) / tot));
  }
  // total, available, load%
  public static ulong[] Mem() { var m = new MS(); m.len = (uint)Marshal.SizeOf(typeof(MS)); GlobalMemoryStatusEx(ref m); return new ulong[] { m.total, m.avail, m.load }; }

  // SystemProcessorPerformanceInformation (class 8): idle, kernel, user, dpc, interrupt, interruptCount (summed)
  public static long[] ProcPerf() {
    const int sz = 48; int max = 1024; IntPtr buf = Marshal.AllocHGlobal(sz * max);
    try {
      int ret; int st = NtQuerySystemInformation(8, buf, sz * max, out ret);
      if (st != 0) return null;
      int n = ret / sz; long[] r = new long[6];
      for (int i = 0; i < n; i++) {
        IntPtr p = new IntPtr(buf.ToInt64() + (long)i * sz);
        r[0] += Marshal.ReadInt64(p, 0); r[1] += Marshal.ReadInt64(p, 8); r[2] += Marshal.ReadInt64(p, 16);
        r[3] += Marshal.ReadInt64(p, 24); r[4] += Marshal.ReadInt64(p, 32); r[5] += (uint)Marshal.ReadInt32(p, 40);
      }
      return r;
    } finally { Marshal.FreeHGlobal(buf); }
  }
  public static uint FgPid() { uint p; GetWindowThreadProcessId(GetForegroundWindow(), out p); return p; }
  [StructLayout(LayoutKind.Sequential)] struct RECT { public int l, t, r, b; }
  [StructLayout(LayoutKind.Sequential)] struct MONINFO { public int cb; public RECT mon, work; public uint flags; }
  [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] static extern IntPtr MonitorFromWindow(IntPtr h, uint f);
  [DllImport("user32.dll")] static extern bool GetMonitorInfo(IntPtr m, ref MONINFO mi);
  [DllImport("user32.dll")] static extern IntPtr GetShellWindow();
  [DllImport("user32.dll")] static extern IntPtr GetDesktopWindow();
  [DllImport("kernel32.dll")] static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
  [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] static extern bool QueryFullProcessImageName(IntPtr h, uint flags, System.Text.StringBuilder sb, ref uint size);
  [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
  // مسار البرنامج بأقل صلاحية (يشتغل حتى مع الألعاب المحمية بـ Anti-cheat)
  public static string ExePath(uint pid) {
    IntPtr h = OpenProcess(0x1000, false, pid); if (h == IntPtr.Zero) return "";
    try { var sb = new System.Text.StringBuilder(1024); uint n = 1024; return QueryFullProcessImageName(h, 0, sb, ref n) ? sb.ToString() : ""; } finally { CloseHandle(h); }
  }
  // النافذة اللي قدامك مغطية الشاشة كاملة؟ (فل سكرين أو Borderless)
  public static bool FgFull() {
    IntPtr h = GetForegroundWindow();
    if (h == IntPtr.Zero || h == GetShellWindow() || h == GetDesktopWindow()) return false;
    RECT r; if (!GetWindowRect(h, out r)) return false;
    var mi = new MONINFO(); mi.cb = Marshal.SizeOf(mi);
    if (!GetMonitorInfo(MonitorFromWindow(h, 2), ref mi)) return false;
    return r.l <= mi.mon.l && r.t <= mi.mon.t && r.r >= mi.mon.r && r.b >= mi.mon.b;
  }
}

public static class PolarResolver {
  static string dir;
  public static void Install(string d) {
    if (dir != null) return;
    dir = d;
    AppDomain.CurrentDomain.AssemblyResolve += (s, e) => {
      var n = new AssemblyName(e.Name).Name;
      var p = Path.Combine(dir, n + ".dll");
      return File.Exists(p) ? Assembly.LoadFrom(p) : null;
    };
  }
}
'@
}

# ---------------- CPU / DPC sampling ----------------
function Measure-CpuWindow([int]$ms = 1000) {
  $t0 = [PolarSys]::Times(); $p0 = [PolarSys]::ProcPerf()
  Start-Sleep -Milliseconds $ms
  $t1 = [PolarSys]::Times(); $p1 = [PolarSys]::ProcPerf()
  $r = @{ cpu = [math]::Round([PolarSys]::CpuBetween($t0, $t1), 2) }
  if ($p0 -and $p1) {
    $tot = ($p1[1] - $p0[1]) + ($p1[2] - $p0[2])
    if ($tot -gt 0) {
      $r.cpuNt = [math]::Round(100 * ($tot - ($p1[0] - $p0[0])) / $tot, 2)
      $r.dpc = [math]::Round(100 * ($p1[3] - $p0[3]) / $tot, 3)
      $r.intr = [math]::Round(100 * ($p1[4] - $p0[4]) / $tot, 3)
      $r.ints = [math]::Round(($p1[5] - $p0[5]) / ($ms / 1000.0))
    }
  }
  return $r
}

# ---------------- LibreHardwareMonitor (حرارة حقيقية) ----------------
$script:lhm = $null
$script:lhmErr = $null
function Test-PawnIO { return (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\PawnIO') }
function Init-Lhm {
  if ($script:lhm) { return $script:lhm }
  $binRoot = if ($env:DEMSET_BIN_PATH) { $env:DEMSET_BIN_PATH } else { Join-Path $PSScriptRoot '..\bin' }
  $dir = Join-Path $binRoot 'lhm'
  if (-not (Test-Path (Join-Path $dir 'LibreHardwareMonitorLib.dll'))) { $script:lhmErr = 'lhm-missing'; return $null }
  try {
    $dir = (Resolve-Path $dir).Path
    [PolarResolver]::Install($dir)
    [void][Reflection.Assembly]::LoadFrom((Join-Path $dir 'LibreHardwareMonitorLib.dll'))
    $c = New-Object LibreHardwareMonitor.Hardware.Computer
    $c.IsCpuEnabled = $true
    $c.IsGpuEnabled = $true
    $c.Open()
    $script:lhm = $c
    return $c
  } catch { $script:lhmErr = $_.Exception.GetBaseException().Message; return $null }
}
function Read-LhmTemps {
  $c = Init-Lhm
  if (-not $c) { return $null }
  $o = @{ cpuSensors = @(); gpuSensors = @() }
  foreach ($h in $c.Hardware) {
    try { $h.Update() } catch {}
    $type = "$($h.HardwareType)"
    foreach ($s in $h.Sensors) {
      if ("$($s.SensorType)" -ne 'Temperature' -or $null -eq $s.Value) { continue }
      $v = [math]::Round([double]$s.Value, 1)
      if ($type -eq 'Cpu') { $o.cpuSensors += @{ n = "$($s.Name)"; v = $v } }
      elseif ($type -like 'Gpu*') { $o.gpuSensors += @{ n = "$($s.Name)"; v = $v } }
    }
  }
  $pick = $o.cpuSensors | Where-Object { $_.n -match 'Package|Tctl|Tdie' } | Select-Object -First 1
  if (-not $pick) { $pick = $o.cpuSensors | Where-Object { $_.n -match 'Max|Average' } | Select-Object -First 1 }
  if (-not $pick) { $pick = $o.cpuSensors | Sort-Object { $_.v } -Descending | Select-Object -First 1 }
  if ($pick -and $pick.v -gt 0) { $o.cpu = $pick.v; $o.cpuName = $pick.n }
  $g = $o.gpuSensors | Where-Object { $_.n -match 'Core|GPU' } | Select-Object -First 1
  if ($g -and $g.v -gt 0) { $o.gpu = $g.v }
  return $o
}
function Read-LhmWmiTemp {
  foreach ($ns in @('root/LibreHardwareMonitor', 'root/OpenHardwareMonitor')) {
    try {
      $sens = @(Get-CimInstance -Namespace $ns -ClassName Sensor -Filter "SensorType='Temperature'" -ErrorAction Stop | Where-Object { $_.Identifier -match 'cpu' })
      $pick = $sens | Where-Object { $_.Name -match 'Package|Tctl|Tdie' } | Select-Object -First 1
      if (-not $pick) { $pick = $sens | Sort-Object Value -Descending | Select-Object -First 1 }
      if ($pick -and $pick.Value -gt 0) { return [math]::Round([double]$pick.Value, 1) }
    } catch {}
  }
  return $null
}

# ---------------- العمليات ----------------
$script:CRITICAL = @('system', 'idle', 'registry', 'smss', 'csrss', 'wininit', 'winlogon', 'services', 'lsass', 'lsaiso', 'svchost', 'dwm', 'explorer',
  'fontdrvhost', 'memory compression', 'secure system', 'msmpeng', 'nissrv', 'securityhealthservice', 'securityhealthsystray', 'sgrmbroker', 'audiodg',
  'ctfmon', 'sihost', 'taskhostw', 'runtimebroker', 'startmenuexperiencehost', 'shellexperiencehost', 'searchhost', 'searchindexer', 'textinputhost',
  'conhost', 'wudfhost', 'dllhost', 'spoolsv', 'wmiprvse', 'lsm', 'trustedinstaller', 'tiworker', 'mpdefendercoreservice', 'smartscreen', 'applicationframehost',
  'systemsettings', 'polar tweaks', 'demset tweaks', 'presentmon', 'powershell', 'nvidia-smi', 'nvcontainer', 'nvdisplay.container', 'atiesrxx', 'atieclxx', 'igfxem', 'dashost',
  'unsecapp', 'wlanext', 'uihost', 'lockapp', 'logonui', 'userinit', 'csrss', 'searchprotocolhost', 'searchfilterhost', 'mousocoreworker', 'usocoreworker')

function Get-ProcList {
  $n = [Environment]::ProcessorCount
  $before = @{}
  foreach ($p in (Get-Process)) { try { $before[$p.Id] = $p.TotalProcessorTime.TotalMilliseconds } catch {} }
  $sw = [Diagnostics.Stopwatch]::StartNew()
  Start-Sleep -Milliseconds 1000
  $procs = Get-Process
  $el = $sw.Elapsed.TotalMilliseconds
  $wmi = @{}
  foreach ($w in (Get-CimInstance Win32_Process -Property ProcessId, ParentProcessId, ExecutablePath, CommandLine -ErrorAction SilentlyContinue)) { $wmi[[int]$w.ProcessId] = $w }
  $svcByPid = @{}
  foreach ($s in (Get-CimInstance Win32_Service -Filter "State='Running'" -Property Name, DisplayName, ProcessId -ErrorAction SilentlyContinue)) {
    if (-not $svcByPid.ContainsKey([int]$s.ProcessId)) { $svcByPid[[int]$s.ProcessId] = @() }
    $svcByPid[[int]$s.ProcessId] += "$($s.DisplayName)"
  }
  $vi = @{}
  $win = $env:windir.ToLower()
  $self = $PID
  $list = @()
  foreach ($p in $procs) {
    if ($p.Id -eq 0 -or $p.Id -eq 4) { continue }
    $cpu = 0
    try { if ($before.ContainsKey($p.Id)) { $cpu = ($p.TotalProcessorTime.TotalMilliseconds - $before[$p.Id]) / ($el * $n) * 100 } } catch {}
    $w = $wmi[[int]$p.Id]
    $path = if ($w) { "$($w.ExecutablePath)" } else { '' }
    $company = ''; $desc = ''
    if ($path) {
      if (-not $vi.ContainsKey($path)) { try { $f = [Diagnostics.FileVersionInfo]::GetVersionInfo($path); $vi[$path] = @("$($f.CompanyName)".Trim(), "$($f.FileDescription)".Trim()) } catch { $vi[$path] = @('', '') } }
      $company = $vi[$path][0]; $desc = $vi[$path][1]
    }
    $name = $p.ProcessName
    $isWin = $path -and $path.ToLower().StartsWith($win)
    $critical = ($script:CRITICAL -contains $name.ToLower()) -or ($p.Id -eq $self) -or ($p.SessionId -eq 0 -and $isWin) -or (-not $path -and $p.SessionId -eq 0)
    $list += @{
      pid = $p.Id; name = $name; path = $path; cmd = $(if ($w) { "$($w.CommandLine)" } else { '' }); parent = $(if ($w) { [int]$w.ParentProcessId } else { 0 })
      cpu = [math]::Round([math]::Max(0, $cpu), 2); ws = [math]::Round($p.WorkingSet64 / 1MB, 1); priv = [math]::Round($p.PrivateMemorySize64 / 1MB, 1)
      company = $company; desc = $desc; session = $p.SessionId; services = @($svcByPid[[int]$p.Id] | Where-Object { $_ }); system = [bool]$isWin; critical = [bool]$critical
      priority = $(try { "$($p.PriorityClass)" } catch { '' })
    }
  }
  return $list
}

function Stop-Procs($items) {
  $done = @()
  foreach ($it in @($items)) {
    try {
      $p = Get-Process -Id $it.pid -ErrorAction Stop
      if ($script:CRITICAL -contains $p.ProcessName.ToLower()) { Warn ("  محمي: " + $p.ProcessName); continue }
      Stop-Process -Id $it.pid -Force -ErrorAction Stop
      $done += @{ pid = $it.pid; name = $it.name; path = $it.path; cmd = $it.cmd }
      Log ("  أنهيت " + $it.name + " (" + $it.pid + ")")
    } catch { Warn ("  ما انتهى " + $it.name + ": " + $_.Exception.Message) }
  }
  Emit 'killed' (ConvertTo-Json -InputObject @($done) -Compress -Depth 4)
}

# مراقبة العمليات المباشرة: تحدّث كل ثانيتين بدون ما تعيد قراءة كل شي من WMI كل مرة
function Start-ProcMon($cfg) {
  $n = [Environment]::ProcessorCount
  $iv = [int]$cfg.interval; if ($iv -lt 1000) { $iv = 2000 }
  $meta = @{}; $vi = @{}; $svcByPid = @{}; $svcAt = [DateTime]::MinValue
  $win = $env:windir.ToLower(); $self = $PID
  $prev = @{}; $sw = [Diagnostics.Stopwatch]::StartNew(); $lastMs = 0
  while ($true) {
    $procs = Get-Process
    $nowMs = $sw.Elapsed.TotalMilliseconds; $el = [math]::Max(1, $nowMs - $lastMs); $lastMs = $nowMs
    # بيانات ثابتة (المسار والأوامر) نقراها بس للعمليات الجديدة
    $new = @($procs | Where-Object { -not $meta.ContainsKey($_.Id) })
    if ($new.Count) {
      foreach ($w in (Get-CimInstance Win32_Process -Property ProcessId, ParentProcessId, ExecutablePath, CommandLine -ErrorAction SilentlyContinue)) {
        $id = [int]$w.ProcessId
        if (-not $meta.ContainsKey($id)) { $meta[$id] = @{ path = "$($w.ExecutablePath)"; cmd = "$($w.CommandLine)"; parent = [int]$w.ParentProcessId } }
      }
    }
    if (([DateTime]::Now - $svcAt).TotalSeconds -gt 15) {
      $svcByPid = @{}
      foreach ($sv in (Get-CimInstance Win32_Service -Filter "State='Running'" -Property DisplayName, ProcessId -ErrorAction SilentlyContinue)) {
        $k = [int]$sv.ProcessId; if (-not $svcByPid.ContainsKey($k)) { $svcByPid[$k] = @() }; $svcByPid[$k] += "$($sv.DisplayName)"
      }
      $svcAt = [DateTime]::Now
    }
    $alive = @{}; $list = @()
    foreach ($p in $procs) {
      if ($p.Id -eq 0 -or $p.Id -eq 4) { continue }
      $alive[$p.Id] = 1
      $cpuMs = 0; try { $cpuMs = $p.TotalProcessorTime.TotalMilliseconds } catch {}
      $cpu = $null
      if ($prev.ContainsKey($p.Id)) { $cpu = [math]::Round([math]::Max(0, ($cpuMs - $prev[$p.Id]) / ($el * $n) * 100), 2) }
      $prev[$p.Id] = $cpuMs
      $m = $meta[$p.Id]; $path = $(if ($m) { $m.path } else { '' })
      $company = ''; $desc = ''
      if ($path) {
        if (-not $vi.ContainsKey($path)) { try { $f = [Diagnostics.FileVersionInfo]::GetVersionInfo($path); $vi[$path] = @("$($f.CompanyName)".Trim(), "$($f.FileDescription)".Trim()) } catch { $vi[$path] = @('', '') } }
        $company = $vi[$path][0]; $desc = $vi[$path][1]
      }
      $name = $p.ProcessName
      $isWin = $path -and $path.ToLower().StartsWith($win)
      $critical = ($script:CRITICAL -contains $name.ToLower()) -or ($p.Id -eq $self) -or ($p.SessionId -eq 0 -and $isWin) -or (-not $path -and $p.SessionId -eq 0)
      $prio = ''; try { $prio = "$($p.PriorityClass)" } catch {}
      $list += @{ pid = $p.Id; name = $name; path = $path; cmd = $(if ($m) { $m.cmd } else { '' }); parent = $(if ($m) { $m.parent } else { 0 })
        cpu = $cpu; ws = [math]::Round($p.WorkingSet64 / 1MB, 1); priv = [math]::Round($p.PrivateMemorySize64 / 1MB, 1)
        company = $company; desc = $desc; session = $p.SessionId; services = @($svcByPid[[int]$p.Id] | Where-Object { $_ }); system = [bool]$isWin; critical = [bool]$critical; priority = $prio }
    }
    foreach ($k in @($prev.Keys)) { if (-not $alive.ContainsKey($k)) { $prev.Remove($k); $meta.Remove($k) } }
    Emit 'proclive' (ConvertTo-Json -InputObject @($list) -Compress -Depth 4)
    Start-Sleep -Milliseconds $iv
  }
}

function Split-CmdArgs([string]$cmd, [string]$path) {
  if (-not $cmd) { return '' }
  $c = $cmd.Trim()
  if ($c.StartsWith('"')) { $e = $c.IndexOf('"', 1); if ($e -gt 0) { return $c.Substring($e + 1).Trim() } }
  if ($path -and $c.ToLower().StartsWith($path.ToLower())) { return $c.Substring($path.Length).Trim() }
  $i = $c.IndexOf(' '); if ($i -gt 0) { return $c.Substring($i + 1).Trim() }
  return ''
}
# يشغّل البرنامج بصلاحيات المستخدم العادية (مو كمسؤول، مثل ما كان شغّال قبل)
function Start-AsUser([string]$path, [string]$argStr) {
  if (-not $argStr) {
    # explorer يفتح الملف من جلسة المستخدم العادية
    Start-Process -FilePath "$env:windir\explorer.exe" -ArgumentList ('"' + $path + '"')
    return
  }
  # مع وسائط: مهمة مجدولة مؤقتة بصلاحيات محدودة لنفس المستخدم
  $tn = 'DemsetTweaksRestore_' + [guid]::NewGuid().ToString('N').Substring(0, 8)
  try {
    $act = New-ScheduledTaskAction -Execute $path -Argument $argStr -WorkingDirectory (Split-Path $path)
    $usr = (Get-CimInstance Win32_ComputerSystem).UserName
    if (-not $usr) { $usr = "$env:USERDOMAIN\$env:USERNAME" }
    $pr = New-ScheduledTaskPrincipal -UserId $usr -LogonType Interactive -RunLevel Limited
    Register-ScheduledTask -TaskName $tn -Action $act -Principal $pr -Force | Out-Null
    Start-ScheduledTask -TaskName $tn
    Start-Sleep -Milliseconds 800
  } catch {
    Start-Process -FilePath $path -ArgumentList $argStr -WorkingDirectory (Split-Path $path)
  } finally { Unregister-ScheduledTask -TaskName $tn -Confirm:$false -ErrorAction SilentlyContinue }
}
function Restart-Procs($items) {
  $ok = 0
  foreach ($it in @($items)) {
    if (-not $it.path -or -not (Test-Path -LiteralPath $it.path)) { Warn ("  ما لقيت " + $it.name); continue }
    try {
      Start-AsUser $it.path (Split-CmdArgs $it.cmd $it.path)
      # نتأكد إنه فعلًا اشتغل
      $found = $false
      for ($i = 0; $i -lt 16 -and -not $found; $i++) { Start-Sleep -Milliseconds 250; $found = [bool](Get-Process -ErrorAction SilentlyContinue | Where-Object { try { $_.Path -eq $it.path } catch { $false } } | Select-Object -First 1) }
      if ($found) { $ok++; Log ("  شغّلت " + $it.name) } else { Warn ("  انطلب تشغيل " + $it.name + " بس ما ظهر بالعمليات") }
    } catch { Warn ("  ما اشتغل " + $it.name + ": " + $_.Exception.Message) }
  }
  Emit 'result' ("done:" + $ok + ":0")
}
# الأولوية الدائمة: ويندوز نفسه يطبّقها كل ما اشتغل البرنامج (IFEO PerfOptions\CpuPriorityClass)
$script:IfeoCls = @{ Idle = 1; Normal = 2; High = 3; BelowNormal = 5; AboveNormal = 6 }
function Set-PermPriority($exe, $cls) {
  $k = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\' + $exe + '\PerfOptions'
  $prior = $null; try { $prior = (Get-ItemProperty -LiteralPath $k -Name CpuPriorityClass -ErrorAction Stop).CpuPriorityClass } catch {}
  if (($cls -eq 'remove') -or ($cls -eq 'Normal')) {
    if (Test-Path -LiteralPath $k) { Remove-ItemProperty -LiteralPath $k -Name CpuPriorityClass -ErrorAction SilentlyContinue }
  } else {
    $v = $(if ("$cls" -match '^\d+$') { [int]$cls } else { $script:IfeoCls["$cls"] })
    if (-not $v) { throw "أولوية غير معروفة: $cls" }
    New-Item -Path $k -Force | Out-Null
    New-ItemProperty -LiteralPath $k -Name CpuPriorityClass -Value $v -PropertyType DWord -Force | Out-Null
  }
  Log ('  دايم: ' + $exe + ' -> ' + $cls)
  return $prior
}
function Set-ProcPriority($items) {
  $out = @()
  foreach ($o in @($items)) {
    if ($o.permExe) {
      try { $pp = Set-PermPriority $o.permExe $o.cls; $out += @{ pid = 0; perm = $o.permExe; prior = $(if ($null -ne $pp) { [int]$pp } else { 'remove' }); now = "$($o.cls)" } } catch { Warn ('  ما انحفظت الأولوية الدائمة: ' + $_.Exception.Message) }
      continue
    }
    try {
      $p = Get-Process -Id $o.pid -ErrorAction Stop
      if ($script:CRITICAL -contains $p.ProcessName.ToLower()) { Warn ("  محمي: " + $p.ProcessName); continue }
      $prior = "$($p.PriorityClass)"
      $p.PriorityClass = [Diagnostics.ProcessPriorityClass]"$($o.cls)"
      $now = "$((Get-Process -Id $o.pid).PriorityClass)"
      Log ("  " + $p.ProcessName + " (" + $o.pid + "): " + $prior + " -> " + $now)
      $out += @{ pid = [int]$o.pid; prior = $prior; now = $now }
    } catch { Warn ("  ما تغيرت أولوية " + $o.pid + ": " + $_.Exception.Message) }
  }
  Emit 'prio' (ConvertTo-Json -InputObject @($out) -Compress)
}

# =============================================================
#  الفحص الشامل — يجرب كل شي فعليًا ويقارن بمصادر مستقلة
# =============================================================
function Invoke-SelfTest($cfg) {
  $Results = New-Object System.Collections.ArrayList
  function Add-R($name, $ok, $detail, $data) { [void]$Results.Add(@{ name = $name; ok = $ok; detail = "$detail"; data = $data }); Emit 'progress' (@{ p = [int]($Results.Count * 100 / 19); label = $name } | ConvertTo-Json -Compress) }
  $script:quiet = $true

  # 1) المعالج: 3 مصادر مستقلة على نفس النافذة
  try {
    $perfOk = Test-PerfCounters
    $t0 = [PolarSys]::Times(); $n0 = [PolarSys]::ProcPerf()
    $pt0 = 0.0; foreach ($p in Get-Process) { try { $pt0 += $p.TotalProcessorTime.TotalMilliseconds } catch {} }
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $perfVals = @()
    for ($i = 0; $i -lt 3; $i++) {
      Start-Sleep -Milliseconds 1000
      if ($perfOk) { try { $perfVals += [double](Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'").PercentProcessorTime } catch {} }
    }
    $t1 = [PolarSys]::Times(); $n1 = [PolarSys]::ProcPerf()
    $pt1 = 0.0; foreach ($p in Get-Process) { try { $pt1 += $p.TotalProcessorTime.TotalMilliseconds } catch {} }
    $el = $sw.Elapsed.TotalMilliseconds
    $a = [PolarSys]::CpuBetween($t0, $t1)
    $tot = ($n1[1] - $n0[1]) + ($n1[2] - $n0[2]); $b = 100 * ($tot - ($n1[0] - $n0[0])) / $tot
    $c = [math]::Max(0, ($pt1 - $pt0) / ($el * [Environment]::ProcessorCount) * 100)
    $d = $(if ($perfVals.Count) { ($perfVals | Measure-Object -Average).Average } else { $null })
    $agree = [math]::Abs($a - $b) -lt 3 -and [math]::Abs($a - $c) -lt 8
    Add-R 'CPU usage' $agree ("GetSystemTimes={0:N1}% NtQSI={1:N1}% ProcessSum={2:N1}% PerfCounter={3}" -f $a, $b, $c, $(if ($null -ne $d) { '{0:N1}%' -f $d } else { 'broken' })) @{ getSystemTimes = $a; ntqsi = $b; procSum = $c; perf = $d; perfOk = $perfOk; cores = [Environment]::ProcessorCount }
    $dpcPct = 100 * ($n1[3] - $n0[3]) / $tot
    Add-R 'DPC / interrupts' ($dpcPct -ge 0 -and $dpcPct -lt 50) ("DPC={0:N3}% Interrupt={1:N3}% ints/s={2:N0}" -f $dpcPct, (100 * ($n1[4] - $n0[4]) / $tot), (($n1[5] - $n0[5]) / ($el / 1000))) $null
  } catch { Add-R 'CPU usage' $false $_.Exception.Message $null }

  # 2) الذاكرة
  try {
    $m = [PolarSys]::Mem(); $os = Get-CimInstance Win32_OperatingSystem
    $usedA = ($m[0] - $m[1]) / 1GB; $usedB = ($os.TotalVisibleMemorySize - $os.FreePhysicalMemory) / 1MB
    Add-R 'RAM' ([math]::Abs($usedA - $usedB) -lt 0.6) ("GlobalMemoryStatusEx={0:N2}GB Win32_OperatingSystem={1:N2}GB total={2:N1}GB" -f $usedA, $usedB, ($m[0] / 1GB)) $null
  } catch { Add-R 'RAM' $false $_.Exception.Message $null }

  # 3) كرت الشاشة
  try {
    $smi = Get-Command nvidia-smi.exe -ErrorAction SilentlyContinue
    if ($smi) {
      $l = (& $smi.Source --query-gpu=name,utilization.gpu,temperature.gpu,memory.used,memory.total --format=csv,noheader,nounits 2>&1 | Select-Object -First 1)
      Add-R 'GPU (nvidia-smi)' ([bool]($l -match '\d')) "$l" $null
    } else { Add-R 'GPU (nvidia-smi)' $null 'nvidia-smi غير موجود (مو NVIDIA)' $null }
  } catch { Add-R 'GPU (nvidia-smi)' $false $_.Exception.Message $null }

  # 4) الحرارة
  try {
    $pawn = Test-PawnIO
    $t = Read-LhmTemps
    $wmiT = Read-LhmWmiTemp
    $acpi = @()
    try { $acpi = @(Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature -ErrorAction Stop | ForEach-Object { [math]::Round($_.CurrentTemperature / 10 - 273.15, 1) }) } catch {}
    $ok = $(if ($t -and $t.cpu) { $t.cpu -gt 15 -and $t.cpu -lt 110 } elseif (-not $pawn) { $null } else { $false })
    Add-R 'CPU temperature' $ok ("PawnIO={0} LHM={1} ({2}) LHM-app={3} ACPI={4} err={5}" -f $pawn, $(if ($t) { $t.cpu } else { '-' }), $(if ($t) { $t.cpuName } else { '' }), $wmiT, ($acpi -join ','), $script:lhmErr) @{ sensors = $(if ($t) { $t.cpuSensors } else { @() }); gpuSensors = $(if ($t) { $t.gpuSensors } else { @() }) }
  } catch { Add-R 'CPU temperature' $false $_.Exception.Message $null }

  # 5) تطبيق وتراجع حقيقي على تويك آمن (الريجستري)
  try {
    $ops = @($cfg.regTest)
    $k = $ops[0].k; $n = $ops[0].n
    $before = Get-RegState $k $n
    $bk = @(); foreach ($op in $ops) { $bk += (Invoke-ApplyOp $op) }
    $mid = Get-RegState $k $n
    foreach ($bkRec in $bk) { Invoke-RevertRecord ([pscustomobject]@{ t = $bkRec.t; k = $bkRec.k; n = $bkRec.n; prior = [pscustomobject]$bkRec.prior }) }
    $after = Get-RegState $k $n
    $ok = ("$($mid.value)" -eq "$($ops[0].v)") -and ($after.exists -eq $before.exists) -and ("$($after.value)" -eq "$($before.value)")
    Add-R 'Tweak apply+revert (registry)' $ok ("$n : قبل=$($before.value) بعد التطبيق=$($mid.value) بعد التراجع=$($after.value)") $null
  } catch { Add-R 'Tweak apply+revert (registry)' $false $_.Exception.Message $null }

  # 6) إعداد طاقة: تطبيق وتراجع
  try {
    # "إطفاء الشاشة بعد" موجود في كل خطط الطاقة وما ينخفي — نغيّره ونرجّعه
    $cur = Get-PowerIndex 'SUB_VIDEO' 'VIDEOIDLE'
    if ($null -eq $cur) { Add-R 'Power setting apply+revert' $false 'ما قدرت أقرا إعدادات خطة الطاقة الحالية' $null }
    else {
      $target = [uint32]($cur.ac + 60)
      $rec = Invoke-ApplyOp ([pscustomobject]@{ t = 'pcfg'; s = 'SUB_VIDEO'; n = 'VIDEOIDLE'; ac = $target })
      $mid = Get-PowerIndex 'SUB_VIDEO' 'VIDEOIDLE'
      Invoke-RevertRecord ([pscustomobject]$rec)
      $after = Get-PowerIndex 'SUB_VIDEO' 'VIDEOIDLE'
      Add-R 'Power setting apply+revert' (($mid.ac -eq $target) -and ($after.ac -eq $cur.ac)) ("VIDEOIDLE: قبل=$($cur.ac) بعد=$($mid.ac) تراجع=$($after.ac)") $null
    }
  } catch { Add-R 'Power setting apply+revert' $false $_.Exception.Message $null }

  # 7) بدء التشغيل: إيقاف وتشغيل عنصر تجريبي
  try {
    Set-RegValue 'HKCU\Software\Microsoft\Windows\CurrentVersion\Run' 'DemsetSelfTest' 'SZ' 'C:\Windows\System32\cmd.exe /c exit'
    $script:quiet = $true
    Set-StartupItem ([pscustomobject]@{ hive = 'HKCU'; sub = 'Run'; name = 'DemsetSelfTest'; enabled = $false })
    $off = -not (Get-StartupEnabled 'HKCU' 'Run' 'DemsetSelfTest')
    Set-StartupItem ([pscustomobject]@{ hive = 'HKCU'; sub = 'Run'; name = 'DemsetSelfTest'; enabled = $true })
    $on = Get-StartupEnabled 'HKCU' 'Run' 'DemsetSelfTest'
    $found = @(Get-StartupItemsData | Where-Object { $_.name -eq 'DemsetSelfTest' }).Count -eq 1
    Remove-RegValue 'HKCU\Software\Microsoft\Windows\CurrentVersion\Run' 'DemsetSelfTest'
    Remove-RegValue ('HKCU\' + $script:SA + 'Run') 'DemsetSelfTest'
    Add-R 'Startup disable/enable' ($off -and $on -and $found) ("ظهر في القائمة=$found اتطفى=$off رجع=$on") $null
  } catch { Add-R 'Startup disable/enable' $false $_.Exception.Message $null }

  # 8) العمليات: قائمة + تغيير أولوية + إنهاء على عملية تجريبية
  try {
    $list = Get-ProcList
    $p = Start-Process -FilePath "$env:windir\System32\PING.EXE" -ArgumentList '-n 60 127.0.0.1' -WindowStyle Hidden -PassThru
    Start-Sleep -Milliseconds 300
    $pr0 = "$((Get-Process -Id $p.Id).PriorityClass)"
    (Get-Process -Id $p.Id).PriorityClass = 'BelowNormal'
    $pr1 = "$((Get-Process -Id $p.Id).PriorityClass)"
    (Get-Process -Id $p.Id).PriorityClass = $pr0
    $script:quiet = $true
    Stop-Procs @(@{ pid = $p.Id; name = 'PING'; path = $p.Path; cmd = '' }) | Out-Null
    Start-Sleep -Milliseconds 300
    $gone = -not (Get-Process -Id $p.Id -ErrorAction SilentlyContinue)
    $crit = @($list | Where-Object { $_.critical }).Count
    $top = ($list | Sort-Object { $_.cpu } -Descending | Select-Object -First 3 | ForEach-Object { "$($_.name) $($_.cpu)%" }) -join ', '
    Add-R 'Processes' (($list.Count -gt 20) -and ($pr1 -eq 'BelowNormal') -and $gone) ("عدد=$($list.Count) محمية=$crit أولوية: $pr0→$pr1 انتهت=$gone الأعلى: $top") $null
  } catch { Add-R 'Processes' $false $_.Exception.Message $null }

  # 9) تنظيف الرام
  try {
    $script:quiet = $true
    $m0 = [PolarSys]::Mem()
    if (-not ('PolarMem' -as [type])) { Invoke-MemClean | Out-Null } else { Invoke-MemClean | Out-Null }
    $m1 = [PolarSys]::Mem()
    Add-R 'RAM clean' $true ("قبل={0:N2}GB بعد={1:N2}GB" -f (($m0[0] - $m0[1]) / 1GB), (($m1[0] - $m1[1]) / 1GB)) $null
  } catch { Add-R 'RAM clean' $false $_.Exception.Message $null }

  # 10) الأقراص
  try {
    $d = @(Get-PhysicalDisk); $rel = @($d | ForEach-Object { try { $_ | Get-StorageReliabilityCounter -ErrorAction Stop } catch { $null } } | Where-Object { $_ })
    Add-R 'Disk health' ($d.Count -gt 0) ("أقراص=$($d.Count) فيها بيانات SMART=$($rel.Count) حرارة=" + (($rel | ForEach-Object { $_.Temperature }) -join ',')) $null
  } catch { Add-R 'Disk health' $false $_.Exception.Message $null }

  # 11) الحالة الحقيقية للتويكات
  try {
    $script:quiet = $true
    $res = @{}
    foreach ($prop in $cfg.verifyMap.PSObject.Properties) {
      $known = 0; $match = 0
      foreach ($raw in @($prop.Value)) { if ($raw.t -eq 'pattr' -or $raw.t -eq 'ps') { continue }; foreach ($op in (Expand-Op $raw)) { $x = $null; try { $x = Test-ConcreteOp $op } catch {}; if ($null -ne $x) { $known++; if ($x) { $match++ } } } }
      $res[$prop.Name] = $(if ($known -eq 0) { 'unknown' } elseif ($match -eq $known) { 'on' } elseif ($match -eq 0) { 'off' } else { 'partial' })
    }
    $applied = @($cfg.applied)
    $drift = @($applied | Where-Object { $res[$_] -and $res[$_] -ne 'on' -and $res[$_] -ne 'unknown' })
    # لكل تويك مختلف: أول قيمتين مختلفتين وقيمتها الحالية بالنظام
    $why = foreach ($id in $drift) {
      $bad = @(); foreach ($raw in @($cfg.verifyMap.$id)) { if ($raw.t -eq 'pattr' -or $raw.t -eq 'ps') { continue }; foreach ($op in (Expand-Op $raw)) { $x = $null; try { $x = Test-ConcreteOp $op } catch {}; if ($x -eq $false -and $bad.Count -lt 2) { $bad += (Get-OpMismatch $op) } } }
      "$id [$($bad -join ' · ')]"
    }
    # إعدادات طاقة ما ثبتت: نجرب نكتبها ونقراها فورًا وبعد ثواني عشان نعرف هل الكتابة تفشل أو شي يرجّعها
    $probe = foreach ($id in $drift) { foreach ($raw in @($cfg.verifyMap.$id)) { if ($raw.t -ne 'pcfg') { continue }; foreach ($op in (Expand-Op $raw)) {
      $x = $null; try { $x = Test-ConcreteOp $op } catch {}
      if ($x -ne $false) { continue }
      $out = ((& powercfg /setacvalueindex scheme_current $op.s $op.n $op.ac) 2>&1 | Out-String).Trim()
      & powercfg /setactive scheme_current 2>&1 | Out-Null
      $now = Get-PowerIndex $op.s $op.n; Start-Sleep -Seconds 3; $later = Get-PowerIndex $op.s $op.n
      $raw2 = (((& powercfg /q scheme_current $op.s $op.n) 2>$null) | Where-Object { $_ -match '0x' } | ForEach-Object { $_.Trim() }) -join ' ; '
      $ov = $null; try { $ov = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes' -ErrorAction Stop).ActiveOverlayAcPowerScheme } catch {}
      "$($op.n): كتبت $($op.ac) ← فورًا=$($now.ac) بعد 3ث=$($later.ac) · خطة=$(Get-ActiveScheme) · وضع الطاقة=$ov · powercfg='$out' · [$raw2]"
    } } }
    if ($probe) { $why = @($why) + @('فحص الكتابة: ' + (@($probe) -join ' | ')) }
    Add-R 'Tweak verification' ($drift.Count -eq 0) ("مطبّق حسب البرنامج=$($applied.Count) مختلف عن النظام=$($drift.Count): " + ($why -join ' | ')) @{ status = $res }
  } catch { Add-R 'Tweak verification' $false $_.Exception.Message $null }

  # 13) الشبكة: بنق ICMP حقيقي + عدادات كرت الشبكة
  try {
    $pg = New-Object Net.NetworkInformation.Ping; $rt = @()
    foreach ($i in 1..4) { try { $x = $pg.Send('1.1.1.1', 1500); if ($x.Status -eq 'Success') { $rt += $x.RoundtripTime } } catch {} }
    $a1 = Get-NetTotals; Start-Sleep -Milliseconds 1000; $a2 = Get-NetTotals
    $okNet = $rt.Count -gt 0 -and $a2[0] -ge $a1[0]
    Add-R 'Ping & network' $okNet ("ping 1.1.1.1: {0}/4 ردود، متوسط {1} ms · تحميل آخر ثانية {2:N1} KB" -f $rt.Count, $(if ($rt.Count) { [math]::Round(($rt | Measure-Object -Average).Average, 1) } else { '—' }), (($a2[0] - $a1[0]) / 1KB)) $null
  } catch { Add-R 'Ping & network' $false $_.Exception.Message $null }

  # 14) بدء التشغيل: كل المصادر
  try {
    $su = @(Get-StartupItemsData)
    $by = ($su | Group-Object { $_.type } | ForEach-Object { "$($_.Name)=$($_.Count)" }) -join ' '
    Add-R 'Startup sources' ($su.Count -gt 0) ("عناصر=$($su.Count) · $by") $null
  } catch { Add-R 'Startup sources' $false $_.Exception.Message $null }

  # 12) محلل المساحة: نقارن حجم مجلد بين الماسح السريع و Get-ChildItem
  try {
    if (-not ('DiskScan' -as [type])) { Add-Type -TypeDefinition (Get-Content -LiteralPath (Join-Path $PSScriptRoot 'diskscan.cs') -Raw) }
    $dir = Join-Path $env:windir 'Logs'
    [DiskScan]::Start($dir); $sw = [Diagnostics.Stopwatch]::StartNew()
    while (-not [DiskScan]::Done -and $sw.Elapsed.TotalSeconds -lt 60) { Start-Sleep -Milliseconds 100 }
    $a = [DiskScan]::Root.S
    $b = (Get-ChildItem -LiteralPath $dir -Recurse -Force -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
    $ok = $a -gt 0 -and [math]::Abs($a - $b) -le [math]::Max(1048576, $b * 0.02)
    Add-R 'Disk space scan' $ok ("Windows\Logs: الماسح={0:N1}MB Get-ChildItem={1:N1}MB ملفات={2} وقت={3:N2}s" -f ($a / 1MB), ($b / 1MB), [DiskScan]::Files, $sw.Elapsed.TotalSeconds) $null
  } catch { Add-R 'Disk space scan' $false $_.Exception.Message $null }

  # 13) مكوّنات طبيب الجهاز: نوع الإقلاع وقائمة الشاشات ووضعها الحالي
  try {
    $fw = [DemsetDisplay]::FirmwareType()
    $mons = @([DemsetDisplay]::List())
    $fwName = switch ($fw) { 1 { 'BIOS (Legacy)' } 2 { 'UEFI' } default { "غير معروف ($fw)" } }
    Add-R 'Device doctor APIs' (($fw -in 1, 2) -and $mons.Count -gt 0) ("الإقلاع=$fwName · شاشات=$($mons.Count): " + (($mons | ForEach-Object { "$($_[1]) $($_[4])Hz (أعلى $($_[5]))" }) -join ' | ')) $null
  } catch { Add-R 'Device doctor APIs' $false $_.Exception.Message $null }

  # 14) وضع الألعاب التلقائي: مسار ملف اللعبة (يشتغل حتى مع أنتي-تشيت) وكشف ملء الشاشة
  try {
    $me = [PolarSys]::ExePath($PID)
    $fs = [PolarSys]::FgFull()
    $ok = $me -and ($me -like '*powershell*')
    Add-R 'Game mode detection' ([bool]$ok) ("مسار العملية=$me · نافذة ملء شاشة الحين=$fs") $null
  } catch { Add-R 'Game mode detection' $false $_.Exception.Message $null }

  # 15) تحديثات ويندوز (COM) — نتأكد إن الخدمة ترد بدون ما نبحث فعليًا
  try {
    $ses = New-Object -ComObject Microsoft.Update.Session
    $srch = $ses.CreateUpdateSearcher()
    $cnt = $srch.GetTotalHistoryCount()
    $wu = Get-Service wuauserv -ErrorAction SilentlyContinue
    Add-R 'Windows Update COM' $true ("سجل التحديثات=$cnt · خدمة wuauserv=$($wu.Status) ($($wu.StartType))") $null
  } catch { Add-R 'Windows Update COM' $false $_.Exception.Message $null }

  # 16) الاختصارات: ننشئ اختصار مؤقت ونقرأه ونحذفه
  try {
    $lnk = Join-Path $env:TEMP ('demset-test-' + [guid]::NewGuid().ToString('N').Substring(0, 6) + '.lnk')
    $sh = New-Object -ComObject WScript.Shell
    $sc = $sh.CreateShortcut($lnk); $sc.TargetPath = "$env:windir\notepad.exe"; $sc.Save()
    $back = $sh.CreateShortcut($lnk).TargetPath
    $desk = [Environment]::GetFolderPath('CommonDesktopDirectory')
    Remove-Item -LiteralPath $lnk -Force -ErrorAction SilentlyContinue
    Add-R 'Desktop shortcuts' ($back -like '*notepad.exe') ("أنشأ وقرأ اختصار تجريبي ($back) · سطح المكتب العام: $desk") $null
  } catch { Add-R 'Desktop shortcuts' $false $_.Exception.Message $null }

  $script:quiet = $false
  Emit 'selftest' (ConvertTo-Json -InputObject @($Results) -Compress -Depth 6)
}

# ---------------- Winget بصلاحيات المستخدم العادية ----------------
# بعض المثبّتات (مثل Spotify و Discord) ترفض أو تنثبت غلط إذا شغلناها كمسؤول.
# نشغّل winget عن طريق مهمة مجدولة مؤقتة بصلاحيات المستخدم، ونقرا مخرجاتها من ملف.
function Invoke-WingetAsUser($cfg) {
  $wg = Join-Path $env:LOCALAPPDATA 'Microsoft\WindowsApps\winget.exe'
  if (-not (Test-Path $wg)) { $wg = 'winget.exe' }
  $log = Join-Path $env:TEMP ('demset-wg-' + [guid]::NewGuid().ToString('N') + '.log')
  $argStr = (@($cfg.args) | ForEach-Object { if ("$_" -match '\s') { '"' + $_ + '"' } else { "$_" } }) -join ' '
  $cmd = '/c ""' + $wg + '" ' + $argStr + ' > "' + $log + '" 2>&1"'
  $tn = 'DemsetTweaksWinget_' + [guid]::NewGuid().ToString('N').Substring(0, 8)
  $full = ''
  try {
    $usr = (Get-CimInstance Win32_ComputerSystem).UserName
    if (-not $usr) { $usr = "$env:USERDOMAIN\$env:USERNAME" }
    # conhost --headless: يشغّل cmd بدون ما تطلع نافذة سودا (ويندوز 10 1903 وأحدث)
    $ch = "$env:windir\System32\conhost.exe"
    if (Test-Path $ch) { $act = New-ScheduledTaskAction -Execute $ch -Argument ("--headless $env:windir\System32\cmd.exe " + $cmd) }
    else { $act = New-ScheduledTaskAction -Execute "$env:windir\System32\cmd.exe" -Argument $cmd }
    $pr = New-ScheduledTaskPrincipal -UserId $usr -LogonType Interactive -RunLevel Limited
    $set = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Hours 2) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
    Register-ScheduledTask -TaskName $tn -Action $act -Principal $pr -Settings $set -Force | Out-Null
    Start-ScheduledTask -TaskName $tn
    $pos = 0; $seen = $false; $sw = [Diagnostics.Stopwatch]::StartNew(); $rest = ''
    while ($true) {
      Start-Sleep -Milliseconds 400
      if (Test-Path -LiteralPath $log) {
        try {
          $fs = [IO.File]::Open($log, 'Open', 'Read', 'ReadWrite')
          if ($fs.Length -gt $pos) {
            $fs.Position = $pos; $buf = New-Object byte[] ($fs.Length - $pos); $n = $fs.Read($buf, 0, $buf.Length); $pos += $n
            $txt = $rest + [Text.Encoding]::UTF8.GetString($buf, 0, $n)
            $parts = $txt -split "\r\n|\n|\r"; $rest = $parts[-1]
            if ($parts.Count -gt 1) { foreach ($l in $parts[0..($parts.Count - 2)]) { $c = ($l -replace "[\x08]", '').Trim(); if ($c -and $c -notmatch '^[\-\\|/ ]+$') { $full += $c + "`n"; Emit 'wg' $c } } }
          }
          $fs.Close()
        } catch {}
      }
      $st = "$((Get-ScheduledTask -TaskName $tn -ErrorAction SilentlyContinue).State)"
      if ($st -eq 'Running') { $seen = $true }
      elseif ($seen -or $sw.Elapsed.TotalSeconds -gt 8) { break }
    }
    if ($rest.Trim()) { $full += $rest; Emit 'wg' $rest.Trim() }
    $code = [int](Get-ScheduledTaskInfo -TaskName $tn).LastTaskResult
    if ($full.Length -gt 4000) { $full = $full.Substring($full.Length - 4000) }
    Emit 'wgout' (ConvertTo-Json -InputObject $full -Compress)
    Emit 'result' ("done:" + $code)
  } catch { Emit 'error' $_.Exception.Message; Emit 'result' 'done:-1' }
  finally {
    Unregister-ScheduledTask -TaskName $tn -Confirm:$false -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $log -Force -ErrorAction SilentlyContinue
  }
}

# ---------------- البرامج المثبتة (للأيقونات الحقيقية ومحلل المساحة) ----------------
function Get-InstalledApps {
  $roots = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall')
  $out = @()
  foreach ($r in $roots) {
    foreach ($k in (Get-ChildItem $r -ErrorAction SilentlyContinue)) {
      $p = Get-ItemProperty $k.PSPath -ErrorAction SilentlyContinue
      if (-not $p.DisplayName -or $p.SystemComponent -eq 1) { continue }
      $icon = "$($p.DisplayIcon)" -replace '^"|"?,\s*-?\d+$|"$', ''
      $out += @{ name = "$($p.DisplayName)"; icon = $icon; loc = "$($p.InstallLocation)".TrimEnd('\'); uninstall = "$($p.UninstallString)"; quiet = "$($p.QuietUninstallString)"; size = [int64]("0$($p.EstimatedSize)") }
    }
  }
  return $out
}

# ---------------- التحديثات: تعريف الكرت + تعريفات Windows Update + تحديثات الويندوز ----------------
function Progress([int]$p, [string]$label) { Emit 'progress' (@{ p = $p; label = $label } | ConvertTo-Json -Compress) }
function Convert-NvVersion([string]$v) {
  # 32.0.15.6094 → 560.94 (آخر 5 أرقام من الجزئين الأخيرين)
  $p = $v.Split('.'); if ($p.Count -lt 4) { return $v }
  $d = ($p[2] + $p[3].PadLeft(4, '0')); $d = $d.Substring([Math]::Max(0, $d.Length - 5))
  return ($d.Substring(0, 3) + '.' + $d.Substring(3))
}
function Get-GpuDriverInfo {
  $out = @()
  foreach ($g in @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue)) {
    $name = "$($g.Name)"; if ($name -match 'Basic Display|Remote|Virtual|Parsec|Meta') { continue }
    $vendor = if ($name -match 'NVIDIA') { 'nvidia' } elseif ($name -match 'AMD|Radeon') { 'amd' } elseif ($name -match 'Intel') { 'intel' } else { 'other' }
    $date = $null; try { $date = [datetime]$g.DriverDate } catch {}
    $ver = "$($g.DriverVersion)"; $nice = if ($vendor -eq 'nvidia') { Convert-NvVersion $ver } else { $ver }
    $tool = $null
    if ($vendor -eq 'nvidia') {
      foreach ($c in @("$env:ProgramFiles\NVIDIA Corporation\NVIDIA app\CEF\NVIDIA app.exe", "$env:ProgramFiles\NVIDIA Corporation\NVIDIA App\CEF\NVIDIA App.exe", "${env:ProgramFiles(x86)}\NVIDIA Corporation\NVIDIA GeForce Experience\NVIDIA GeForce Experience.exe")) { if (Test-Path -LiteralPath $c) { $tool = @{ name = (Split-Path $c -Leaf) -replace '\.exe$', ''; path = $c }; break } }
    } elseif ($vendor -eq 'amd') {
      foreach ($c in @("$env:ProgramFiles\AMD\CNext\CNext\RadeonSoftware.exe")) { if (Test-Path -LiteralPath $c) { $tool = @{ name = 'AMD Software: Adrenalin'; path = $c }; break } }
    } elseif ($vendor -eq 'intel') {
      foreach ($c in @("${env:ProgramFiles(x86)}\Intel\Driver and Support Assistant\DSATray.exe", "$env:ProgramFiles\Intel\Driver and Support Assistant\DSATray.exe")) { if (Test-Path -LiteralPath $c) { $tool = @{ name = 'Intel Driver & Support Assistant'; path = $c }; break } }
    }
    $out += @{ name = $name; vendor = $vendor; version = $nice; rawVersion = $ver; date = $(if ($date) { $date.ToString('yyyy-MM-dd') } else { '' }); ageDays = $(if ($date) { [int]((Get-Date) - $date).TotalDays } else { -1 }); tool = $tool }
  }
  return $out
}
function Invoke-UpdatesScan($cfg) {
  $res = @{ gpu = @(Get-GpuDriverInfo); drivers = @(); windows = @(); problems = @(); wuError = ''; scannedAt = (Get-Date).ToString('s') }
  # أجهزة فيها مشكلة تعريف (كود 28 = ما لها تعريف)
  foreach ($d in @(Get-CimInstance Win32_PnPEntity -Filter 'ConfigManagerErrorCode <> 0' -ErrorAction SilentlyContinue)) {
    $res.problems += @{ name = "$($d.Name)"; code = [int]$d.ConfigManagerErrorCode; cls = "$($d.PNPClass)"; id = "$($d.DeviceID)" }
  }
  Log '▶ يدوّر في Windows Update (ياخذ دقيقة أحيانًا)…'
  try {
    $ses = New-Object -ComObject Microsoft.Update.Session
    $ses.ClientApplicationID = 'Demset Tweaks'
    $sr = $ses.CreateUpdateSearcher()
    $found = $sr.Search("IsInstalled=0 and IsHidden=0")
    foreach ($u in @($found.Updates)) {
      $kb = (@($u.KBArticleIDs) | ForEach-Object { 'KB' + $_ }) -join ', '
      $o = @{ id = "$($u.Identity.UpdateID)"; title = "$($u.Title)"; kb = $kb; sizeMB = [math]::Round([double]$u.MaxDownloadSize / 1MB, 1); downloaded = [bool]$u.IsDownloaded; reboot = ([int]$u.InstallationBehavior.RebootBehavior -ne 0); optional = (-not [bool]$u.AutoSelectOnWebSites) }
      if ([int]$u.Type -eq 2) {
        $o.cls = "$($u.DriverClass)"; $o.maker = "$($u.DriverManufacturer)"; $o.model = "$($u.DriverModel)"
        try { $o.date = ([datetime]$u.DriverVerDate).ToString('yyyy-MM-dd') } catch { $o.date = '' }
        $res.drivers += $o
      } else {
        $o.cats = (@($u.Categories) | ForEach-Object { $_.Name }) -join ', '
        $res.windows += $o
      }
    }
    Log ("  لقيت " + $res.drivers.Count + " تعريف و " + $res.windows.Count + " تحديث ويندوز")
  } catch { $res.wuError = $_.Exception.Message; Warn ('  Windows Update ما رد: ' + $_.Exception.Message) }
  Emit 'updscan' (ConvertTo-Json -InputObject $res -Compress -Depth 5)
}
function Invoke-UpdatesInstall($cfg) {
  $want = @($cfg.ids)
  $results = @(); $reboot = $false
  try {
    $ses = New-Object -ComObject Microsoft.Update.Session
    $ses.ClientApplicationID = 'Demset Tweaks'
    $found = $ses.CreateUpdateSearcher().Search("IsInstalled=0 and IsHidden=0")
    $list = @($found.Updates | Where-Object { $want -contains "$($_.Identity.UpdateID)" })
    $i = 0
    foreach ($u in $list) {
      $i++; $t = "$($u.Title)"
      Progress ([int](($i - 1) / [math]::Max(1, $list.Count) * 100)) ("($i/$($list.Count)) تحميل: " + $t)
      try {
        if (-not $u.EulaAccepted) { $u.AcceptEula() }
        $col = New-Object -ComObject Microsoft.Update.UpdateColl; [void]$col.Add($u)
        if (-not $u.IsDownloaded) { $dl = $ses.CreateUpdateDownloader(); $dl.Updates = $col; [void]$dl.Download() }
        Progress ([int](($i - 0.5) / [math]::Max(1, $list.Count) * 100)) ("($i/$($list.Count)) تثبيت: " + $t)
        $ins = $ses.CreateUpdateInstaller(); $ins.Updates = $col; $r = $ins.Install()
        $code = [int]$r.ResultCode  # 2 = نجح، 3 = نجح مع أخطاء، 4 = فشل، 5 = انلغى
        $ok = ($code -eq 2 -or $code -eq 3)
        if ($r.RebootRequired) { $reboot = $true }
        $results += @{ id = "$($u.Identity.UpdateID)"; title = $t; ok = $ok; code = $code; hr = ('0x{0:X8}' -f $r.HResult) }
        if ($ok) { Log ('  ✓ ' + $t) } else { Warn ('  ✗ ' + $t + ' (كود ' + $code + ')') }
      } catch { $results += @{ id = "$($u.Identity.UpdateID)"; title = $t; ok = $false; code = -1; hr = $_.Exception.Message }; Warn ('  ✗ ' + $t + ': ' + $_.Exception.Message) }
    }
    if (-not $list.Count) { Warn '  التحديثات المطلوبة ما عادت متوفرة (يمكن انثبتت)' }
  } catch { Warn ('Windows Update: ' + $_.Exception.Message) }
  Progress 100 'خلص'
  Emit 'updinst' (ConvertTo-Json -InputObject @{ results = @($results); reboot = $reboot } -Compress -Depth 4)
}

# ---------------- اختصار البرنامج على سطح المكتب بعد التثبيت ----------------
# يدور اختصار البرنامج في قائمة ابدأ (للكل وللمستخدم) وينسخه لسطح المكتب.
# لو البرنامج من المتجر (ما له ملف lnk) يسوي اختصار shell:AppsFolder من Get-StartApps.
function Get-NormName([string]$s) { return (($s.ToLower()) -replace '[^a-z0-9]', '') }
# يطابق اسمين بعد ما نشيل الرموز: متساويين، أو واحد يبدأ بالثاني أو يحتويه (4 حروف أو أكثر)
function Test-NameMatch([string]$n, [string[]]$wants) {
  if (-not $n) { return $false }
  foreach ($w in $wants) {
    if (-not $w) { continue }
    if ($n -eq $w) { return $true }
    if ($w.Length -ge 4 -and ($n.StartsWith($w) -or $n.Contains($w))) { return $true }
    if ($n.Length -ge 4 -and ($w.StartsWith($n) -or $w.Contains($n))) { return $true }
  }
  return $false
}
$script:exeSkip = '(?i)(unins|uninst|setup|install|update|crash|report|helper|elevat|service|svc|vc_?redist|dotnet|redist|\bcef|webview|notif|tray|broker|launcher_?helper)'
# أكبر ملف تشغيل في مجلد (أو اللي اسمه نفس التلميح)
function Find-MainExe([string]$dir, [string]$hint) {
  if (-not $dir -or -not (Test-Path -LiteralPath $dir)) { return $null }
  $exes = @(Get-ChildItem -LiteralPath $dir -Filter *.exe -Recurse -Depth 3 -File -ErrorAction SilentlyContinue)
  if ($hint) { $h = $exes | Where-Object { $_.Name -ieq $hint } | Select-Object -First 1; if ($h) { return $h.FullName } }
  $c = $exes | Where-Object { $_.Name -notmatch $script:exeSkip } | Sort-Object Length -Descending | Select-Object -First 1
  if ($c) { return $c.FullName }
  return $null
}
# لو البرنامج ما سوّى اختصار في قائمة ابدأ (برامج Portable، أو مثبّتات ما تسوي اختصار): نلقى ملفه بنفسنا
function Find-AppExe($it, [string[]]$wants) {
  # 1) برامج Winget الـ Portable: تنحط في مجلد WinGet\Packages\<id>_...
  $roots = @("$env:LOCALAPPDATA\Microsoft\WinGet\Packages", "$env:ProgramFiles\WinGet\Packages", "${env:ProgramFiles(x86)}\WinGet\Packages")
  try { $u = "$((Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).UserName)".Split('\')[-1]; if ($u -and $u -ne $env:USERNAME) { $roots += "$env:SystemDrive\Users\$u\AppData\Local\Microsoft\WinGet\Packages" } } catch {}
  foreach ($r in $roots) {
    if (-not (Test-Path -LiteralPath $r)) { continue }
    foreach ($d in @(Get-ChildItem -LiteralPath $r -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like ($it.id + '_*') })) {
      $e = Find-MainExe $d.FullName $it.exe; if ($e) { return $e }
    }
  }
  # 2) قائمة البرامج المثبّتة (Uninstall): أيقونة البرنامج غالبًا هي ملفه، وإلا مجلد التثبيت
  $keys = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall')
  foreach ($k in $keys) {
    foreach ($e in @(Get-ChildItem -LiteralPath $k -ErrorAction SilentlyContinue)) {
      $p = $null; try { $p = Get-ItemProperty -LiteralPath $e.PSPath -ErrorAction Stop } catch { continue }
      if (-not $p.DisplayName -or -not (Test-NameMatch (Get-NormName $p.DisplayName) $wants)) { continue }
      $ic = "$($p.DisplayIcon)" -replace '^"|",?\d*$|,-?\d+$', '' -replace '"', ''
      if ($ic -match '(?i)\.exe$' -and (Test-Path -LiteralPath $ic) -and (Split-Path $ic -Leaf) -notmatch $script:exeSkip) { return $ic }
      $x = Find-MainExe "$($p.InstallLocation)".Trim('"') $it.exe; if ($x) { return $x }
    }
  }
  return $null
}
function New-DesktopLnk([string]$dst, [string]$target, [string]$args0, [string]$icon, [string]$wd) {
  $sh = New-Object -ComObject WScript.Shell
  $l = $sh.CreateShortcut($dst)
  $l.TargetPath = $target; if ($args0) { $l.Arguments = $args0 }
  if ($wd) { $l.WorkingDirectory = $wd }
  if ($icon) { $l.IconLocation = $icon }
  $l.Save()
  return (Test-Path -LiteralPath $dst)
}
function Add-AppShortcuts($cfg) {
  # سطح المكتب الصح: لو البرنامج شغّال كمسؤول بحساب ثاني (مو الحساب اللي داخل الويندوز)، سطح مكتب هالحساب
  # ما يشوفه المستخدم — فنحط الاختصار على سطح المكتب العام (يبان لكل الحسابات)
  $desk = [Environment]::GetFolderPath('Desktop')
  $pubDesk = [Environment]::GetFolderPath('CommonDesktopDirectory')
  try {
    $inter = "$((Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).UserName)"
    $me = "$env:USERDOMAIN\$env:USERNAME"
    if ($inter -and $inter -ne $me -and $pubDesk) { $desk = $pubDesk; Log "  (الاختصار على سطح المكتب العام — البرنامج شغّال بحساب $me والداخل $inter)" }
  } catch {}
  $res = @()
  $todo = @($cfg.items)
  # تطبيقات المتجر تاخذ ثواني لين تتسجّل في قائمة ابدأ — نعيد البحث كذا مرة قبل لا نقول "ما لقيت"
  for ($try = 0; $try -lt 6 -and $todo.Count; $try++) {
    if ($try) { Start-Sleep -Seconds 3 }
    $menus = @([Environment]::GetFolderPath('CommonPrograms'), [Environment]::GetFolderPath('Programs')) | Where-Object { $_ -and (Test-Path $_) }
    $lnks = @(foreach ($m in $menus) { Get-ChildItem -LiteralPath $m -Recurse -Filter *.lnk -ErrorAction SilentlyContinue })
    $lnks = @($lnks | Where-Object { $_.BaseName -notmatch '(?i)uninstall|readme|help|website|documentation|manual|release notes|license|إزالة' })
    $start = @(try { Get-StartApps } catch { @() })
    $left = @()
    foreach ($it in $todo) {
      $want = Get-NormName $it.name
      $alt = Get-NormName (($it.id -split '\.')[-1]); if ($alt -match '^\d+$|^synapse\d$') { $alt = Get-NormName (($it.id -split '\.')[-2]) }
      $wants = @($want, $alt) + @(@($it.lnk) | Where-Object { $_ } | ForEach-Object { Get-NormName $_ })
      $r = @{ id = $it.id; name = $it.name; ok = $false; how = ''; path = '' }
      try {
        # موجود أصلًا على سطح المكتب؟ (أغلب المثبّتات تسوي اختصار بنفسها)
        $exist = @(foreach ($d in @([Environment]::GetFolderPath('Desktop'), $pubDesk, $desk)) { if ($d -and (Test-Path $d)) { Get-ChildItem -LiteralPath $d -Filter *.lnk -ErrorAction SilentlyContinue } }) | Where-Object { Test-NameMatch (Get-NormName $_.BaseName) $wants } | Select-Object -First 1
        if ($exist) { $r.ok = $true; $r.how = 'exists'; $r.path = $exist.FullName; $res += $r; continue }
        # أدوات الطرفية (Claude Code و Codex …): اختصار يفتح نافذة أوامر شغّال فيها البرنامج
        if ($it.cli) {
          $exe = Find-AppExe $it $wants
          if (-not $exe) { $lk = Join-Path $env:LOCALAPPDATA ('Microsoft\WinGet\Links\' + $it.cli + '.exe'); if (Test-Path -LiteralPath $lk) { $exe = $lk } }
          if (-not $exe) { $cmd = Get-Command $it.cli -ErrorAction SilentlyContinue | Select-Object -First 1; if ($cmd) { $exe = $cmd.Source } }
          if ($exe) {
            $dst = Join-Path $desk (($it.name -replace '[\\/:*?"<>|]', '') + '.lnk')
            $r.ok = New-DesktopLnk $dst "$env:windir\System32\cmd.exe" ('/k "' + $exe + '"') ($exe + ',0') $env:USERPROFILE
            $r.how = 'cli'; $r.path = $dst
          } else { $r.how = 'notfound' }
          if ($r.ok) { Log ("  اختصار على سطح المكتب: " + $it.name); $res += $r }
          elseif ($try -lt 5) { $left += $it } else { Warn ("  ما لقيت " + $it.name); $res += $r }
          continue
        }
        $hit = if ($it.store) { $null } else { $lnks | Where-Object { Test-NameMatch (Get-NormName $_.BaseName) $wants } | Sort-Object { $_.BaseName.Length } | Select-Object -First 1 }
        if ($hit) {
          $dst = Join-Path $desk ($hit.Name)
          Copy-Item -LiteralPath $hit.FullName -Destination $dst -Force
          $r.ok = (Test-Path -LiteralPath $dst); $r.how = 'copied'; $r.path = $dst
        } else {
          $sa = $start | Where-Object { Test-NameMatch (Get-NormName $_.Name) $wants } | Sort-Object { $_.Name.Length } | Select-Object -First 1
          if ($sa) {
            $dst = Join-Path $desk (($sa.Name -replace '[\\/:*?"<>|]', '') + '.lnk')
            $sh = New-Object -ComObject WScript.Shell
            $l = $sh.CreateShortcut($dst)
            # shell:AppsFolder يشتغل لتطبيقات المتجر والبرامج العادية
            $l.TargetPath = "$env:windir\explorer.exe"; $l.Arguments = 'shell:AppsFolder\' + $sa.AppID
            # أيقونة التطبيق نفسه (بدل أيقونة المستكشف) لو لقيناها
            try {
              if ($sa.AppID -match '^([^!]+)!') { $pk = Get-AppxPackage -ErrorAction SilentlyContinue | Where-Object { $_.PackageFamilyName -eq $Matches[1] } | Select-Object -First 1
                if ($pk) { $ico = Get-ChildItem -LiteralPath $pk.InstallLocation -Recurse -Include *.ico -ErrorAction SilentlyContinue | Select-Object -First 1; if ($ico) { $l.IconLocation = $ico.FullName } } }
            } catch {}
            $l.Save()
            $r.ok = (Test-Path -LiteralPath $dst); $r.how = 'created'; $r.path = $dst
          } elseif (-not $it.store -and ($exe = Find-AppExe $it $wants)) {
            # ما له اختصار في قائمة ابدأ (Portable مثلًا): نسوي اختصار لملفه مباشرة
            $dst = Join-Path $desk (($it.name -replace '[\\/:*?"<>|]', '') + '.lnk')
            $r.ok = New-DesktopLnk $dst $exe '' ($exe + ',0') (Split-Path $exe)
            $r.how = 'exe'; $r.path = $dst
          } else { $r.how = 'notfound' }
        }
      } catch { $r.how = 'error: ' + $_.Exception.Message }
      if ($r.ok) { Log ("  اختصار على سطح المكتب: " + $it.name); $res += $r }
      elseif ($r.how -eq 'notfound' -and $try -lt 5) { $left += $it }
      else { Warn ("  ما لقيت اختصار لـ " + $it.name + " (" + $r.how + ")"); $res += $r }
    }
    $todo = $left
  }
  Emit 'lnk' (ConvertTo-Json -InputObject @($res) -Compress -Depth 3)
}

# ---------------- تحليل مساحة القرص (مثل PC Manager) ----------------
function Get-FixedDrives {
  $o = @()
  foreach ($d in [IO.DriveInfo]::GetDrives()) {
    if ($d.DriveType -ne 'Fixed' -or -not $d.IsReady) { continue }
    $o += @{ letter = $d.Name.Substring(0, 1); label = "$($d.VolumeLabel)"; total = $d.TotalSize; free = $d.TotalFreeSpace; system = ($d.Name.Substring(0, 2) -ieq $env:SystemDrive) }
  }
  return $o
}
function Get-DownloadsPath {
  try {
    $v = (Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' -ErrorAction Stop).'{374DE290-123F-4565-9164-39C4925E467B}'
    if ($v) { return [Environment]::ExpandEnvironmentVariables($v) }
  } catch {}
  return (Join-Path $env:USERPROFILE 'Downloads')
}
function Invoke-DiskScan($cfg) {
  if (-not ('DiskScan' -as [type])) { Add-Type -TypeDefinition (Get-Content -LiteralPath (Join-Path $PSScriptRoot 'diskscan.cs') -Raw) }
  $letter = "$($cfg.drive)".Substring(0, 1).ToUpper()
  $root = $letter + ':\'
  $di = New-Object IO.DriveInfo $root
  $used = $di.TotalSize - $di.TotalFreeSpace
  [DiskScan]::Start($root)
  $sw = [Diagnostics.Stopwatch]::StartNew()
  while (-not [DiskScan]::Done) {
    Start-Sleep -Milliseconds 400
    $p = [math]::Min(97, [DiskScan]::Bytes * 100.0 / [math]::Max(1, $used))
    Emit 'progress' (@{ p = [math]::Round($p, 1); label = ("{0:N0} ملف · {1:N1} جيجا" -f [DiskScan]::Files, ([DiskScan]::Bytes / 1GB)) } | ConvertTo-Json -Compress)
  }
  if ([DiskScan]::Error) { Emit 'error' ([DiskScan]::Error); $script:exitCode = 1; return }
  [DiskScan]::Save($cfg.out)
  $sz = { param($n) [DiskScan]::SizeOf($n) }
  $sys = $letter -ieq $env:SystemDrive.Substring(0, 1)
  $cats = $null
  if ($sys) {
    $rootFiles = 0
    foreach ($c in [DiskScan]::Root.C) { if (-not $c.D) { $rootFiles += $c.S } }
    $cats = [ordered]@{
      user = (& $sz 'Users')
      apps = (& $sz 'Program Files') + (& $sz 'Program Files (x86)') + (& $sz 'ProgramData')
      system = (& $sz 'Windows') + $rootFiles
      recycle = (& $sz '$Recycle.Bin')
    }
    $known = 0; foreach ($v in $cats.Values) { $known += $v }
    $cats['other'] = [math]::Max(0, $used - $known)
  }
  $dl = Get-DownloadsPath
  $big = @(foreach ($b in [DiskScan]::BigFiles(200)) { $i = $b.IndexOf('|'); @{ s = [int64]$b.Substring(0, $i); p = $b.Substring($i + 1).Replace('\\?\', '') } })
  $sum = @{
    drive = $letter; total = $di.TotalSize; used = $used; free = $di.TotalFreeSpace; scanned = [DiskScan]::Root.S; files = [DiskScan]::Files; denied = [DiskScan]::Denied
    seconds = [math]::Round($sw.Elapsed.TotalSeconds, 1); system = $sys; cats = $cats; downloads = $dl; big = $big; at = [DateTimeOffset]::Now.ToUnixTimeMilliseconds()
  }
  Emit 'diskscan' ($sum | ConvertTo-Json -Compress -Depth 4)
}
