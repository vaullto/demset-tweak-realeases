﻿# Fixed, reversible profiles. Every baseline is durably saved BEFORE a write.
function Save-BoostBackup($file, $records) {
  $dir = Split-Path -Parent $file
  [IO.Directory]::CreateDirectory($dir) | Out-Null
  $json = ConvertTo-Json -InputObject @($records) -Depth 12
  $bytes = [Text.Encoding]::UTF8.GetBytes($json)
  $tmp = $file + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
  try {
    $stream = [IO.File]::Open($tmp, 'CreateNew', 'Write', 'None')
    try { $stream.Write($bytes, 0, $bytes.Length); $stream.Flush($true) } finally { $stream.Dispose() }
    if ([IO.File]::Exists($file)) { [IO.File]::Replace($tmp, $file, [NullString]::Value) } else { [IO.File]::Move($tmp, $file) }
  } finally { if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force } }
}
function Get-BoostWindowsBuild { return [Environment]::OSVersion.Version.Build }
function Merge-BoostPreference([string]$value, [string]$name, [string]$wanted) {
  $prefix = '^\s*' + [regex]::Escape($name) + '\s*='
  $tokens = @($value -split ';' | ForEach-Object { $_.Trim() } | Where-Object { $_ -and $_ -notmatch $prefix })
  return (($tokens + ($name + '=' + $wanted)) -join ';') + ';'
}
function Set-BoostNvidiaValue($op) {
  $code = [DemsetNv]::Set([uint32]$op.id, [int64]$op.v, $false)
  if ($code -ne 0) { throw "NVIDIA rejected setting ($code)" }
}
function Restore-BoostRecord($r) {
  if ($r.t -eq 'reg') {
    if ($r.prior.exists) { Set-RegValueDirect $r.k $r.n $r.prior.kind $r.prior.value }
    else { Remove-RegValueDirect $r.k $r.n }
  } elseif ($r.t -eq 'nvdrs') {
    $code = if ($r.prior.exists) { [DemsetNv]::Set([uint32]$r.id, [int64]$r.prior.value, ($r.prior.type -eq 1)) } else { [DemsetNv]::Delete([uint32]$r.id) }
    if ($code -ne 0) { throw "NVIDIA restore rejected ($code)" }
  } else { throw 'Invalid backup operation type' }
}
function Test-BoostRegValue($now, $wanted) {
  if ([bool]$now.exists -ne [bool]$wanted.exists) { return $false }
  if (-not $now.exists) { return $true }
  if ($now.kind -cne $wanted.kind) { return $false }
  return ((ConvertTo-Json -InputObject $now.value -Compress -Depth 6) -ceq (ConvertTo-Json -InputObject $wanted.value -Compress -Depth 6))
}
function Get-BoostGameOps([string]$exe,[string]$group) {
  if ($group -eq 'cpu') { return @(@{t='reg';k=('HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\' + [IO.Path]::GetFileName($exe) + '\PerfOptions');n='CpuPriorityClass';y='DWORD';v=3}) }
  $k = 'HKCU\Software\Microsoft\DirectX\UserGpuPreferences'
  $prior = Get-RegState $k $exe
  return @(@{t='reg';k=$k;n=$exe;y='SZ';v=(Merge-BoostPreference ([string]$prior.value) 'GpuPreference' '2')})
}
function Test-BoostOperation($op) {
  try {
    if ($op.t -eq 'reg') {
      $kind = if ($op.y -eq 'DWORD') { 'DWord' } else { 'String' }
      return Test-BoostRegValue (Get-RegState $op.k $op.n) @{exists=$true;kind=$kind;value=$op.v}
    }
    $v = Get-NvDrs $op
    return ($v.exists -and $v.type -eq 0 -and $v.value -eq $op.v)
  } catch { return $false }
}
function Get-BoostProfileState([string]$file, $ops) {
  if (-not (Test-Path -LiteralPath $file)) { return $false }
  if (-not @($ops).Count) { return $false }
  foreach ($op in $ops) { if (-not (Test-BoostOperation $op)) { return $false } }
  return $true
}
function Get-BoostWindowsOps {
  $cu = 'HKCU\Software\Microsoft\Windows\CurrentVersion'
  $ops = @(
    @{t='reg';k='HKCU\Software\Microsoft\GameBar';n='AutoGameModeEnabled';y='DWORD';v=1},
    @{t='reg';k='HKCU\Software\Microsoft\GameBar';n='AllowAutoGameMode';y='DWORD';v=1},
    @{t='reg';k='HKCU\Software\Microsoft\GameBar';n='UseNexusForGameBarEnabled';y='DWORD';v=0},
    @{t='reg';k="$cu\GameDVR";n='AppCaptureEnabled';y='DWORD';v=0},
    @{t='reg';k='HKCU\System\GameConfigStore';n='GameDVR_Enabled';y='DWORD';v=0},
    @{t='reg';k="$cu\Themes\Personalize";n='AppsUseLightTheme';y='DWORD';v=0},
    @{t='reg';k="$cu\Themes\Personalize";n='SystemUsesLightTheme';y='DWORD';v=0},
    @{t='reg';k="$cu\StorageSense\Parameters\StoragePolicy";n='01';y='DWORD';v=1},
    @{t='reg';k="$cu\StorageSense\Parameters\StoragePolicy";n='04';y='DWORD';v=1},
    @{t='reg';k="$cu\StorageSense\Parameters\StoragePolicy";n='2048';y='DWORD';v=1},
    @{t='reg';k="$cu\StorageSense\Parameters\StoragePolicy";n='08';y='DWORD';v=0},
    @{t='reg';k="$cu\StorageSense\Parameters\StoragePolicy";n='32';y='DWORD';v=0}
  )
  if ((Get-BoostWindowsBuild) -ge 22000) {
    $k = 'HKCU\Software\Microsoft\DirectX\UserGpuPreferences'; $n = 'DirectXUserGlobalSettings'
    $prior = Get-RegState $k $n
    $ops += @{t='reg';k=$k;n=$n;y='SZ';v=(Merge-BoostPreference ([string]$prior.value) 'SwapEffectUpgradeEnable' '1')}
  }
  return $ops
}
function Get-BoostNvidiaOps {
  # NVIDIA public NvApiDriverSettings.h enums; never write guessed driver keys.
  return @(
    @{t='nvdrs';id=0x1057EB71;v=1;label='Prefer maximum performance'},
    @{t='nvdrs';id=0x00CE2691;v=0x14;label='Texture filtering: High performance'},
    @{t='nvdrs';id=0x0064B541;v=1;label='Highest available refresh rate'},
    @{t='nvdrs';id=0x00A879CF;v=0x08416747;label='Vertical sync off'},
    @{t='nvdrs';id=0x00E73211;v=1;label='Anisotropic sample optimization'},
    @{t='nvdrs';id=0x002ECAF2;v=1;label='Trilinear optimization'},
    @{t='nvdrs';id=0x0019BB68;v=0;label='Allow negative LOD bias'},
    @{t='nvdrs';id=0x20C1221E;v=0;label='Threaded optimization auto'},
    @{t='nvdrs';id=0x20FDD1F9;v=0;label='OpenGL triple buffering off'},
    @{t='nvdrs';id=0x107D639D;v=1;label='Gamma correction: ON_IF_FOS'},
    @{t='nvdrs';id=0x107EFC5B;v=0;label='Antialiasing application controlled'},
    @{t='nvdrs';id=0x0098C1AC;v=0;label='MFAA off'},
    @{t='nvdrs';id=0x00AC8497;v=102400;label='Shader cache 100 GB'}
  )
}
function Get-BoostPrivacyNames {
  return @('location','userNotificationListener','userAccountInformation','contacts','appointments','phoneCall','phoneCallHistory','email','userDataTasks','chat','radios','bluetoothSync','appDiagnostics','documentsLibrary','downloadsFolder','picturesLibrary','videosLibrary','musicLibrary','broadFileSystemAccess','graphicsCaptureProgrammatic','graphicsCaptureWithoutBorder','humanPresence','activity')
}
function Get-BoostPrivacyOps {
  # Explicit permissions only. Camera, microphone, voice activation untouched.
  $names = @(Get-BoostPrivacyNames)
  $ops = @()
  foreach ($n in $names) {
    $k = 'HKCU\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\' + $n
    # Unknown/new permissions are not fabricated on unsupported Windows builds.
    if (Test-RegKey $k) { $ops += @{t='reg';k=$k;n='Value';y='SZ';v='Deny'} }
  }
  return $ops
}
function Get-OneClickGames {
  $all = @(Get-GameExes); $out = @()
  foreach ($g in (Get-GameDirs).games) {
    $prefix = $g.TrimEnd('\') + '\'
    $candidates = @($all | Where-Object { $_.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase) })
    if (-not $candidates.Count) { continue }
    $best = $candidates | ForEach-Object { Get-Item -LiteralPath $_ } | Sort-Object Length -Descending | Select-Object -First 1
    $out += @{name=(Split-Path $g -Leaf);exe=$best.FullName;candidates=$candidates}
  }
  return $out
}
function Get-OneClickScanGames($cfg) {
  $out = @(); $seen = @{}
  foreach ($g in (@(Get-OneClickGames) + @($cfg.extraGames))) {
    if (-not $g -or -not $g.exe) { continue }
    if (-not [IO.Path]::IsPathRooted([string]$g.exe)) { continue }
    try { $exe = [IO.Path]::GetFullPath([string]$g.exe) } catch { continue }
    if ([IO.Path]::GetExtension($exe) -ine '.exe' -or -not (Test-Path -LiteralPath $exe -PathType Leaf)) { continue }
    if ($seen.ContainsKey($exe.ToLowerInvariant())) { continue }
    $candidates = @($exe)
    foreach ($candidate in @($g.candidates)) {
      try {
        if (-not $candidate -or -not [IO.Path]::IsPathRooted([string]$candidate)) { continue }
        $c = [IO.Path]::GetFullPath([string]$candidate)
        if ([IO.Path]::GetExtension($c) -ieq '.exe' -and (Test-Path -LiteralPath $c -PathType Leaf) -and $c -notin $candidates) { $candidates += $c }
      } catch {}
    }
    $name = [string]$g.name
    if (-not $name.Trim()) { $name = [IO.Path]::GetFileNameWithoutExtension($exe) }
    $selected = $null
    if ($cfg.selections -is [Collections.IDictionary]) { $selected = $cfg.selections[$name] }
    elseif ($cfg.selections) { $property = $cfg.selections.PSObject.Properties[$name]; if ($property) { $selected = $property.Value } }
    if ($selected) {
      $match = @($candidates | Where-Object { [string]::Equals($_, [string]$selected, [StringComparison]::OrdinalIgnoreCase) })
      if ($match.Count) { $exe = $match[0] }
    }
    if ($seen.ContainsKey($exe.ToLowerInvariant())) { continue }
    $seen[$exe.ToLowerInvariant()] = $true
    $out += @{name=$name;exe=$exe;candidates=$candidates}
  }
  return $out
}
function Invoke-OneClick($cfg) {
  try {
    if (-not $cfg.backupDir -or -not [IO.Path]::IsPathRooted([string]$cfg.backupDir)) { throw 'Absolute backup directory required' }
    $root = [IO.Path]::GetFullPath([string]$cfg.backupDir)
    $action = [string]$cfg.action
    if ($action -notin @('scan','apply','revert')) { throw 'Unknown action' }
    if ($action -eq 'scan') {
      $games = @(Get-OneClickScanGames $cfg)
      foreach ($g in $games) {
        foreach ($kind in @('cpu','gpu')) {
          $gameFile = Join-Path $root ((Get-BoostGameKey $g.exe $kind) + '.json')
          $g[$kind + 'Backup'] = Test-Path -LiteralPath $gameFile
          $g[$kind] = Get-BoostProfileState $gameFile @(Get-BoostGameOps $g.exe $kind)
        }
      }
      $status = @{}; $backups = @{}
      foreach ($group in @('windows','nvidia','privacy')) {
        $profileFile = Join-Path $root ($group + '.json')
        $backups[$group] = Test-Path -LiteralPath $profileFile
        $profileOps = switch ($group) { 'windows' { @(Get-BoostWindowsOps) } 'nvidia' { @(Get-BoostNvidiaOps) } 'privacy' { @(Get-BoostPrivacyOps) } }
        $status[$group] = Get-BoostProfileState $profileFile @($profileOps)
      }
      $hags = @{supported=$null;manual=$true;requested=(Get-RegState 'HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode');reason='HwSchMode is a requested setting only. Hardware/driver support must be checked in Windows Graphics settings; Windows Boost does not guess it.'}
      Emit 'oneclick' (ConvertTo-Json -InputObject @{ok=$true;games=$games;status=$status;backups=$backups;hags=$hags} -Depth 8 -Compress); return
    }
    $group = [string]$cfg.group
    if ($group -notin @('windows','nvidia','privacy','cpu','gpu')) { throw 'Unknown boost profile' }
    $ops = @(); $key = $group
    if ($group -in @('cpu','gpu')) {
      $exe = [IO.Path]::GetFullPath([string]$cfg.exe)
      if ([IO.Path]::GetExtension($exe) -ne '.exe' -or ($action -eq 'apply' -and -not (Test-Path -LiteralPath $exe -PathType Leaf))) { throw 'Game executable not found' }
      $key = Get-BoostGameKey $exe $group
      $ops = @(Get-BoostGameOps $exe $group)
    } elseif ($group -eq 'windows') { $ops = @(Get-BoostWindowsOps) }
    elseif ($group -eq 'nvidia') { $ops = @(Get-BoostNvidiaOps) }
    elseif ($group -eq 'privacy') { $ops = @(Get-BoostPrivacyOps) }
    $file = Join-Path $root ($key + '.json')
    $records = @(); if (Test-Path -LiteralPath $file) {
      $records = @(Get-Content -LiteralPath $file -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop | ForEach-Object { $_ })
      foreach ($record in $records) {
        if ($record.t -notin @('reg','nvdrs') -or $null -eq $record.prior -or $record.prior.exists -isnot [bool]) { throw 'Invalid profile backup; no settings changed' }
        if ($record.t -eq 'reg') {
          if ($record.prior.exists -and $record.prior.kind -notin @('DWord','QWord','String','ExpandString','MultiString','Binary')) { throw 'Invalid registry backup type' }
          $allowed = @($ops | Where-Object { $_.t -eq 'reg' -and $_.k -ceq $record.k -and $_.n -ceq $record.n })
          # Privacy permissions may disappear in a Windows update; recorded
          # entries are still recoverable, but remain within the fixed allowlist.
          if (-not $allowed.Count -and $group -eq 'privacy') {
            $allowed = @(Get-BoostPrivacyNames | Where-Object { $record.k -ceq ('HKCU\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\' + $_) -and $record.n -ceq 'Value' })
          }
          # A Win11 upgrade/downgrade does not invalidate the previously saved
          # DirectX global preference baseline.
          if (-not $allowed.Count -and $group -eq 'windows' -and $record.k -ceq 'HKCU\Software\Microsoft\DirectX\UserGpuPreferences' -and $record.n -ceq 'DirectXUserGlobalSettings') { $allowed = @($true) }
        } else { $allowed = @($ops | Where-Object { $_.t -eq 'nvdrs' -and $_.id -eq $record.id }) }
        if (-not $allowed.Count) { throw 'Backup contains a setting outside this profile; no settings changed' }
      }
    }
    if ($action -eq 'revert') {
      $failed = @(); $count=0
      foreach ($r in $records) {
        try {
          Restore-BoostRecord $r
          if ($r.t -eq 'reg') {
            $now = Get-RegState $r.k $r.n
            if (-not (Test-BoostRegValue $now $r.prior)) { throw 'Restore verification failed' }
          } elseif ($r.t -eq 'nvdrs') {
            $now = Get-NvDrs $r
            if ($now.exists -ne $r.prior.exists -or ($now.exists -and $now.value -ne $r.prior.value)) { throw 'NVIDIA restore verification failed' }
          }
          $count++
        } catch { $failed += @{label=$r.label;name=$r.n;error=$_.Exception.Message} }
      }
      if (-not $failed.Count -and (Test-Path -LiteralPath $file)) { Remove-Item -LiteralPath $file -Force }
      Emit 'oneclick' (ConvertTo-Json -InputObject @{ok=($failed.Count -eq 0);count=$count;failed=$failed;reboot=($group -eq 'cpu')} -Depth 8 -Compress); return
    }
    if ($action -ne 'apply') { throw 'Unknown action' }
    $results = @()
    foreach ($op in $ops) {
      try {
        $prior = if ($op.t -eq 'reg') { Get-RegState $op.k $op.n } else { Get-NvDrs $op }
        if ($op.t -eq 'nvdrs' -and $prior.exists -and $prior.type -ne 0) { throw 'NVIDIA setting is not a DWORD; no change was made' }
        $existing = @($records | Where-Object { $_.t -eq $op.t -and $_.k -eq $op.k -and $_.n -eq $op.n -and $_.id -eq $op.id })
        if (-not $existing.Count) {
          $rec = @{t=$op.t;prior=$prior}; foreach ($p in @('k','n','id','label')) { if ($op.ContainsKey($p)) { $rec[$p]=$op[$p] } }
          $records += $rec
          Save-BoostBackup $file $records
        }
        if ($op.t -eq 'reg') {
          Set-RegValueDirect $op.k $op.n $op.y $op.v
          $now = Get-RegState $op.k $op.n
          $kind = if ($op.y -eq 'DWORD') { 'DWord' } else { 'String' }
          if (-not (Test-BoostRegValue $now @{exists=$true;kind=$kind;value=$op.v})) { throw 'Registry write verification failed' }
        }
        else { Set-BoostNvidiaValue $op; $now=Get-NvDrs $op; if (-not $now.exists -or $now.value -ne $op.v -or $now.type -ne 0) { throw 'NVIDIA write verification failed' } }
        $results += @{ok=$true;label=$op.label;name=$op.n;value=$op.v}
      } catch { $results += @{ok=$false;label=$op.label;name=$op.n;error=$_.Exception.Message} }
    }
    $bad = @($results | Where-Object { -not $_.ok })
    Emit 'oneclick' (ConvertTo-Json -InputObject @{ok=($bad.Count -eq 0 -and $results.Count -gt 0);results=$results;count=($results.Count-$bad.Count);reboot=($group -eq 'cpu');nothing=($results.Count -eq 0)} -Depth 8 -Compress)
  } catch { Emit 'oneclick' (ConvertTo-Json -InputObject @{ok=$false;error=$_.Exception.Message} -Compress) }
}
function Get-BoostGameKey([string]$exe,[string]$group) {
  $sha = [Security.Cryptography.SHA256]::Create()
  try { return $group + '-' + ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($exe.ToLowerInvariant()))).Replace('-','').Substring(0,24)) } finally { $sha.Dispose() }
}
function Get-BoostGameState($root,$exe,$group) { return Test-Path -LiteralPath (Join-Path $root ((Get-BoostGameKey $exe $group) + '.json')) }
