﻿# =============================================================
#  Demset Tweaks — كرت NVIDIA: إعدادات التعريف (Driver Profile) وكسر السرعة (Overclock)
#  كله عن طريق nvapi64.dll (نفس واجهة التعريف اللي تستخدمها لوحة تحكم NVIDIA و MSI Afterburner).
#  القراءة أول: إذا الكرت أو التعريف ما يدعم، نقول بوضوح وما نجرب شي.
# =============================================================

if (-not ('DemsetNv' -as [type])) {
  Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class DemsetNv {
  [DllImport("nvapi64.dll", EntryPoint = "nvapi_QueryInterface", CallingConvention = CallingConvention.Cdecl)]
  static extern IntPtr QI(uint id);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int F0();
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FEnum([Out] IntPtr[] h, out int n);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FBuf(IntPtr h, IntPtr buf);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FOutH(out IntPtr h);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FH(IntPtr h);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FHOutH(IntPtr s, out IntPtr p);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FSet(IntPtr s, IntPtr p, IntPtr buf);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FGet(IntPtr s, IntPtr p, uint id, IntPtr buf);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int FDel(IntPtr s, IntPtr p, uint id);
  static T Fn<T>(uint id) where T : class { IntPtr p = QI(id); if (p == IntPtr.Zero) throw new Exception("nvapi function 0x" + id.ToString("X8") + " missing"); return Marshal.GetDelegateForFunctionPointer(p, typeof(T)) as T; }
  static bool inited;
  public static void Init() { if (inited) return; int r = Fn<F0>(0x0150E828)(); if (r != 0) throw new Exception("NvAPI_Initialize=" + r); inited = true; }

  // ---------- كسر السرعة (Pstates20) ----------
  static IntPtr Gpu() { Init(); var h = new IntPtr[64]; int n; int r = Fn<FEnum>(0xE5AC921F)(h, out n); if (r != 0 || n < 1) throw new Exception("EnumPhysicalGPUs=" + r); return h[0]; }
  // يرجّع: [ok, editable, coreDelta_kHz, coreMin, coreMax, memDelta_kHz, memMin, memMax, version]
  public static int[] GetOffsets() {
    IntPtr g = Gpu();
    foreach (int ver in new int[] { 0x21CF8, 0x11C94 }) {
      int size = ver & 0xFFFF; IntPtr b = Marshal.AllocHGlobal(size);
      try {
        for (int i = 0; i < size; i++) Marshal.WriteByte(b, i, 0);
        Marshal.WriteInt32(b, 0, ver);
        int r = Fn<FBuf>(0x6FF81213)(g, b);
        if (r != 0) continue;
        int editable = Marshal.ReadInt32(b, 4) & 1, np = Marshal.ReadInt32(b, 8), nc = Marshal.ReadInt32(b, 12);
        int[] o = new int[] { 1, editable, 0, 0, 0, 0, 0, 0, ver };
        for (int p = 0; p < Math.Min(np, 16); p++) {
          int pb = 20 + p * 456;
          if (Marshal.ReadInt32(b, pb) != 0) continue; // P0 بس
          for (int c = 0; c < Math.Min(nc, 8); c++) {
            int cb = pb + 8 + c * 44, dom = Marshal.ReadInt32(b, cb);
            int k = dom == 0 ? 2 : dom == 4 ? 5 : -1; if (k < 0) continue;
            o[k] = Marshal.ReadInt32(b, cb + 12); o[k + 1] = Marshal.ReadInt32(b, cb + 16); o[k + 2] = Marshal.ReadInt32(b, cb + 20);
          }
        }
        return o;
      } finally { Marshal.FreeHGlobal(b); }
    }
    return new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
  }
  public static int SetOffsets(int core_kHz, int mem_kHz) {
    IntPtr g = Gpu(); int ver = GetOffsets()[8]; if (ver == 0) return -999;
    int size = ver & 0xFFFF; IntPtr b = Marshal.AllocHGlobal(size);
    try {
      for (int i = 0; i < size; i++) Marshal.WriteByte(b, i, 0);
      Marshal.WriteInt32(b, 0, ver); Marshal.WriteInt32(b, 8, 1); Marshal.WriteInt32(b, 12, 2);
      int pb = 20; Marshal.WriteInt32(b, pb, 0);
      int c0 = pb + 8; Marshal.WriteInt32(b, c0, 0); Marshal.WriteInt32(b, c0 + 12, core_kHz);
      int c1 = pb + 8 + 44; Marshal.WriteInt32(b, c1, 4); Marshal.WriteInt32(b, c1 + 12, mem_kHz);
      return Fn<FBuf>(0x0F4DAE6B)(g, b);
    } finally { Marshal.FreeHGlobal(b); }
  }

  // ---------- إعدادات التعريف (DRS) على البروفايل العام ----------
  const int SET_SIZE = 12320, SET_VER = SET_SIZE | (1 << 16);
  static IntPtr Session(out IntPtr prof) {
    prof = IntPtr.Zero; Init(); IntPtr s;
    int r = Fn<FOutH>(0x0694D52E)(out s); if (r != 0) throw new Exception("DRS_CreateSession=" + r);
    try {
      r = Fn<FH>(0x375DBD6B)(s); if (r != 0) throw new Exception("DRS_LoadSettings=" + r);
      r = Fn<FHOutH>(0xDA8466A0)(s, out prof); if (r != 0) throw new Exception("DRS_GetBaseProfile=" + r);
      return s;
    } catch { Close(s); throw; }
  }
  static void Close(IntPtr s) { try { Fn<FH>(0xDAD9CFF8)(s); } catch { } }
  // يرجّع [موجود في البروفايل العام؟ 1/0، القيمة، النوع] — النوع 0=DWORD 1=Binary
  public static long[] Get(uint id) {
    IntPtr prof; IntPtr s = Session(out prof); IntPtr b = Marshal.AllocHGlobal(SET_SIZE);
    try {
      for (int i = 0; i < SET_SIZE; i++) Marshal.WriteByte(b, i, 0);
      Marshal.WriteInt32(b, 0, SET_VER);
      int r = Fn<FGet>(0x73BF8338)(s, prof, id, b);
      if (r == -160) return new long[] { 0, 0, -1 }; // NVAPI_SETTING_NOT_FOUND only
      if (r != 0) throw new Exception("DRS_GetSetting=" + r);
      int type = Marshal.ReadInt32(b, 4104), loc = Marshal.ReadInt32(b, 4108);
      long v = type == 1 ? Marshal.ReadInt64(b, 8220 + 4) : (uint)Marshal.ReadInt32(b, 8220);
      return new long[] { loc == 0 ? 1 : 0, v, type };
    } finally { Marshal.FreeHGlobal(b); Close(s); }
  }
  public static int Set(uint id, long value, bool binary) {
    IntPtr prof; IntPtr s = Session(out prof); IntPtr b = Marshal.AllocHGlobal(SET_SIZE);
    try {
      for (int i = 0; i < SET_SIZE; i++) Marshal.WriteByte(b, i, 0);
      Marshal.WriteInt32(b, 0, SET_VER); Marshal.WriteInt32(b, 4100, (int)id); Marshal.WriteInt32(b, 4104, binary ? 1 : 0);
      if (binary) { Marshal.WriteInt32(b, 8220, 8); Marshal.WriteInt64(b, 8224, value); } else Marshal.WriteInt32(b, 8220, (int)(uint)value);
      int r = Fn<FSet>(0x577DD202)(s, prof, b); if (r != 0) return r;
      return Fn<FH>(0xFCBC7E14)(s);
    } finally { Marshal.FreeHGlobal(b); Close(s); }
  }
  public static int Delete(uint id) {
    IntPtr prof; IntPtr s = Session(out prof);
    try { int r = Fn<FDel>(0xE4A26362)(s, prof, id); if (r != 0 && r != -160) return r; return Fn<FH>(0xFCBC7E14)(s); } finally { Close(s); }
  }
}
'@
}

# --------- عمليات التويكات (nvdrs) ---------
function Get-NvDrs($op) { $g = [DemsetNv]::Get([uint32]$op.id); return @{ exists = ($g[0] -eq 1); value = $g[1]; type = $g[2] } }

# --------- كسر سرعة الكرت ---------
function Get-NvPower {
  $smi = Join-Path $env:windir 'System32\nvidia-smi.exe'
  if (-not (Test-Path $smi)) { return $null }
  $l = ((& $smi --query-gpu=power.limit,power.default_limit,power.min_limit,power.max_limit,clocks.max.graphics,clocks.max.memory,name --format=csv,noheader,nounits) 2>$null | Select-Object -First 1)
  if (-not $l) { return $null }
  $p = $l -split ',\s*'
  $num = { param($x) $d = 0.0; if ([double]::TryParse(($x -replace '[^\d\.]', ''), [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$d)) { $d } else { $null } }
  return @{ limit = (& $num $p[0]); def = (& $num $p[1]); min = (& $num $p[2]); max = (& $num $p[3]); maxCore = (& $num $p[4]); maxMem = (& $num $p[5]); name = "$($p[6])".Trim() }
}
function Get-NvOffsets { return [DemsetNv]::GetOffsets() }
function Set-NvOffsets([int]$coreKHz,[int]$memKHz) { return [DemsetNv]::SetOffsets($coreKHz,$memKHz) }
function Set-NvPowerLimit([double]$watts) {
  $smi = Join-Path $env:windir 'System32\nvidia-smi.exe'
  if (-not (Test-Path -LiteralPath $smi -PathType Leaf)) { throw 'nvidia-smi غير متوفر؛ لم يتم تغيير حد الطاقة.' }
  $reply = ((& $smi -pl $watts.ToString([Globalization.CultureInfo]::InvariantCulture)) 2>&1 | Out-String).Trim()
  if ($LASTEXITCODE -ne 0) { throw (($reply -split "`n")[0]) }
}
function Add-NvOcReadback($out) {
  $g = @(Get-NvOffsets)
  if ($g.Count -lt 8) { throw 'تعذّر التحقق من بيانات السرعات.' }
  $out.supported = ($g[0] -eq 1); $out.editable = ($g[1] -eq 1)
  $out.core = $g[2] / 1000.0; $out.coreMin = $g[3] / 1000.0; $out.coreMax = $g[4] / 1000.0
  $out.mem = $g[5] / 1000.0; $out.memMin = $g[6] / 1000.0; $out.memMax = $g[7] / 1000.0
  $out.power = Get-NvPower
}
function Invoke-GpuOc($cfg) {
  $out = @{ ok = $false; supported = $false }
  $before = $null; $initialPower = $null; $writeAttempted = $false; $powerAttempted = $false
  try {
    if ($cfg.action -notin @('get','set')) { throw 'طلب كسر سرعة غير صالح.' }
    if ($cfg.action -eq 'set') {
      $before = @(Get-NvOffsets)
      if ($before.Count -lt 8 -or $before[0] -ne 1 -or $before[1] -ne 1) { throw 'كرتك أو التعريف لا يسمح بتعديل السرعات بهذه الطريقة.' }
      if ($null -eq $cfg.core -or $null -eq $cfg.mem) { throw 'لازم تحدد قيمة النواة والذاكرة.' }
      $coreMHz = [double]$cfg.core; $memMHz = [double]$cfg.mem
      if ([double]::IsNaN($coreMHz) -or [double]::IsInfinity($coreMHz) -or [double]::IsNaN($memMHz) -or [double]::IsInfinity($memMHz) -or $coreMHz -ne [math]::Truncate($coreMHz) -or $memMHz -ne [math]::Truncate($memMHz)) { throw 'قيمة السرعة لازم تكون رقم MHz صحيحًا.' }
      $coreKHz = [int]($coreMHz * 1000); $memKHz = [int]($memMHz * 1000)
      if ($coreKHz -lt $before[3] -or $coreKHz -gt $before[4] -or $memKHz -lt $before[6] -or $memKHz -gt $before[7]) { throw 'القيم خارج الحدود التي يسمح بها تعريف الكرت.' }
      if ($null -ne $cfg.power) {
        $wantedPower = [double]$cfg.power; $initialPower = Get-NvPower
        if ([double]::IsNaN($wantedPower) -or [double]::IsInfinity($wantedPower) -or -not $initialPower -or $null -eq $initialPower.min -or $null -eq $initialPower.max -or $null -eq $initialPower.limit -or $wantedPower -lt $initialPower.min -or $wantedPower -gt $initialPower.max) { throw 'حد الطاقة غير مدعوم أو خارج حدود الكرت؛ لم نكتب أي تغيير.' }
      }
      $writeAttempted = $true
      $r = Set-NvOffsets $coreKHz $memKHz
      if ($r -ne 0) { throw "التعريف رفض القيم (كود $r)" }
      $verify = @(Get-NvOffsets)
      if ($verify.Count -lt 8 -or $verify[0] -ne 1 -or $verify[2] -ne $coreKHz -or $verify[5] -ne $memKHz) { throw 'القيم المقروءة لا تطابق السرعات المطلوبة؛ لم نعتبر التعديل ناجحًا.' }
      if ($null -ne $cfg.power) {
        try {
          $powerAttempted = $true
          Set-NvPowerLimit $wantedPower
          $readPower = Get-NvPower
          if (-not $readPower -or $null -eq $readPower.limit -or [math]::Abs([double]$readPower.limit - $wantedPower) -gt 0.5) { throw 'حد الطاقة المقروء لا يطابق الطلب.' }
        } catch { $out.powerError = $_.Exception.Message; throw }
      }
      Log ("  تم التحقق: نواة " + $coreMHz + " MHz، ذاكرة " + $memMHz + " MHz")
    }
    Add-NvOcReadback $out
    $out.ok = $out.supported -and -not $out.error -and -not $out.powerError
    if (-not $out.supported) { $out.error = 'التعريف ما رد على قراءة السرعات — كرتك أو نسخة التعريف ما تدعم هالطريقة' }
  } catch {
    $out.error = $_.Exception.Message
    if ($writeAttempted -and $before) {
      $rollbackErrors = @()
      try {
        $code = Set-NvOffsets ([int]$before[2]) ([int]$before[5])
        $check = @(Get-NvOffsets)
        if ($code -ne 0 -or $check.Count -lt 8 -or $check[0] -ne 1 -or $check[2] -ne $before[2] -or $check[5] -ne $before[5]) { throw 'تعذّر التحقق من استعادة السرعات الأصلية.' }
      } catch { $rollbackErrors += $_.Exception.Message }
      if ($powerAttempted -and $initialPower) {
        try {
          Set-NvPowerLimit ([double]$initialPower.limit)
          $checkPower = Get-NvPower
          if (-not $checkPower -or $null -eq $checkPower.limit -or [math]::Abs([double]$checkPower.limit - [double]$initialPower.limit) -gt 0.5) { throw 'تعذّر التحقق من استعادة حد الطاقة الأصلي.' }
        } catch { $rollbackErrors += $_.Exception.Message }
      }
      $out.rollback = @{ok=($rollbackErrors.Count -eq 0);errors=$rollbackErrors}
      if ($rollbackErrors.Count) { $out.error += '؛ فشلت استعادة بعض القيم، راجع السرعات وحد الطاقة: ' + ($rollbackErrors -join ' / ') }
    }
    try { Add-NvOcReadback $out } catch {}
    $out.ok = $false
  }
  Emit 'gpuoc' (ConvertTo-Json -InputObject $out -Compress -Depth 4)
}
