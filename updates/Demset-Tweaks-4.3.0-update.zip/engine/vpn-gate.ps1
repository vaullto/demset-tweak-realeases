﻿# VPN Gate's official volunteer CSV; never execute a downloaded configuration verbatim.
# https://www.vpngate.net/en/ and https://www.vpngate.net/api/iphone/
function Get-GateServers {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  $csv = (Invoke-WebRequest -UseBasicParsing -Uri 'https://www.vpngate.net/api/iphone/' -TimeoutSec 20 -ErrorAction Stop).Content
  if ($csv.Length -gt 20MB) { throw 'قائمة السيرفرات أكبر من المتوقع' }
  $lines = @($csv -split '\r?\n' | Where-Object { $_ -and $_ -notmatch '^\*' })
  if (-not $lines.Count -or $lines[0] -notmatch '^#HostName,IP,') { throw 'رد VPN Gate غير صالح' }
  $lines[0] = $lines[0].TrimStart('#')
  return @($lines | ConvertFrom-Csv | Where-Object { $_.HostName -match '^[a-zA-Z0-9-]+$' -and $_.CountryShort -match '^[A-Z]{2}$' -and $_.OpenVPN_ConfigData_Base64 })
}
function ConvertTo-SafeGateConfig([string]$base64) {
  $raw = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($base64))
  if ($raw.Length -gt 256KB) { throw 'ملف الاتصال أكبر من المتوقع' }
  $safe = @(); $block = $null; $remote = $false; $ca = $false
  # No plugin, up/down, route-up, script-security, management, external file paths or auth scripts.
  $allowed = @('client','dev','proto','remote','resolv-retry','nobind','persist-key','persist-tun','cipher','data-ciphers','auth','verb','mute','remote-cert-tls','verify-x509-name','tls-version-min','connect-retry','connect-timeout','reneg-sec','sndbuf','rcvbuf','explicit-exit-notify','pull','route-delay','auth-nocache','comp-lzo')
  foreach ($line in @($raw -split '\r?\n')) {
    $l = $line.Trim(); if (-not $l -or $l -match '^[#;]') { continue }
    if ($block) {
      if ($l -eq "</$block>") { $safe += $l; $block = $null; continue }
      if ($l -notmatch '^[-A-Za-z0-9+/= :]+$') { throw 'شهادة غير صالحة' }
      $safe += $l; continue
    }
    if ($l -match '^<(ca|cert|key|tls-auth|tls-crypt)>$') { $block = $Matches[1]; if ($block -eq 'ca') { $ca = $true }; $safe += $l; continue }
    $parts = $l -split '\s+'; $directive = $parts[0].ToLowerInvariant()
    if ($allowed -notcontains $directive) { continue }
    if ($l -match '["''`$;&|<>\\]') { throw 'تعليمات اتصال غير آمنة' }
    if ($directive -eq 'remote') {
      $address = $null
      if ($parts.Count -lt 3 -or -not [Net.IPAddress]::TryParse($parts[1], [ref]$address) -or $address.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork -or $parts[2] -notmatch '^\d+$' -or [int]$parts[2] -lt 1 -or [int]$parts[2] -gt 65535) { throw 'عنوان السيرفر غير صالح' }
      $remote = $true
    }
    if ($directive -eq 'dev' -and $parts[1] -ne 'tun') { throw 'نوع اتصال غير مدعوم' }
    if ($directive -in @('comp-lzo','remote-cert-tls','tls-version-min','cipher','data-ciphers','auth')) { continue } # Policy is fixed below, not controlled by downloaded metadata.
    $safe += $l
  }
  if ($block -or -not $remote -or -not $ca) { throw 'ملف الاتصال ناقص' }
  $safe += 'remote-cert-tls server'; $safe += 'tls-version-min 1.2'
  $safe += 'data-ciphers AES-256-GCM:AES-128-GCM:CHACHA20-POLY1305:AES-128-CBC'
  $safe += 'data-ciphers-fallback AES-128-CBC'; $safe += 'auth SHA1'
  $safe += 'auth-nocache'; $safe += 'allow-compression no'; $safe += 'script-security 1'; $safe += 'verb 3'
  return ($safe -join "`r`n")
}
function Invoke-GateVpn([string]$action, $cfg) {
  $exe = Join-Path $env:ProgramFiles 'OpenVPN\bin\openvpn.exe'
  $result = @{ provider = 'gate'; installed = (Test-Path -LiteralPath $exe); state = 'disconnected' }
  try {
    if ($action -eq 'countries') {
      $servers = @(Get-GateServers)
      $result.servers = @($servers | ForEach-Object { @{ id = $_.HostName; country = $_.CountryLong; cc = $_.CountryShort; ping = $_.Ping; speed = $_.Speed; score = $_.Score } })
      $result.source = 'https://www.vpngate.net/en/'; $result.at = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
    } else {
      if (-not $cfg.gateDir) { throw 'مسار حالة الاتصال غير موجود' }
      $dir = [IO.Path]::GetFullPath([string]$cfg.gateDir)
      New-Item -ItemType Directory -Path $dir -Force -ErrorAction Stop | Out-Null
      $stateFile = Join-Path $dir 'session.json'; $logFile = Join-Path $dir 'connection.log'; $profile = Join-Path $dir 'demset-gate.ovpn'
      $session = $null; $process = $null
      if (Test-Path -LiteralPath $stateFile) {
        $session = Get-Content -LiteralPath $stateFile -Raw | ConvertFrom-Json
        $process = Get-Process -Id $session.pid -ErrorAction SilentlyContinue
        if ($process) { try { if ($process.Path -ne $exe -or $process.StartTime.ToUniversalTime().Ticks -ne [int64]$session.startTicks) { $process = $null } } catch { $process = $null } }
      }
      if ($action -eq 'countryDisconnect') {
        if ($process) {
          # OpenVPN's documented Windows exit-event performs route/DNS cleanup.
          # Do not force-kill a networking process and pretend the tunnel reverted.
          if ($session.exitEvent -notmatch '^Global\\DemsetGate-[a-f0-9]{32}$') { throw 'حدث إيقاف الاتصال غير صالح' }
          $exit = [Threading.EventWaitHandle]::OpenExisting([string]$session.exitEvent)
          try { $exit.Set() | Out-Null; $process.WaitForExit(12000) | Out-Null } finally { $exit.Dispose() }
        }
        if ($process -and -not $process.HasExited) { throw 'عملية الاتصال ما توقفت' }
        Remove-Item -LiteralPath $stateFile -ErrorAction SilentlyContinue
      } elseif ($action -eq 'countryConnect') {
        if (-not $result.installed) { throw 'ثبّت OpenVPN Community أولًا' }
        if ($process) { throw 'افصل الاتصال الحالي أولًا' }
        $server = @(Get-GateServers | Where-Object { $_.HostName -eq [string]$cfg.id }) | Select-Object -First 1
        if (-not $server) { throw 'السيرفر ما عاد متوفر؛ حدّث قائمة الدول' }
        $content = ConvertTo-SafeGateConfig $server.OpenVPN_ConfigData_Base64
        [IO.File]::WriteAllText($profile, $content, (New-Object Text.UTF8Encoding($false)))
        [IO.File]::WriteAllText($logFile, '')
        $exitEvent = 'Global\DemsetGate-' + [guid]::NewGuid().ToString('N')
        $process = Start-Process -FilePath $exe -ArgumentList @('--config', ('"' + $profile + '"'), '--log', ('"' + $logFile + '"'), '--service', $exitEvent, '0') -WindowStyle Hidden -PassThru -ErrorAction Stop
        $session = @{ pid = $process.Id; startTicks = $process.StartTime.ToUniversalTime().Ticks; country = $server.CountryLong; cc = $server.CountryShort; server = $server.HostName; exitEvent = $exitEvent }
        $session | ConvertTo-Json | Set-Content -LiteralPath $stateFile -Encoding UTF8
        Start-Sleep -Milliseconds 1200
      }
      if ($process -and -not $process.HasExited -and $action -ne 'countryDisconnect') {
        $text = if (Test-Path -LiteralPath $logFile) { Get-Content -LiteralPath $logFile -Tail 80 | Out-String } else { '' }
        $lastState = @($text -split '\r?\n' | Where-Object { $_ -match 'Initialization Sequence Completed|AUTH_FAILED|Exiting due to fatal error|TLS Error|Options error|SIGUSR1.*restarting|Restart pause|TCP/UDP.*link remote' }) | Select-Object -Last 1
        $result.state = if ($lastState -match 'Initialization Sequence Completed') { 'connected' } elseif ($lastState -match 'AUTH_FAILED|Exiting due to fatal error|TLS Error|Options error') { 'error' } else { 'connecting' }
        $result.country = $session.country; $result.cc = $session.cc; $result.server = $session.server
        if ($result.state -eq 'error') { $result.error = 'السيرفر رفض الاتصال أو غير متوافق. افصل وجرّب سيرفر ثاني.' }
      } elseif ($session -and $action -ne 'countryDisconnect') { $result.state = 'error'; $result.error = 'الاتصال توقف؛ جرّب سيرفر ثاني. بعض السيرفرات القديمة غير متوافقة مع التشفير الحالي.' }
    }
  } catch { $result.error = $_.Exception.Message }
  Emit 'vpn' ($result | ConvertTo-Json -Compress -Depth 5)
}
