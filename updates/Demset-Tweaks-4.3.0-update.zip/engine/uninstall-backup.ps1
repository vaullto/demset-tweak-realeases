﻿# Only remove confirmed leftovers; every entry is saved before its mutation.
function Save-LeftoverManifest($path, $items) {
  $json = ConvertTo-Json -InputObject @($items) -Depth 10
  $utf8 = New-Object Text.UTF8Encoding($true)
  $bytes = $utf8.GetPreamble() + $utf8.GetBytes($json)
  $tmp = $path + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
  try {
    $stream = New-Object IO.FileStream($tmp, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None, 4096, [IO.FileOptions]::WriteThrough)
    try { $stream.Write($bytes, 0, $bytes.Length); $stream.Flush($true) } finally { $stream.Dispose() }
    if ([IO.File]::Exists($path)) { [IO.File]::Replace($tmp, $path, [NullString]::Value) }
    else { [IO.File]::Move($tmp, $path) }
  } finally { if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue } }
}
function Remove-Leftovers($cfg) {
  $bk = [IO.Path]::GetFullPath([string]$cfg.backup)
  New-Item -ItemType Directory -Force -Path $bk -ErrorAction Stop | Out-Null
  $manifestFile = Join-Path $bk 'manifest.json'; $manifest = @(); $done = @(); $i = 0
  foreach ($it in @($cfg.items)) {
    $i++; $res = @{ kind = $it.kind; path = $it.path; ok = $false }
    $entry = @{ kind = $it.kind; path = $it.path; ready = $false; restored = $false }
    try {
      switch ($it.kind) {
        { $_ -in @('folder','file') } {
          if (-not (Test-SafeLeftoverPath $it.path)) { throw 'مسار محمي' }
          $original = [IO.Path]::GetFullPath([string]$it.path)
          if (-not (Test-Path -LiteralPath $original)) { throw 'العنصر غير موجود؛ لم يحتسب كحذف جديد' }
          $node = Get-Item -LiteralPath $original -Force -ErrorAction Stop
          if ($node.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'لن نحذف رابط مجلد أو مسار تحويل' }
          $entry.backup = Join-Path $bk ("payload-$i"); $entry.path = $original
          $manifest += $entry; Save-LeftoverManifest $manifestFile $manifest
          Move-Item -LiteralPath $original -Destination $entry.backup -ErrorAction Stop
          if ((Test-Path -LiteralPath $original) -or -not (Test-Path -LiteralPath $entry.backup)) { throw 'لم يكتمل نقل العنصر إلى النسخة الاحتياطية' }
          $res.note = 'انتقل لنسخة احتياطية قابلة للاستعادة'
        }
        'regkey' {
          if ($it.path -notmatch '^HK(CU|LM)\\(SOFTWARE|Software)\\.+' -or $it.path -match '\\(Microsoft|Classes|Policies|Wow6432Node)$') { throw 'مفتاح محمي' }
          $entry.backup = Join-Path $bk ("reg-$i.reg")
          & reg.exe export $it.path $entry.backup /y 2>&1 | Out-Null
          if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $entry.backup)) { throw 'فشل تصدير النسخة الاحتياطية' }
          $manifest += $entry; Save-LeftoverManifest $manifestFile $manifest
          & reg.exe delete $it.path /f 2>&1 | Out-Null
          if ($LASTEXITCODE -ne 0 -or (Test-RegKey $it.path)) { throw 'المفتاح باقي أو الحذف مرفوض' }
          $res.note = 'حذف موثّق بعد تصدير المفتاح'
        }
        'runvalue' {
          $parts = $it.path -split '\|', 2
          if ($parts.Count -ne 2 -or $parts[0] -notmatch '^HK(CU|LM)\\SOFTWARE\\(WOW6432Node\\)?Microsoft\\Windows\\CurrentVersion\\Run$') { throw 'مسار بدء تشغيل غير صالح' }
          $entry.registry = Get-RegState $parts[0] $parts[1]
          if (-not $entry.registry.exists) { throw 'قيمة بدء التشغيل غير موجودة' }
          $manifest += $entry; Save-LeftoverManifest $manifestFile $manifest
          Remove-RegValue $parts[0] $parts[1]
          if ((Get-RegState $parts[0] $parts[1]).exists) { throw 'قيمة بدء التشغيل باقية' }
          $res.note = 'حفظنا القيمة الأصلية ونوعها فقط'
        }
        'task' {
          if ($it.tpath -like '\Microsoft\*') { throw 'مهمة نظام محمية' }
          $entry.tname = $it.tname; $entry.tpath = $it.tpath; $entry.backup = Join-Path $bk ("task-$i.xml")
          Export-ScheduledTask -TaskName $it.tname -TaskPath $it.tpath -ErrorAction Stop | Set-Content -LiteralPath $entry.backup -Encoding Unicode -ErrorAction Stop
          $manifest += $entry; Save-LeftoverManifest $manifestFile $manifest
          Unregister-ScheduledTask -TaskName $it.tname -TaskPath $it.tpath -Confirm:$false -ErrorAction Stop
          if (Get-ScheduledTask -TaskName $it.tname -TaskPath $it.tpath -ErrorAction SilentlyContinue) { throw 'المهمة ما زالت موجودة' }
          $res.note = 'انحذفت المهمة مع حفظ XML ومسارها'
        }
        'service' {
          # Exact complete registry export preserves account/dependencies/configuration.
          if ($it.path -notmatch '^[A-Za-z0-9_. -]+$') { throw 'اسم خدمة غير صالح' }
          $sv = Get-CimInstance Win32_Service -Filter ("Name='" + $it.path + "'") -ErrorAction Stop
          if (-not $sv -or $sv.PathName -match '(?i)\\Windows\\') { throw 'خدمة نظام أو خدمة غير موجودة' }
          $entry.backup = Join-Path $bk ("svc-$i.reg")
          $serviceKey = 'HKLM\SYSTEM\CurrentControlSet\Services\' + $it.path
          & reg.exe export $serviceKey $entry.backup /y 2>&1 | Out-Null
          if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $entry.backup)) { throw 'فشل حفظ إعدادات الخدمة كاملة' }
          $manifest += $entry; Save-LeftoverManifest $manifestFile $manifest
          Stop-Service -Name $it.path -ErrorAction Stop
          & sc.exe delete $it.path 2>&1 | Out-Null
          if ($LASTEXITCODE -ne 0) { throw 'فشل حذف الخدمة' }
          $entry.reboot = $true; $res.note = 'طلب حذف الخدمة مقبول؛ قد يكتمل بعد إعادة التشغيل'; $res.reboot = $true
        }
        default { throw 'نوع عنصر غير مدعوم' }
      }
      $entry.ready = $true; $res.ok = $true; $res.backup = $entry.backup
      Save-LeftoverManifest $manifestFile $manifest
      Log ('  ✓ ' + $it.path + ' — ' + $res.note)
    } catch { $res.ok = $false; $res.error = $_.Exception.Message; Warn ('  ✗ ' + $it.path + ': ' + $res.error) }
    $done += $res
  }
  Emit 'leftclean' (ConvertTo-Json -InputObject @($done) -Compress -Depth 5)
}
function Restore-UninstallBackup([string]$dir) {
  $file = Join-Path $dir 'manifest.json'; $n = 0; $failed = @(); $reboot = $false
  if (-not (Test-Path -LiteralPath $file)) {
    # Older releases have only .reg/XML exports; preserve their limited restoration.
    foreach ($f in @(Get-ChildItem -LiteralPath $dir -Filter '*.reg' -ErrorAction SilentlyContinue)) { & reg.exe import $f.FullName 2>&1 | Out-Null; if ($LASTEXITCODE -eq 0) { $n++ } else { $failed += @{ path = $f.Name; error = 'فشل استيراد المفتاح' } } }
    foreach ($f in @(Get-ChildItem -LiteralPath $dir -Filter 'task-*.xml' -ErrorAction SilentlyContinue)) {
      try { $raw = Get-Content -LiteralPath $f.FullName -Raw; $x = [xml]$raw; $uri = [string]$x.Task.RegistrationInfo.URI; if (-not $uri) { throw 'ملف قديم دون مسار المهمة' }; $cut = $uri.LastIndexOf('\'); Register-ScheduledTask -Xml $raw -TaskName $uri.Substring($cut + 1) -TaskPath $uri.Substring(0,$cut + 1) -Force -ErrorAction Stop | Out-Null; $n++ } catch { $failed += @{ path = $f.Name; error = $_.Exception.Message } }
    }
  } else {
    # Windows PowerShell 5.1 writes a JSON root array as one pipeline object.
    # Enumerate explicitly so a single-entry manifest isn't nested Object[].
    $decoded = Get-Content -LiteralPath $file -Raw | ConvertFrom-Json
    $entries = @(); foreach ($item in $decoded) { $entries += $item }
    :restoreEntry foreach ($e in $entries) {
      if ($e.restored) { continue }
      # A crash can happen after the mutation but before committing ready=true.
      # The prepared manifest remains durable; infer only provable recovery work.
      if (-not $e.ready) {
        switch ($e.kind) {
          { $_ -in @('folder','file') } { if (-not $e.backup -or -not (Test-Path -LiteralPath $e.backup)) { continue restoreEntry } }
          'runvalue' {
            $preparedParts = $e.path -split '\|',2
            if ($preparedParts.Count -ne 2 -or -not $e.registry.exists -or (Get-RegState $preparedParts[0] $preparedParts[1]).exists) { continue restoreEntry }
          }
          'regkey' { if (-not $e.backup -or -not (Test-Path -LiteralPath $e.backup) -or (Test-RegKey $e.path)) { continue restoreEntry } }
          'service' {
            $preparedServiceKey = 'HKLM\SYSTEM\CurrentControlSet\Services\' + $e.path
            if (-not $e.backup -or -not (Test-Path -LiteralPath $e.backup) -or (Test-RegKey $preparedServiceKey)) { continue restoreEntry }
          }
          'task' {
            if (-not $e.backup -or -not (Test-Path -LiteralPath $e.backup) -or (Get-ScheduledTask -TaskName $e.tname -TaskPath $e.tpath -ErrorAction SilentlyContinue)) { continue restoreEntry }
          }
          default { continue restoreEntry }
        }
      }
      try {
        switch ($e.kind) {
          { $_ -in @('folder','file') } {
            if (-not (Test-SafeLeftoverPath $e.path)) { throw 'مسار الاستعادة محمي أو يحتوي رابط تحويل' }
            if (Test-Path -LiteralPath $e.path) { throw 'المسار موجود؛ لم نستبدل ملفاتك الحالية' }
            $parent = Split-Path -Parent $e.path; New-Item -ItemType Directory -Path $parent -Force -ErrorAction Stop | Out-Null
            Move-Item -LiteralPath $e.backup -Destination $e.path -ErrorAction Stop
            if (-not (Test-Path -LiteralPath $e.path)) { throw 'فشل استرجاع الملف' }
          }
          { $_ -in @('regkey','service') } { & reg.exe import $e.backup 2>&1 | Out-Null; if ($LASTEXITCODE -ne 0) { throw 'فشل استيراد النسخة' }; if ($e.kind -eq 'service') { $reboot = $true } }
          'runvalue' { $p = $e.path -split '\|',2; if ((Get-RegState $p[0] $p[1]).exists) { throw 'قيمة بدء التشغيل موجودة الآن؛ لم نستبدلها' }; Set-RegValue $p[0] $p[1] $e.registry.kind $e.registry.value; if (-not (Get-RegState $p[0] $p[1]).exists) { throw 'لم ترجع قيمة بدء التشغيل' } }
          'task' { Register-ScheduledTask -Xml (Get-Content -LiteralPath $e.backup -Raw) -TaskName $e.tname -TaskPath $e.tpath -ErrorAction Stop | Out-Null }
          default { throw 'نوع نسخة غير مدعوم' }
        }
        $e.restored = $true; $n++; Save-LeftoverManifest $file $entries
      } catch { $failed += @{ path = $e.path; error = $_.Exception.Message } }
    }
  }
  Emit 'uninstrestore' (@{ count = $n; failed = @($failed); reboot = $reboot; ok = ($n -gt 0 -and $failed.Count -eq 0) } | ConvertTo-Json -Compress -Depth 5)
  Emit 'result' ('done:' + $n + ':' + $failed.Count)
}
