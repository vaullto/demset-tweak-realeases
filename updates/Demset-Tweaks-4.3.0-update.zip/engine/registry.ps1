﻿# Registry Tweaks is deliberately separate from the general optimizer. Scanning
# performs no writes. Values, types and paths are chosen by this allowlist only.
function Get-RegistryTweakDefinitions {
  return @(
    @{ id = 'reg_game_capture'; path = 'HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR'; name = 'AllowGameDVR'; kind = 'DWord'; value = 0; minBuild = 10240; maxBuild = 21999; policy = $true; risk = 'safe'; reboot = $true },
    @{ id = 'reg_background_apps'; path = 'HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy'; name = 'LetAppsRunInBackground'; kind = 'DWord'; value = 2; minBuild = 15063; policy = $true; risk = 'medium'; reboot = $true },
    @{ id = 'reg_power_throttling'; path = 'HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling'; name = 'PowerThrottlingOff'; kind = 'DWord'; value = 1; minBuild = 22000; policy = $true; desktop = $true; risk = 'medium'; reboot = $true },
    @{ id = 'reg_foreground_priority'; path = 'HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl'; name = 'Win32PrioritySeparation'; kind = 'DWord'; value = 38; minBuild = 10240; risk = 'medium'; reboot = $true }
  )
}

function Get-RegistryHardware {
  $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
  $pc = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
  $cpu = @(Get-CimInstance Win32_Processor -ErrorAction Stop)
  $gpu = @(Get-CimInstance Win32_VideoController -ErrorAction Stop | ForEach-Object { @{ name = $_.Name; driver = $_.DriverVersion; pnpId = $_.PNPDeviceID } })
  $cv = Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -ErrorAction Stop
  $batteries = @(Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue)
  return @{
    os = $os.Caption; build = [int]$os.BuildNumber; ubr = $cv.UBR; edition = $cv.EditionID
    client = ([int]$os.ProductType -eq 1); ramGB = [math]::Round([double]$pc.TotalPhysicalMemory / 1GB, 2)
    cpu = ($cpu | ForEach-Object { $_.Name }) -join ' / '; threads = [int]$pc.NumberOfLogicalProcessors
    gpus = $gpu; laptop = ($batteries.Count -gt 0 -or [int]$pc.PCSystemType -eq 2)
    managed = [bool]$pc.PartOfDomain; scannedAt = [DateTime]::UtcNow.ToString('o')
  }
}

function Test-RegistryCompatibility($d, $hw) {
  if (-not $hw.client -or $hw.build -lt $d.minBuild) { return 'إصدار ويندوز غير مدعوم لهذا التعديل.' }
  if ($d.maxBuild -and $hw.build -gt $d.maxBuild) { return 'هذه السياسة موثّقة لويندوز 10 فقط؛ لا نطبّقها على ويندوز 11.' }
  if ($d.policy -and $hw.edition -notmatch '^(Professional|Enterprise|Education|IoTEnterprise)') { return 'سياسة غير موثّقة لنسخة ويندوز الحالية؛ لن تُطبّق.' }
  if ($d.desktop -and $hw.laptop) { return 'غير مقترح على الأجهزة المحمولة بسبب الطاقة والحرارة.' }
  if ($hw.managed) { return 'الجهاز مرتبط بدومين؛ راجع مسؤول النظام قبل تغيير سياساته.' }
  return ''
}

function Test-RegistryStateEqual($a, $b) {
  if ([bool]$a.exists -ne [bool]$b.exists) { return $false }
  if (-not $a.exists) { return $true }
  if ([string]$a.kind -ne [string]$b.kind) { return $false }
  return ((ConvertTo-Json -InputObject $a.value -Compress -Depth 5) -ceq (ConvertTo-Json -InputObject $b.value -Compress -Depth 5))
}

function Save-RegistrySnapshot([string]$file, $obj) {
  $dir = Split-Path -Parent $file
  [void][System.IO.Directory]::CreateDirectory($dir)
  $tmp = $file + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
  try {
    $json = ConvertTo-Json -InputObject $obj -Depth 12
    $bytes = (New-Object System.Text.UTF8Encoding($false)).GetBytes($json)
    # WriteThrough and Flush(true) make the recoverable baseline durable before
    # any registry write, including if the application exits mid-operation.
    $stream = New-Object System.IO.FileStream($tmp, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None, 4096, [IO.FileOptions]::WriteThrough)
    try { $stream.Write($bytes, 0, $bytes.Length); $stream.Flush($true) } finally { $stream.Dispose() }
    if (Test-Path -LiteralPath $file) { [IO.File]::Replace($tmp, $file, [NullString]::Value) } else { [IO.File]::Move($tmp, $file) }
  } finally { if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force } }
}

function Read-RegistrySnapshot([string]$file, $d) {
  if (-not (Test-Path -LiteralPath $file)) { return $null }
  $b = Get-Content -LiteralPath $file -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
  if ($b.schema -ne 1 -or $b.id -cne $d.id -or $b.path -cne $d.path -or $b.name -cne $d.name -or $null -eq $b.original -or $b.original.exists -isnot [bool]) { throw 'ملف النسخة الاحتياطية غير صالح؛ لم يتم تغيير الريجستري.' }
  if ($b.original.exists -and ($b.original.kind -notin @('DWord', 'QWord', 'String', 'ExpandString', 'MultiString', 'Binary') -or $null -eq $b.original.PSObject.Properties['value'])) { throw 'نوع النسخة الاحتياطية غير صالح؛ لم يتم تغيير الريجستري.' }
  return $b
}

function Restore-RegistryValue($d, $original) {
  if ($original.exists) { Set-RegValueDirect $d.path $d.name $original.kind $original.value }
  else { Remove-RegValueDirect $d.path $d.name }
  if (-not (Test-RegistryStateEqual (Get-RegState $d.path $d.name) $original)) { throw ('تعذّر التحقق من استعادة ' + $d.name) }
}

function Invoke-RegistryChange($d, $hw, [string]$dir, [string]$action) {
  $file = Join-Path $dir ($d.id + '.json')
  $b = Read-RegistrySnapshot $file $d
  $before = Get-RegState $d.path $d.name
  $wanted = @{ exists = $true; kind = $d.kind; value = $d.value }
  if ($action -eq 'apply') {
    $reason = Test-RegistryCompatibility $d $hw
    if ($reason) { throw $reason }
    if (Test-RegistryStateEqual $before $wanted) { return @{ id = $d.id; ok = $true; changed = $false } }
    if ($b -and $b.active) { throw 'توجد نسخة أصلية نشطة والقيمة تغيّرت خارج هذا القسم. استعدها أولًا قبل إعادة التطبيق.' }
    $b = @{ schema = 1; id = $d.id; path = $d.path; name = $d.name; original = $before; active = $true; at = [DateTime]::UtcNow.ToString('o') }
    Save-RegistrySnapshot $file $b
    try {
      # Never bypass registry protection through a SYSTEM scheduled task.
      Set-RegValueDirect $d.path $d.name $d.kind $d.value
      if (-not (Test-RegistryStateEqual (Get-RegState $d.path $d.name) $wanted)) { throw 'لم تنجح قراءة التحقق بعد الكتابة.' }
      return @{ id = $d.id; ok = $true; changed = $true; reboot = [bool]$d.reboot }
    } catch {
      $failure = $_.Exception.Message
      try { Restore-RegistryValue $d $before; $b.active = $false; Save-RegistrySnapshot $file $b }
      catch { throw ($failure + '؛ فشلت الاستعادة التلقائية أيضًا: ' + $_.Exception.Message + '؛ النسخة الأصلية محفوظة.') }
      throw ($failure + '؛ تمت استعادة القيمة الأصلية.')
    }
  }
  if (-not $b -or -not $b.active) { return @{ id = $d.id; ok = $true; changed = $false } }
  # Do not silently overwrite a newer change made by another application.
  if (-not (Test-RegistryStateEqual $before $wanted) -and -not (Test-RegistryStateEqual $before $b.original)) { throw 'القيمة تغيّرت خارج هذا القسم؛ أوقف التعديل المتعارض قبل استعادة النسخة الأصلية.' }
  Restore-RegistryValue $d $b.original
  $b.active = $false
  Save-RegistrySnapshot $file $b
  return @{ id = $d.id; ok = $true; changed = $true; reboot = [bool]$d.reboot }
}

function Get-RegistryScan($hw, [string]$dir, $results) {
  $items = @()
  foreach ($d in @(Get-RegistryTweakDefinitions)) {
    try {
      $current = Get-RegState $d.path $d.name
      $wanted = @{ exists = $true; kind = $d.kind; value = $d.value }
      $b = Read-RegistrySnapshot (Join-Path $dir ($d.id + '.json')) $d
      $reason = Test-RegistryCompatibility $d $hw
      $matches = Test-RegistryStateEqual $current $wanted
      $equivalent = ($d.id -eq 'reg_foreground_priority' -and $current.exists -and $current.kind -eq 'DWord' -and [int]$current.value -eq 2)
      $recommended = $false
      if ($d.id -eq 'reg_game_capture' -and -not $reason -and -not $matches) {
        $capture = Get-RegState 'HKCU\System\GameConfigStore' 'GameDVR_Enabled'
        $recommended = ($capture.exists -and $capture.kind -eq 'DWord' -and [int]$capture.value -eq 1)
      }
      $items += @{ id = $d.id; path = $d.path; name = $d.name; current = $current; proposed = $wanted
        compatible = (-not [bool]$reason); reason = $reason; recommended = $recommended; equivalent = $equivalent
        matches = $matches; applied = [bool]($b -and $b.active); reboot = [bool]$d.reboot
        status = $(if ($b -and $b.active) { if ($matches) { 'applied' } else { 'drifted' } } elseif ($matches) { 'already' } elseif ($equivalent) { 'equivalent' } elseif ($reason) { 'unsupported' } else { 'available' }) }
    } catch { $items += @{ id = $d.id; compatible = $false; status = 'error'; error = $_.Exception.Message; recommended = $false } }
  }
  return @{ ok = (@($results | Where-Object { -not $_.ok }).Count -eq 0); hardware = $hw; items = $items; results = @($results)
    memoryNote = 'تم قياس الرام الفعلية. لم نجد إعداد ذاكرة موثّقًا يحتاج قيمة محسوبة من حجم الرام ضمن هذه المكتبة؛ لا نكتب أرقامًا عشوائية ولا نغيّر ملف الترحيل.' }
}

function Invoke-RegistryTweaks($cfg) {
  try {
    if ($cfg.action -notin @('scan', 'apply', 'revert', 'revertAll')) { throw 'طلب Registry غير صالح.' }
    if (-not $cfg.backupDir -or -not [IO.Path]::IsPathRooted([string]$cfg.backupDir)) { throw 'مسار النسخ الاحتياطي غير صالح.' }
    $defs = @(Get-RegistryTweakDefinitions)
    $ids = @($cfg.ids)
    if ($cfg.action -eq 'revertAll') { $ids = @($defs | ForEach-Object { $_.id }) }
    foreach ($id in $ids) { if ($id -notin @($defs | ForEach-Object { $_.id })) { throw ('تعديل غير معروف: ' + $id) } }
    try { $hw = Get-RegistryHardware }
    catch {
      # Restoring a recorded baseline must still work if CIM is temporarily
      # unavailable. New writes require a successful hardware/OS scan.
      if ($cfg.action -notin @('revert', 'revertAll')) { throw }
      $hw = @{ client = $false; build = 0; edition = 'Unknown'; os = 'تعذّر تحديث معلومات الجهاز؛ الاستعادة تستخدم النسخة الأصلية.'; ramGB = $null; cpu = ''; gpus = @(); scannedAt = [DateTime]::UtcNow.ToString('o') }
    }
    $results = @()
    if ($cfg.action -ne 'scan') {
      foreach ($id in @($ids | Select-Object -Unique)) {
        $d = $defs | Where-Object { $_.id -eq $id } | Select-Object -First 1
        try { $results += Invoke-RegistryChange $d $hw $cfg.backupDir $(if ($cfg.action -eq 'apply') { 'apply' } else { 'revert' }) }
        catch { $results += @{ id = $id; ok = $false; error = $_.Exception.Message } }
      }
    }
    Emit 'registry' (ConvertTo-Json -InputObject (Get-RegistryScan $hw $cfg.backupDir $results) -Depth 12 -Compress)
  } catch { Emit 'registry' (ConvertTo-Json -InputObject @{ ok = $false; error = $_.Exception.Message; items = @(); results = @() } -Compress) }
}
