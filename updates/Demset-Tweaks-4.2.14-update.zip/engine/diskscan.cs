using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

public class DNode {
  public string N; public long S; public long F; public long T; public bool D;
  public List<DNode> C; public long O; public int OC;
}

public static class DiskScan {
  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
  struct WFD {
    public uint attr; public uint ct1, ct2, at1, at2; public uint wtLow; public uint wtHigh;
    public uint sizeHigh; public uint sizeLow; public uint r0; public uint r1;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)] public string name;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 14)] public string alt;
  }
  [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
  static extern IntPtr FindFirstFileExW(string name, int level, out WFD data, int op, IntPtr filter, int flags);
  [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
  static extern bool FindNextFileW(IntPtr h, out WFD data);
  [DllImport("kernel32.dll")] static extern bool FindClose(IntPtr h);

  public static long Files, Bytes, Dirs, Denied;
  public static volatile bool Done;
  public static DNode Root;
  public static string Error;
  static readonly object bigLock = new object();
  static List<KeyValuePair<long, string>> big = new List<KeyValuePair<long, string>>();
  public static long MinKeep = 1048576;      // أصغر عنصر نحتفظ فيه بالشجرة (1 ميجا)
  public static int MaxKids = 80;            // أكثر عدد أبناء لكل مجلد
  public static long BigMin = 104857600;     // الملفات الكبيرة: 100 ميجا وفوق
  static bool win = Environment.OSVersion.Platform == PlatformID.Win32NT;

  public static void Start(string root) {
    Files = 0; Bytes = 0; Dirs = 0; Denied = 0; Done = false; Root = null; Error = null;
    lock (bigLock) big.Clear();
    var t = new Thread(() => {
      try { Root = ScanTop(root); } catch (Exception e) { Error = e.Message; }
      Done = true;
    });
    t.IsBackground = true; t.Start();
  }

  static long UnixMs(long ft) { if (ft <= 0) return 0; try { return (DateTime.FromFileTimeUtc(ft) - new DateTime(1970, 1, 1)).Ticks / 10000; } catch { return 0; } }

  static void AddBig(long size, string path) {
    if (size < BigMin) return;
    lock (bigLock) {
      big.Add(new KeyValuePair<long, string>(size, path));
      if (big.Count > 400) { big.Sort((a, b) => b.Key.CompareTo(a.Key)); big.RemoveRange(200, big.Count - 200); }
    }
  }

  // يرجّع (ملفات، مجلدات) مباشرة داخل المسار
  static void List(string dir, List<DNode> files, List<string> dirs, List<string> dirNames, List<long> dirTimes) {
    if (win) {
      string p = dir.StartsWith(@"\\?\") ? dir : @"\\?\" + dir;
      WFD d; IntPtr h = FindFirstFileExW(Path.Combine(p, "*"), 1, out d, 0, IntPtr.Zero, 2);
      if (h == new IntPtr(-1)) { Interlocked.Increment(ref Denied); return; }
      try {
        do {
          if (d.name == "." || d.name == "..") continue;
          long t = UnixMs(((long)d.wtHigh << 32) | d.wtLow);
          if ((d.attr & 0x10) != 0) {
            if ((d.attr & 0x400) != 0) continue; // junction / symlink: نتخطاه عشان ما نحسب مرتين
            dirs.Add(Path.Combine(dir, d.name)); dirNames.Add(d.name); dirTimes.Add(t);
          } else {
            long s = ((long)d.sizeHigh << 32) | d.sizeLow;
            if ((d.attr & (0x400000 | 0x40000 | 0x1000)) != 0) s = 0; // ملفات سحابية مو محمّلة
            files.Add(new DNode { N = d.name, S = s, F = 1, T = t });
          }
        } while (FindNextFileW(h, out d));
      } finally { FindClose(h); }
    } else {
      try {
        foreach (var fi in new DirectoryInfo(dir).EnumerateFileSystemInfos()) {
          long t = (long)(fi.LastWriteTimeUtc - new DateTime(1970, 1, 1)).TotalMilliseconds;
          if ((fi.Attributes & FileAttributes.Directory) != 0) {
            if ((fi.Attributes & FileAttributes.ReparsePoint) != 0) continue;
            dirs.Add(fi.FullName); dirNames.Add(fi.Name); dirTimes.Add(t);
          } else {
            long s = 0; try { if ((fi.Attributes & FileAttributes.ReparsePoint) == 0) s = ((FileInfo)fi).Length; } catch { }
            files.Add(new DNode { N = fi.Name, S = s, F = 1, T = t });
          }
        }
      } catch { Interlocked.Increment(ref Denied); }
    }
  }

  static DNode ScanDir(string path, string name, long time, bool parallel) {
    var node = new DNode { N = name, D = true, T = time, C = new List<DNode>() };
    var files = new List<DNode>(); var dirs = new List<string>(); var names = new List<string>(); var times = new List<long>();
    List(path, files, dirs, names, times);
    Interlocked.Increment(ref Dirs);
    long fs = 0;
    foreach (var f in files) { fs += f.S; if (f.S >= BigMin) AddBig(f.S, Path.Combine(path, f.N)); }
    Interlocked.Add(ref Files, files.Count); Interlocked.Add(ref Bytes, fs);
    var kids = new DNode[dirs.Count];
    if (parallel && dirs.Count > 1) {
      Parallel.For(0, dirs.Count, new ParallelOptions { MaxDegreeOfParallelism = Math.Max(2, Environment.ProcessorCount) }, i => { kids[i] = ScanDir(dirs[i], names[i], times[i], false); });
    } else {
      for (int i = 0; i < dirs.Count; i++) kids[i] = ScanDir(dirs[i], names[i], times[i], false);
    }
    node.S = fs; node.F = files.Count;
    var all = new List<DNode>(files.Count + kids.Length);
    foreach (var k in kids) { node.S += k.S; node.F += k.F; all.Add(k); }
    all.AddRange(files);
    all.Sort((a, b) => b.S.CompareTo(a.S));
    for (int i = 0; i < all.Count; i++) {
      var c = all[i];
      if (i < MaxKids && c.S >= MinKeep) node.C.Add(c);
      else { node.O += c.S; node.OC += 1; }
    }
    return node;
  }

  static DNode ScanTop(string root) {
    // المستوى الأول بالتوازي، وكل الملفات بالجذر تنحفظ (مثل pagefile.sys)
    var n = ScanDir(root, root, 0, true);
    return n;
  }

  public static string[] BigFiles(int n) {
    lock (bigLock) {
      big.Sort((a, b) => b.Key.CompareTo(a.Key));
      var o = new List<string>();
      for (int i = 0; i < big.Count && i < n; i++) o.Add(big[i].Key + "|" + big[i].Value);
      return o.ToArray();
    }
  }
  public static long SizeOf(string name) {
    if (Root == null) return 0;
    foreach (var c in Root.C) if (string.Equals(c.N, name, StringComparison.OrdinalIgnoreCase)) return c.S;
    return 0;
  }

  static void Esc(StringBuilder sb, string s) {
    sb.Append('"');
    foreach (char ch in s) {
      if (ch == '"' || ch == '\\') { sb.Append('\\').Append(ch); }
      else if (ch < 32) sb.Append("\\u").Append(((int)ch).ToString("x4"));
      else sb.Append(ch);
    }
    sb.Append('"');
  }
  static void Write(StringBuilder sb, DNode n) {
    sb.Append("{\"n\":"); Esc(sb, n.N);
    sb.Append(",\"s\":").Append(n.S).Append(",\"f\":").Append(n.F).Append(",\"t\":").Append(n.T);
    if (n.D) {
      sb.Append(",\"d\":1");
      if (n.O > 0) sb.Append(",\"o\":").Append(n.O).Append(",\"oc\":").Append(n.OC);
      if (n.C != null && n.C.Count > 0) {
        sb.Append(",\"c\":[");
        for (int i = 0; i < n.C.Count; i++) { if (i > 0) sb.Append(','); Write(sb, n.C[i]); }
        sb.Append(']');
      }
    }
    sb.Append('}');
  }
  public static void Save(string file) {
    var sb = new StringBuilder(1 << 20);
    if (Root != null) Write(sb, Root);
    File.WriteAllText(file, sb.ToString(), new UTF8Encoding(false));
  }
}
