﻿# =============================================================
#  Demset Tweaks — طبيب الجهاز ووضع اللعب
#  طبيب الجهاز: يفحص إعدادات الهاردوير اللي تاكل الأداء (سرعة الرام، تردد الشاشة،
#  قنوات الرام، سرعة PCIe، الألعاب على HDD...) — كله قراءات حقيقية من الجهاز.
#  وضع اللعب: يجهز الجهاز لما تبدأ لعبة ويرجّع كل شي لما تقفلها.
# =============================================================

if (-not ('DemsetDisplay' -as [type])) {
  Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public static class DemsetDisplay {
  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
  public struct DEVMODE {
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmDeviceName;
    public short dmSpecVersion, dmDriverVersion, dmSize, dmDriverExtra;
    public int dmFields, dmPositionX, dmPositionY, dmDisplayOrientation, dmDisplayFixedOutput;
    public short dmColor, dmDuplex, dmYResolution, dmTTOption, dmCollate;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmFormName;
    public short dmLogPixels;
    public int dmBitsPerPel, dmPelsWidth, dmPelsHeight, dmDisplayFlags, dmDisplayFrequency;
    public int dmICMMethod, dmICMIntent, dmMediaType, dmDitherType, dmReserved1, dmReserved2, dmPanningWidth, dmPanningHeight;
  }
  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
  public struct DISPLAY_DEVICE {
    public int cb;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string DeviceName;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceString;
    public int StateFlags;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceID;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceKey;
  }
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern bool EnumDisplayDevices(string dev, uint i, ref DISPLAY_DEVICE dd, uint flags);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern bool EnumDisplaySettings(string dev, int mode, ref DEVMODE dm);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int ChangeDisplaySettingsEx(string dev, ref DEVMODE dm, IntPtr hwnd, uint flags, IntPtr lParam);

  // كل شاشة شغّالة: الاسم، الدقة الحالية، التردد الحالي، وأعلى تردد متاح بنفس الدقة
  public static List<object[]> List() {
    var res = new List<object[]>();
    for (uint i = 0; i < 16; i++) {
      var dd = new DISPLAY_DEVICE(); dd.cb = Marshal.SizeOf(dd);
      if (!EnumDisplayDevices(null, i, ref dd, 0)) break;
      if ((dd.StateFlags & 1) == 0) continue; // مو متصلة بسطح المكتب
      var cur = new DEVMODE(); cur.dmSize = (short)Marshal.SizeOf(cur);
      if (!EnumDisplaySettings(dd.DeviceName, -1, ref cur)) continue;
      int max = cur.dmDisplayFrequency;
      var all = new SortedSet<int>();
      var m = new DEVMODE(); m.dmSize = (short)Marshal.SizeOf(m);
      for (int k = 0; EnumDisplaySettings(dd.DeviceName, k, ref m); k++) {
        if (m.dmPelsWidth == cur.dmPelsWidth && m.dmPelsHeight == cur.dmPelsHeight && (m.dmDisplayFlags & 2) == 0 && m.dmBitsPerPel == cur.dmBitsPerPel) {
          all.Add(m.dmDisplayFrequency);
          if (m.dmDisplayFrequency > max) max = m.dmDisplayFrequency;
        }
      }
      var mon = new DISPLAY_DEVICE(); mon.cb = Marshal.SizeOf(mon);
      string monName = EnumDisplayDevices(dd.DeviceName, 0, ref mon, 0) ? mon.DeviceString : "";
      res.Add(new object[] { dd.DeviceName, monName, cur.dmPelsWidth, cur.dmPelsHeight, cur.dmDisplayFrequency, max, string.Join(",", all), (dd.StateFlags & 4) != 0 });
    }
    return res;
  }
  // يغيّر التردد بس (نفس الدقة)، ويحفظه بالريجستري. 0 = نجح
  public static int SetFreq(string dev, int hz) {
    var dm = new DEVMODE(); dm.dmSize = (short)Marshal.SizeOf(dm);
    if (!EnumDisplaySettings(dev, -1, ref dm)) return -100;
    dm.dmDisplayFrequency = hz; dm.dmFields = 0x400000;
    return ChangeDisplaySettingsEx(dev, ref dm, IntPtr.Zero, 1, IntPtr.Zero);
  }
  // نوع البايوس من الويندوز نفسه: 1 = Legacy BIOS، 2 = UEFI (نفس اللي يعرضه msinfo32)
  [DllImport("kernel32.dll")] static extern bool GetFirmwareType(ref uint t);
  public static uint FirmwareType() { uint t = 0; try { if (GetFirmwareType(ref t)) return t; } catch { } return 0; }
  public static int GetFreq(string dev) { var dm = new DEVMODE(); dm.dmSize = (short)Marshal.SizeOf(dm); return EnumDisplaySettings(dev, -1, ref dm) ? dm.dmDisplayFrequency : 0; }
}
'@
}

# سرعة الرام المكتوبة في رقم القطعة (Part Number) — أغلب رامات الألعاب تكتب سرعة XMP فيه
function Get-RamRatedFromPart([string]$pn) {
  $p = "$pn".Trim().ToUpper()
  if (-not $p) { return 0 }
  $pats = @(
    '(?<!\d)(\d{4})C\d{2}',       # G.Skill F4-3600C16 / Corsair ...B3200C16 / CMK32GX5M2B5600C36
    '^(?:KF|HX)[3-5](\d{2})C',     # Kingston Fury KF432C16 → 3200 / KF560C36 → 6000 / HyperX HX436C17 → 3600
    '(?<!\d)(\d{4})HC\d{2}',       # TeamGroup TF13D416G3200HC16F → 3200
    '^BL\d+G(\d{2})C',            # Crucial Ballistix BL8G32C16 → 3200
    '^(?:PVS|PV|PSD)\d+G(\d{3})C', # Patriot PVS416G320C6 → 3200
    'DDR[45]-(\d{4})',
    '-(\d{4})-'
  )
  foreach ($re in $pats) {
    $m = [regex]::Match($p, $re)
    if (-not $m.Success) { continue }
    if ($re -like '^(?:KF*') { $v = [int]$m.Groups[1].Value * 100 }
    elseif ($re -like '^BL*') { $v = [int]$m.Groups[1].Value * 100 }
    elseif ($re -like '^(?:PVS*') { $v = [int]$m.Groups[1].Value * 10 }
    else { $v = [int]$m.Groups[1].Value }
    if ($v -ge 1600 -and $v -le 10000) { return $v }
  }
  return 0
}
function Get-RamChannel([string]$loc, [string]$bank) {
  foreach ($s in @($loc, $bank)) {
    $m = [regex]::Match("$s", '(?i)channel\s*([A-H])'); if ($m.Success) { return $m.Groups[1].Value.ToUpper() }
    $m = [regex]::Match("$s", '(?i)(?:DIMM|CH)[\s_-]*([A-H])\d'); if ($m.Success) { return $m.Groups[1].Value.ToUpper() }
    $m = [regex]::Match("$s", '^\s*([A-H])[0-9]\s*$'); if ($m.Success) { return $m.Groups[1].Value.ToUpper() }
    # أسماء مثل "DDR5-A1" أو "Controller0-ChannelA-DIMM1" أو "P0_A1"
    $m = [regex]::Match("$s", '(?i)(?:^|[\s_-])([A-H])[0-9]\b'); if ($m.Success) { return $m.Groups[1].Value.ToUpper() }
  }
  return ''
}
function Get-DriveMedia([string]$letter) {
  try {
    $part = Get-Partition -DriveLetter $letter -ErrorAction Stop
    $pd = Get-PhysicalDisk -ErrorAction Stop | Where-Object { "$($_.DeviceId)" -eq "$($part.DiskNumber)" } | Select-Object -First 1
    if ($pd) { return @{ media = "$($pd.MediaType)"; bus = "$($pd.BusType)"; name = "$($pd.FriendlyName)" } }
  } catch {}
  return $null
}
function Get-GameLibraries {
  $libs = @()
  # Steam
  try {
    $sp = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction Stop).SteamPath
    if ($sp) {
      $sp = $sp -replace '/', '\'
      $vdf = Join-Path $sp 'steamapps\libraryfolders.vdf'
      $paths = @($sp)
      if (Test-Path -LiteralPath $vdf) { foreach ($m in [regex]::Matches((Get-Content -LiteralPath $vdf -Raw -Encoding UTF8), '"path"\s+"([^"]+)"')) { $paths += ($m.Groups[1].Value -replace '\\\\', '\') } }
      foreach ($p in ($paths | Select-Object -Unique)) {
        $sa = Join-Path $p 'steamapps'
        if (-not (Test-Path -LiteralPath $sa)) { continue }
        $names = @(Get-ChildItem -LiteralPath $sa -Filter 'appmanifest_*.acf' -ErrorAction SilentlyContinue | ForEach-Object { $m = [regex]::Match((Get-Content -LiteralPath $_.FullName -Raw -Encoding UTF8), '"name"\s+"([^"]+)"'); if ($m.Success) { $m.Groups[1].Value } } | Where-Object { $_ -notmatch 'Steamworks|Redistributable|Proton|Steam Linux' })
        if ($names.Count) { $libs += @{ store = 'Steam'; path = $p; games = $names } }
      }
    }
  } catch {}
  # Epic
  $man = Join-Path $env:ProgramData 'Epic\EpicGamesLauncher\Data\Manifests'
  if (Test-Path -LiteralPath $man) {
    $by = @{}
    foreach ($f in Get-ChildItem -LiteralPath $man -Filter *.item -ErrorAction SilentlyContinue) {
      try { $j = Get-Content -LiteralPath $f.FullName -Raw -Encoding UTF8 | ConvertFrom-Json; if ($j.InstallLocation) { $root = $j.InstallLocation.Substring(0, 3); if (-not $by[$root]) { $by[$root] = @() }; $by[$root] += $j.DisplayName } } catch {}
    }
    foreach ($k in $by.Keys) { $libs += @{ store = 'Epic'; path = $k; games = $by[$k] } }
  }
  # مجلدات ألعاب معروفة
  foreach ($d in [IO.DriveInfo]::GetDrives()) {
    if ($d.DriveType -ne 'Fixed' -or -not $d.IsReady) { continue }
    foreach ($sub in @('Riot Games', 'XboxGames', 'Program Files\EA Games', 'Program Files (x86)\Ubisoft\Ubisoft Game Launcher\games', 'Program Files (x86)\Battle.net', 'Program Files (x86)\Overwatch', 'Program Files (x86)\Call of Duty')) {
      $p = Join-Path $d.RootDirectory.FullName $sub
      if (Test-Path -LiteralPath $p) { $g = @(Get-ChildItem -LiteralPath $p -Directory -ErrorAction SilentlyContinue | ForEach-Object { $_.Name }); if ($sub -like '*Battle.net' -or $sub -like '*Overwatch' -or $sub -like '*Call of Duty') { $g = @(Split-Path $sub -Leaf) }; if ($g.Count) { $libs += @{ store = (Split-Path $sub -Leaf); path = $p; games = $g } } }
    }
  }
  return $libs
}

function Invoke-Doctor {
  $script:dChecks = @()
  $isLaptop = $false
  try { $isLaptop = [bool](Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue) } catch {}
  $board = Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue | Select-Object -First 1
  $bios = Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue | Select-Object -First 1
  # UEFI أو Legacy: من GetFirmwareType (المصدر الرسمي)، وإذا ما رد نجرب الريجستري و Secure Boot
  $fw = [int][DemsetDisplay]::FirmwareType()
  if ($fw -eq 2) { $uefi = $true } elseif ($fw -eq 1) { $uefi = $false } else {
    $uefi = $null
    try { $pe = (Get-ItemProperty 'HKLM:\System\CurrentControlSet\Control' -ErrorAction Stop).PEFirmwareType; if ($pe -eq 2) { $uefi = $true } elseif ($pe -eq 1) { $uefi = $false } } catch {}
    if ($null -eq $uefi) { try { [void](Confirm-SecureBootUEFI -ErrorAction Stop); $uefi = $true } catch { if ("$($_.Exception.Message)" -match 'not supported') { $uefi = $false } } }
  }
  $boardInfo = @{ maker = "$($board.Manufacturer)".Trim(); model = "$($board.Product)".Trim(); bios = "$($bios.SMBIOSBIOSVersion)"; uefi = $uefi; laptop = $isLaptop }

  # ---- 1) سرعة الرام (XMP / EXPO) ----
  Log '▶ الرام: السرعة والقنوات'
  $mods = @(Get-CimInstance Win32_PhysicalMemory -ErrorAction SilentlyContinue)
  if ($mods.Count) {
    $cfg = [int](($mods | Measure-Object ConfiguredClockSpeed -Minimum).Minimum)
    $typeCode = [int]$mods[0].SMBIOSMemoryType
    $type = switch ($typeCode) { 26 { 'DDR4' } 34 { 'DDR5' } 24 { 'DDR3' } default { '' } }
    $rated = 0; $ratedSrc = ''
    # الرام تمشي على سرعة أبطأ قطعة — فناخذ الأقل، مو الأعلى
    $parts = @($mods | ForEach-Object { Get-RamRatedFromPart $_.PartNumber })
    $known = @($parts | Where-Object { $_ -gt 0 })
    $mixed = (@($known | Select-Object -Unique).Count -gt 1)
    if ($known.Count -eq $mods.Count) { $rated = [int](($known | Measure-Object -Minimum).Minimum); $ratedSrc = 'part' }
    else {
      $spdMin = [int](($mods | Where-Object { $_.Speed -gt 0 } | Measure-Object Speed -Minimum).Minimum)
      $rated = [int](@(@($known) + @($spdMin) | Where-Object { $_ -gt 0 } | Measure-Object -Minimum).Minimum); $ratedSrc = 'spd'
    }
    $pn = (($mods | ForEach-Object { "$($_.PartNumber)".Trim() } | Select-Object -Unique) -join ', ')
    $val = "$cfg MT/s" + $(if ($rated -gt 0) { " من $rated" } else { '' })
    $jedecBase = @{ 'DDR4' = @(2133, 2400, 2666); 'DDR5' = @(4800) }
    if ($rated -gt 0 -and $cfg -gt 0 -and $rated - $cfg -ge 200) {
      $pct = [math]::Round(100 * ($rated - $cfg) / $rated)
      $script:dChecks += @{ id = 'ram_speed'; title = 'سرعة الرام'; status = 'problem'; impact = 'high'; value = $val
        detail = "رامك مصنوعة على $rated بس شغّالة على $cfg (أبطأ بـ $pct٪). السبب غالبًا إن XMP أو EXPO طافي في البايوس. تفعيله ياخذ دقيقة ويعطي فريمات أكثر بشكل واضح في الألعاب اللي تعتمد على المعالج."
        fix = @{ kind = 'bios'; what = 'xmp' }; extra = @{ part = $pn; type = $type; rated = $rated; cfg = $cfg } }
    } elseif ($rated -eq 0 -and $jedecBase[$type] -and ($jedecBase[$type] -contains $cfg) -and -not $isLaptop) {
      $script:dChecks += @{ id = 'ram_speed'; title = 'سرعة الرام'; status = 'warn'; impact = 'high'; value = "$cfg MT/s"
        detail = "رامك شغّالة على السرعة الأساسية ($cfg). ما قدرت أعرف السرعة اللي مصنوعة عليها من رقم القطعة ($pn). إذا رامك للألعاب (مكتوب عليها 3200 أو 3600 أو 6000 مثلًا) فالـ XMP/EXPO غالبًا طافي."
        fix = @{ kind = 'bios'; what = 'xmp' }; extra = @{ part = $pn; type = $type; cfg = $cfg } }
    } else {
      $mx = $(if ($mixed) { " عندك قطع بسرعات مختلفة ($(@($known | Select-Object -Unique | Sort-Object) -join ' و ')) — الرام كلها تمشي على سرعة أبطأ قطعة، وهذا أقصى شي توصله بهالتركيبة. لو تبي أسرع، لازم قطع متطابقة." } else { '' })
      $script:dChecks += @{ id = 'ram_speed'; title = 'سرعة الرام'; status = $(if ($mixed) { 'warn' } else { 'ok' }); impact = 'high'; value = $val; detail = "الرام شغّالة على أقصى سرعة ممكنة ($cfg MT/s, $type).$mx"; extra = @{ part = $pn; mixed = $mixed } }
    }
    # ---- 2) قنوات الرام (Dual Channel) ----
    $chs = @($mods | ForEach-Object { Get-RamChannel $_.DeviceLocator $_.BankLabel } | Where-Object { $_ } | Select-Object -Unique)
    $gb = [math]::Round((($mods | Measure-Object Capacity -Sum).Sum) / 1GB)
    $locs = ($mods | ForEach-Object { "$($_.DeviceLocator)" }) -join ', '
    if ($mods.Count -eq 1) {
      $script:dChecks += @{ id = 'ram_channel'; title = 'قنوات الرام (Dual Channel)'; status = 'problem'; impact = 'high'; value = "قطعة وحدة ($gb GB)"
        detail = "عندك قطعة رام وحدة، يعني الرام شغّالة Single Channel ونص سرعة النقل بس. قطعتين بنفس الحجم (مثلًا 2×8 بدل 1×16) تعطي فريمات أكثر بشكل واضح خصوصًا مع الكرت المدمج والألعاب التنافسية." + $(if ($isLaptop) { ' (بعض اللابتوبات فيها رام ملحومة بالبوردة، شيك قبل لا تشتري.)' } else { '' })
        fix = @{ kind = 'info' } }
    } elseif ($chs.Count -eq 1 -and $mods.Count -ge 2) {
      $script:dChecks += @{ id = 'ram_channel'; title = 'قنوات الرام (Dual Channel)'; status = 'problem'; impact = 'high'; value = "$($mods.Count) قطع بنفس القناة"
        detail = "قطع الرام مركّبة كلها في القناة $($chs[0]) ($locs)، فشغّالة Single Channel. انقلها للمنافذ الصح: غالبًا المنفذ الثاني والرابع من جهة المعالج (A2 و B2) — شوف كتيّب المذربورد."
        fix = @{ kind = 'info' } }
    } elseif (($mods.Count % 2) -eq 1 -or @($mods | Select-Object -ExpandProperty Capacity -Unique).Count -gt 1) {
      # عدد فردي أو أحجام مختلفة: قناة فيها أكثر من الثانية — جزء من الرام Single Channel، ومع DDR5 غالبًا السرعة تنزل
      $sizes = ($mods | ForEach-Object { "$([math]::Round($_.Capacity / 1GB))GB" }) -join ' + '
      $ddr5 = @($mods | Where-Object { $_.SMBIOSMemoryType -eq 34 }).Count -gt 0
      $script:dChecks += @{ id = 'ram_channel'; title = 'قنوات الرام (Dual Channel)'; status = 'warn'; impact = 'high'; value = "$($mods.Count) قطع غير متوازنة ($sizes)"
        detail = "عندك $($mods.Count) قطع رام ($locs · $sizes). لما القنوات مو متساوية، الجزء الزايد من الرام يشتغل Single Channel (Flex Mode) وأبطأ من الباقي." + $(if ($ddr5) { " ومع DDR5 تركيب قطعتين بنفس القناة يخلي البوردة تنزّل السرعة عشان الثبات — هذا غالبًا سبب إن الرام ما توصل سرعتها المكتوبة. الأفضل قطعتين متطابقتين (أو أربع) بدل ثلاث." } else { " الأفضل عدد زوجي من قطع بنفس الحجم والسرعة." })
        fix = @{ kind = 'info' } }
    } else {
      $script:dChecks += @{ id = 'ram_channel'; title = 'قنوات الرام (Dual Channel)'; status = $(if ($chs.Count -ge 2) { 'ok' } else { 'unknown' }); impact = 'high'; value = "$($mods.Count) قطع · $gb GB"
        detail = $(if ($chs.Count -ge 2) { "الرام شغّالة Dual Channel (القنوات: $($chs -join '، '))." } else { "عندك $($mods.Count) قطع ($locs). ما قدرت أتأكد من القنوات من أسماء المنافذ، بس غالبًا سليمة." }) }
    }
  }

  # ---- 3) تردد الشاشة ----
  Log '▶ الشاشات: التردد'
  try {
    foreach ($d in [DemsetDisplay]::List()) {
      $dev = "$($d[0])"; $mon = "$($d[1])"; $w = [int]$d[2]; $h = [int]$d[3]; $cur = [int]$d[4]; $max = [int]$d[5]; $modes = "$($d[6])"; $primary = [bool]$d[7]
      $name = "$(if ($primary) { 'الشاشة الأساسية' } else { 'شاشة ثانية' }) · ${w}×${h}"
      if ($max -gt $cur + 1) {
        $script:dChecks += @{ id = 'refresh_' + ($dev -replace '\W', ''); title = 'تردد الشاشة'; status = 'problem'; impact = 'high'; value = "$cur Hz من $max Hz"
          detail = "$name ($mon) شغّالة على $cur Hz وهي تدعم $max Hz. يعني تشوف فريمات أقل من اللي جهازك يطلعها، والحركة أقل نعومة. هذا ينصلح من هنا بضغطة."
          fix = @{ kind = 'refresh'; dev = $dev; hz = $max; prior = $cur }; extra = @{ modes = $modes; monitor = $mon } }
      } else {
        $script:dChecks += @{ id = 'refresh_' + ($dev -replace '\W', ''); title = 'تردد الشاشة'; status = 'ok'; impact = 'high'; value = "$cur Hz"; detail = "$name ($mon) شغّالة على أعلى تردد تدعمه ($cur Hz) بهالدقة." }
      }
    }
  } catch { Warn ('  الشاشات: ' + $_.Exception.Message) }

  # ---- 4) كرت الشاشة: PCIe و Resizable BAR ----
  Log '▶ كرت الشاشة: PCIe'
  foreach ($g in @(Get-PnpDevice -Class Display -PresentOnly -ErrorAction SilentlyContinue)) {
    try {
      $props = Get-PnpDeviceProperty -InstanceId $g.InstanceId -KeyName 'DEVPKEY_PciDevice_CurrentLinkWidth', 'DEVPKEY_PciDevice_MaxLinkWidth', 'DEVPKEY_PciDevice_CurrentLinkSpeed', 'DEVPKEY_PciDevice_MaxLinkSpeed' -ErrorAction Stop
      $pv = @{}; foreach ($p in $props) { $pv[$p.KeyName] = $p.Data }
      $cw = [int]$pv['DEVPKEY_PciDevice_CurrentLinkWidth']; $mw = [int]$pv['DEVPKEY_PciDevice_MaxLinkWidth']
      $cs = [int]$pv['DEVPKEY_PciDevice_CurrentLinkSpeed']; $ms = [int]$pv['DEVPKEY_PciDevice_MaxLinkSpeed']
      if (-not $mw) { continue }  # الكرت المدمج ما له PCIe
      $gen = { param($x) if ($x -ge 1 -and $x -le 6) { "Gen$x" } else { '?' } }
      $val = "x$cw Gen$cs (يدعم x$mw Gen$ms)"
      if ($cw -lt $mw) {
        $script:dChecks += @{ id = 'pcie'; title = 'منفذ كرت الشاشة (PCIe)'; status = 'problem'; impact = 'mid'; value = "x$cw من x$mw"
          detail = "$($g.FriendlyName) شغّال على x$cw بدل x$mw. الأسباب: الكرت في المنفذ الثاني بدل الأول (الأقرب للمعالج)، أو هارديسك M.2 يشارك نفس الخطوط، أو غبار في المنفذ. انقل الكرت للمنفذ الأول." ; fix = @{ kind = 'info' }; extra = @{ raw = $val } }
      } else {
        $note = if ($cs -lt $ms) { " السرعة الحين Gen$cs لأن الكرت مرتاح وهذا طبيعي (توفير طاقة) — ترتفع لحالها وقت اللعب." } else { '' }
        $script:dChecks += @{ id = 'pcie'; title = 'منفذ كرت الشاشة (PCIe)'; status = 'ok'; impact = 'mid'; value = "x$cw"; detail = "$($g.FriendlyName) على كامل الخطوط (x$cw).$note" }
      }
    } catch {}
  }
  $smi = Join-Path $env:windir 'System32\nvidia-smi.exe'
  if (Test-Path $smi) {
    try {
      $q = (& $smi -q -d MEMORY) 2>$null | Out-String
      $fb = [regex]::Match($q, 'FB Memory Usage\s+Total\s*:\s*(\d+)\s*MiB'); $b1 = [regex]::Match($q, 'BAR1 Memory Usage\s+Total\s*:\s*(\d+)\s*MiB')
      if ($b1.Success) {
        $bar = [int]$b1.Groups[1].Value
        # Resizable BAR شغّال = الجهاز أكيد مقلع UEFI (ReBAR ما يشتغل على Legacy/CSM)
        if ($bar -ge 1024 -and $uefi -ne $true) { $uefi = $true; $boardInfo.uefi = $true }
        if ($bar -ge 1024) { $script:dChecks += @{ id = 'rebar'; title = 'Resizable BAR'; status = 'ok'; impact = 'mid'; value = 'شغّال'; detail = "المعالج يقدر يوصل لكل ذاكرة الكرت مرة وحدة (BAR1 = $bar MiB)." } }
        else { $script:dChecks += @{ id = 'rebar'; title = 'Resizable BAR'; status = 'warn'; impact = 'mid'; value = 'طافي'; detail = "Resizable BAR طافي (BAR1 = $bar MiB). تفعيله يعطي 0–10٪ في بعض الألعاب الحديثة. يتفعل من البايوس: شغّل 'Above 4G Decoding' و 'Re-Size BAR Support' (ويحتاج الويندوز يكون مثبّت بنظام UEFI)."; fix = @{ kind = 'bios'; what = 'rebar' } } }
      }
    } catch {}
  }

  # ---- 5) الألعاب على هارديسك عادي ----
  Log '▶ أماكن الألعاب'
  $libs = @(Get-GameLibraries)
  $slow = @(); $fast = 0
  foreach ($l in $libs) {
    $letter = "$($l.path)".Substring(0, 1)
    $md = Get-DriveMedia $letter
    if ($md -and $md.media -eq 'HDD') { $slow += @{ store = $l.store; path = $l.path; games = @($l.games | Select-Object -First 6); count = @($l.games).Count; disk = $md.name } } else { $fast += @($l.games).Count }
  }
  if ($slow.Count) {
    $n = ($slow | Measure-Object count -Sum).Sum
    $script:dChecks += @{ id = 'games_hdd'; title = 'مكان الألعاب'; status = 'problem'; impact = 'mid'; value = "$n لعبة على HDD"
      detail = ("عندك $n لعبة على هارديسك عادي (HDD): " + (($slow | ForEach-Object { ($_.games -join '، ') }) -join '، ') + ". الـ HDD يسبب تحميل بطيء وتقطيع لما اللعبة تحمّل مناطق جديدة. انقلها لـ SSD (Steam: كلك يمين على اللعبة ← Properties ← Installed Files ← Move).")
      fix = @{ kind = 'info' }; extra = @{ libs = $slow } }
  } elseif ($libs.Count) {
    $script:dChecks += @{ id = 'games_hdd'; title = 'مكان الألعاب'; status = 'ok'; impact = 'mid'; value = "$fast لعبة على SSD"; detail = 'كل الألعاب اللي لقيتها (Steam و Epic وغيرها) على SSD.' }
  }

  # ---- 6) خطة الطاقة ----
  $sch = (& powercfg /getactivescheme) 2>$null | Out-String
  $schName = ([regex]::Match($sch, '\((.+)\)')).Groups[1].Value
  if ($sch -match 'a1841308-3541-4fab-bc81-f71556f20b4a') {
    $script:dChecks += @{ id = 'power'; title = 'خطة الطاقة'; status = 'problem'; impact = 'mid'; value = $schName; detail = 'خطة "توفير الطاقة" شغّالة، وهذي تحد سرعة المعالج. غيّرها لخطة الأداء.'; fix = @{ kind = 'tweak'; id = 'power_plan' } }
  } elseif ($sch -match '381b4222-f694-41f0-9685-ff5bb260df2e' -and -not $isLaptop) {
    $script:dChecks += @{ id = 'power'; title = 'خطة الطاقة'; status = 'warn'; impact = 'low'; value = $schName; detail = 'خطة "متوازن" شغّالة. على جهاز مكتبي خطة Ultimate Performance تقلل التأخير لما المعالج يصحى من الخمول.'; fix = @{ kind = 'tweak'; id = 'power_plan' } }
  } else {
    $script:dChecks += @{ id = 'power'; title = 'خطة الطاقة'; status = 'ok'; impact = 'low'; value = $schName; detail = "الخطة الحالية: $schName." }
  }

  # ---- 7) Memory Integrity (VBS / HVCI) ----
  try {
    $dg = Get-CimInstance -Namespace root\Microsoft\Windows\DeviceGuard -ClassName Win32_DeviceGuard -ErrorAction Stop
    $hvci = @($dg.SecurityServicesRunning) -contains 2
    if ($hvci) {
      $script:dChecks += @{ id = 'hvci'; title = 'Memory Integrity (حماية الذاكرة)'; status = 'info'; impact = 'mid'; value = 'شغّالة'
        detail = 'هذي حماية أمان من الويندوز، بس تاخذ تقريبًا 5–10٪ من الفريمات في بعض الألعاب. القرار لك: إذا طفيتها جهازك يصير أسرع بس أقل حماية من نوع معيّن من الفايروسات. بعض الألعاب (مثل Valorant مع Vanguard) ما تحتاجها.'
        fix = @{ kind = 'link'; url = 'windowsdefender://coreisolation'; label = 'افتح إعداداتها' } }
    } else { $script:dChecks += @{ id = 'hvci'; title = 'Memory Integrity (حماية الذاكرة)'; status = 'ok'; impact = 'mid'; value = 'طافية'; detail = 'ما تاخذ من أداء الألعاب.' } }
  } catch {}

  # ---- 8) مساحة قرص النظام ----
  try {
    $c = [IO.DriveInfo]::new($env:SystemDrive)
    $freePct = [math]::Round(100 * $c.AvailableFreeSpace / $c.TotalSize)
    $freeGB = [math]::Round($c.AvailableFreeSpace / 1GB)
    if ($freePct -lt 10) { $script:dChecks += @{ id = 'cfree'; title = 'مساحة قرص النظام'; status = 'problem'; impact = 'mid'; value = "$freeGB GB فاضي ($freePct٪)"; detail = 'قرص النظام شبه ممتلي. لما يقل عن 10٪ الويندوز يبطّأ والتحديثات تفشل والـ SSD يقل أداه.'; fix = @{ kind = 'nav'; page = 'space'; label = 'شوف وش ماكل المساحة' } } }
    else { $script:dChecks += @{ id = 'cfree'; title = 'مساحة قرص النظام'; status = 'ok'; impact = 'low'; value = "$freeGB GB فاضي"; detail = "فيه مساحة كافية ($freePct٪)." } }
  } catch {}

  # ---- وضع الإقلاع (UEFI / Legacy) ----
  if ($uefi -eq $false) {
    $script:dChecks += @{ id = 'bootmode'; title = 'وضع الإقلاع'; status = 'warn'; impact = 'low'; value = 'Legacy (CSM)'
      detail = 'الويندوز مثبّت بوضع Legacy القديم مو UEFI. هذا يمنع Resizable BAR ودخول البايوس من الويندوز، ويخلي الإقلاع أبطأ شوي. التحويل ممكن بدون فرمتة بأداة MBR2GPT من مايكروسوفت، بس يحتاج حذر.'; fix = @{ kind = 'info' } }
  }
  # ---- 9) عمر تعريف كرت الشاشة ----
  foreach ($g in @(Get-GpuDriverInfo)) {
    if ($g.vendor -eq 'other') { continue }
    $st = if ($g.ageDays -gt 180) { 'warn' } else { 'ok' }
    $script:dChecks += @{ id = 'gpudrv'; title = 'تعريف كرت الشاشة'; status = $st; impact = 'mid'; value = "$($g.version) · $($g.date)"; detail = $(if ($st -eq 'warn') { "تعريف $($g.name) عمره أكثر من 6 شهور. التعريفات الجديدة فيها تحسينات للألعاب الجديدة وإصلاحات تقطيع." } else { "تعريف $($g.name) حديث." }); fix = $(if ($st -eq 'warn') { @{ kind = 'nav'; page = 'updates'; label = 'صفحة التحديثات' } } else { $null }) }
  }

  $res = @{ at = (Get-Date).ToString('s'); board = $boardInfo; checks = @($script:dChecks) }
  Emit 'doctor' (ConvertTo-Json -InputObject $res -Compress -Depth 6)
}

function Set-RefreshRate($cfg) {
  $before = [DemsetDisplay]::GetFreq($cfg.dev)
  $r = [DemsetDisplay]::SetFreq($cfg.dev, [int]$cfg.hz)
  Start-Sleep -Milliseconds 600
  $after = [DemsetDisplay]::GetFreq($cfg.dev)
  if ($r -eq 0 -and $after -eq [int]$cfg.hz) { Log ("  التردد: $before → $after Hz") } else { Warn ("  ما تغيّر التردد (كود $r، الحالي $after Hz)") }
  Emit 'refresh' (@{ ok = ($r -eq 0 -and $after -eq [int]$cfg.hz); code = $r; before = $before; after = $after } | ConvertTo-Json -Compress)
}

# ---------------- وضع اللعب ----------------
function Invoke-GameBoost($cfg) {
  if ($cfg.action -eq 'on') {
    $rec = @{ pid = [int]$cfg.pid; at = (Get-Date).ToString('s'); svcs = @(); plan = $null; onedrive = $null; prio = $null; standby = $false }
    if ($cfg.opts.priority) {
      try { $p = Get-Process -Id $cfg.pid -ErrorAction Stop; $rec.prio = "$($p.PriorityClass)"; if ($rec.prio -eq 'Normal') { $p.PriorityClass = 'High'; Log ("  أولوية " + $p.ProcessName + ": عالية") } } catch { Warn ('  الأولوية: ' + $_.Exception.Message) }
    }
    if ($cfg.opts.plan) {
      $prior = Get-ActiveScheme
      $target = $null
      foreach ($l in ((& powercfg /list) 2>$null)) { if ($l -match '(Demset|Polar) Ultimate Performance' -and $l -match '([0-9a-fA-F-]{36})') { $target = $Matches[1] } }
      if (-not $target) { foreach ($l in ((& powercfg /list) 2>$null)) { if ($l -match 'e9a42b02-d5df-448d-aa00-03f14749eb61|8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' -and $l -match '([0-9a-fA-F-]{36})') { $target = $Matches[1] } } }
      if (-not $target) { $target = '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' }
      if ($prior -and $prior -ne $target) { & powercfg /setactive $target 2>&1 | Out-Null; $rec.plan = $prior; Log '  خطة الطاقة: أداء عالي' }
    }
    # C-states: الأنوية ما تنام وقت اللعب (استجابة أسرع، حرارة أعلى) — على الخطة الشغّالة بعد أي تبديل
    if ($cfg.opts.cstates) {
      $i = Get-PowerIndex 'SUB_PROCESSOR' 'IDLEDISABLE'
      if ($i) { & powercfg /setacvalueindex scheme_current SUB_PROCESSOR IDLEDISABLE 1 2>&1 | Out-Null; & powercfg /setactive scheme_current 2>&1 | Out-Null; $rec.idle = @{ scheme = (Get-ActiveScheme); prior = $i.ac }; Log '  أوقفت سكون الأنوية (C-states) مؤقتًا' }
    }
    if ($cfg.opts.updates) {
      # ما نوقف شي لو الويندوز يثبّت تحديث الحين
      $installing = [bool](Get-Process TrustedInstaller, TiWorker -ErrorAction SilentlyContinue)
      if ($installing) { Log '  الويندوز يثبّت تحديث الحين — ما وقفت خدماته' }
      else { foreach ($s in 'wuauserv', 'BITS', 'DoSvc', 'UsoSvc') { $sv = Get-Service $s -ErrorAction SilentlyContinue; if ($sv -and $sv.Status -eq 'Running') { try { Stop-Service $s -Force -ErrorAction Stop; $rec.svcs += $s } catch {} } }; if ($rec.svcs.Count) { Log ('  وقفت مؤقتًا: ' + ($rec.svcs -join '، ')) } }
    }
    if ($cfg.opts.onedrive) {
      $od = Get-Process OneDrive -ErrorAction SilentlyContinue | Select-Object -First 1
      if ($od) { try { $path = $od.Path; Start-Process -FilePath $path -ArgumentList '/shutdown' -WindowStyle Hidden; $rec.onedrive = $path; Log '  OneDrive: وقف مؤقتًا' } catch {} }
    }
    if ($cfg.opts.standby) {
      if (-not ('PolarMem' -as [type])) {
        Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class PolarMem {
  [DllImport("ntdll.dll")] static extern uint NtSetSystemInformation(int infoClass, ref int info, int len);
  [DllImport("ntdll.dll")] static extern uint RtlAdjustPrivilege(int priv, bool enable, bool thread, out bool was);
  [StructLayout(LayoutKind.Sequential)] struct MS { public uint len; public uint load; public ulong total, avail, tpf, apf, tv, av, aev; }
  [DllImport("kernel32.dll")] static extern bool GlobalMemoryStatusEx(ref MS m);
  public static ulong[] Status() { var m = new MS(); m.len = (uint)Marshal.SizeOf(typeof(MS)); GlobalMemoryStatusEx(ref m); return new ulong[] { m.total, m.avail, m.load }; }
  public static uint Run(int cmd) { bool w; RtlAdjustPrivilege(13, true, false, out w); RtlAdjustPrivilege(5, true, false, out w); int c = cmd; return NtSetSystemInformation(80, ref c, 4); }
}
'@
      }
      $rec.standby = ([PolarMem]::Run(4) -eq 0); if ($rec.standby) { Log '  نظّفت الذاكرة الاحتياطية (Standby)' }
    }
    Emit 'boost' (ConvertTo-Json -InputObject $rec -Compress -Depth 4)
  } else {
    $r = $cfg.rec
    if ($r.idle) { & powercfg /setacvalueindex $r.idle.scheme SUB_PROCESSOR IDLEDISABLE ([uint32]$r.idle.prior) 2>&1 | Out-Null; & powercfg /setactive scheme_current 2>&1 | Out-Null; Log '  رجّعت سكون الأنوية' }
    if ($cfg.only -eq 'idle') { Emit 'boost' (@{ restored = $true; only = 'idle' } | ConvertTo-Json -Compress); return }
    if ($r.plan) { & powercfg /setactive $r.plan 2>&1 | Out-Null; Log '  رجّعت خطة الطاقة' }
    foreach ($s in @($r.svcs)) { if ($s) { try { Start-Service $s -ErrorAction Stop } catch {} } }
    if (@($r.svcs).Count) { Log ('  رجّعت تشغيل: ' + (@($r.svcs) -join '، ')) }
    if ($r.onedrive -and -not (Get-Process OneDrive -ErrorAction SilentlyContinue)) { try { Start-AsUser $r.onedrive '/background'; Log '  رجّعت OneDrive' } catch {} }
    Emit 'boost' (@{ restored = $true } | ConvertTo-Json -Compress)
  }
}
