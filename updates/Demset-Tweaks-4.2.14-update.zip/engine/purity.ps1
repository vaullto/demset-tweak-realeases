﻿# =============================================================
#  Demset Tweaks — "لعبة صافية": مين داخل لعبتك؟
#  يقرا الملفات المحقونة داخل عملية اللعبة (الأوفرلاي والتسجيل)، والبرامج اللي تسجّل بالخلفية.
#  قراءة بس — الإطفاء يصير من مكانه (تويك أو إعدادات البرنامج نفسه).
# =============================================================

# الملفات اللي تحقن نفسها في الألعاب: [نمط الاسم، المعرّف]
$script:HookDlls = @(
  @('^discordhook', 'discord'), @('^gameoverlayrenderer', 'steam'), @('^nvspcap|^nvcamera|^nvshare|^nvgsync', 'nvidia'),
  @('^rtsshooks|^rtsscore', 'rtss'), @('^graphics-hook', 'obs'), @('medal', 'medal'), @('^owclient|overwolf|^ow-graphics', 'overwolf'),
  @('^eosovh', 'epic'), @('^igo(32|64)', 'ea'), @('^uplay_overlay|^upc_overlay|^overlay64', 'ubisoft'), @('^bnetoverlay|battle\.net.*overlay', 'battlenet'),
  @('^gamecapture|^ss-capture|steelseries', 'steelseries'), @('^razer', 'razer'), @('^amdrelivehook|^amdow', 'amd')
)
# برامج تسجّل أو ترسم بالخلفية: [اسم العملية، المعرّف]
$script:HookProcs = @(
  @('Discord', 'discord'), @('NVIDIA Overlay', 'nvidia'), @('nvcontainer', 'nvidia'), @('Medal', 'medal'), @('MedalEncoder', 'medal'),
  @('obs64', 'obs'), @('RTSS', 'rtss'), @('Overwolf', 'overwolf'), @('SteelSeriesGG', 'steelseries'), @('steam', 'steam'), @('EpicGamesLauncher', 'epic'),
  @('EADesktop', 'ea'), @('upc', 'ubisoft'), @('Battle.net', 'battlenet'), @('GameBar', 'gamebar'), @('XboxPcApp', 'gamebar')
)

function Get-ModuleNames([int]$procId) {
  try { return @((Get-Process -Id $procId -ErrorAction Stop).Modules | ForEach-Object { $_.ModuleName.ToLower() }) } catch { return $null }
}

# نلقى اللعبة: عملية لها نافذة وفيها DirectX 11/12 أو Vulkan، ومو من البرامج العادية
function Find-GameProcess {
  $skip = 'explorer|chrome|msedge|firefox|brave|opera|discord|steam|steamwebhelper|epicgameslauncher|battle\.net|code|demset|electron|nvidia|medal|obs64|spotify|claude|textinputhost|searchhost|shellexperiencehost|applicationframehost|systemsettings|windowsterminal|powershell|taskmgr|eadesktop|upc|overwolf|lively|wallpaper|razer|steelseries'
  $best = $null
  foreach ($p in (Get-Process | Where-Object { $_.MainWindowHandle -ne 0 -and $_.ProcessName -notmatch "^($skip)" })) {
    $m = Get-ModuleNames $p.Id
    if (-not $m) { continue }
    if ($m -contains 'd3d12.dll' -or $m -contains 'd3d11.dll' -or $m -contains 'vulkan-1.dll') {
      if (-not $best -or $p.WorkingSet64 -gt $best.WorkingSet64) { $best = $p }
    }
  }
  return $best
}

function Invoke-HookScan($cfg) {
  $res = @{ game = $null; gameName = $null; protected = $false; injected = @(); running = @(); gamebar = $null; steamOverlay = $null; at = (Get-Date).ToString('s') }
  # 1) اللعبة نفسها
  $g = $null
  if ($cfg -and $cfg.pid) { $g = Get-Process -Id ([int]$cfg.pid) -ErrorAction SilentlyContinue }
  if (-not $g) { $g = Find-GameProcess }
  if ($g) {
    $res.game = $g.Id; $res.gameName = $(if ($g.MainWindowTitle) { $g.MainWindowTitle } else { $g.ProcessName })
    $mods = Get-ModuleNames $g.Id
    if ($null -eq $mods) { $res.protected = $true }
    else {
      $found = @{}
      foreach ($m in $mods) { foreach ($h in $script:HookDlls) { if ($m -match $h[0]) { if (-not $found[$h[1]]) { $found[$h[1]] = @() }; $found[$h[1]] += $m } } }
      $res.injected = @($found.Keys | ForEach-Object { @{ id = $_; dlls = @($found[$_] | Select-Object -Unique) } })
    }
  }
  # 2) البرامج اللي شغّالة
  $names = @(Get-Process -ErrorAction SilentlyContinue | ForEach-Object { $_.ProcessName })
  $run = @{}
  foreach ($h in $script:HookProcs) { if ($names -contains $h[0]) { $run[$h[1]] = $true } }
  $res.running = @($run.Keys)
  # 3) Xbox Game Bar والتسجيل حقه
  try {
    $dvr = (Get-ItemProperty 'HKCU:\System\GameConfigStore' -ErrorAction SilentlyContinue).GameDVR_Enabled
    $cap = (Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -ErrorAction SilentlyContinue).AppCaptureEnabled
    $res.gamebar = @{ dvr = $dvr; capture = $cap; on = (($dvr -ne 0) -or ($cap -ne 0)) }
  } catch {}
  # 4) أوفرلاي Steam من إعداداتك (localconfig.vdf)
  try {
    $sp = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction Stop).SteamPath
    if ($sp) {
      $vals = @()
      foreach ($f in (Get-ChildItem -LiteralPath (Join-Path $sp 'userdata') -Directory -ErrorAction SilentlyContinue)) {
        $lc = Join-Path $f.FullName 'config\localconfig.vdf'
        if (Test-Path -LiteralPath $lc) { $m = [regex]::Match((Get-Content -LiteralPath $lc -Raw -Encoding UTF8), '"EnableGameOverlay"\s+"(\d)"'); if ($m.Success) { $vals += [int]$m.Groups[1].Value } }
      }
      $res.steamOverlay = $(if ($vals.Count) { [bool]($vals | Measure-Object -Maximum).Maximum } else { $null })
    }
  } catch {}
  Emit 'hooks' (ConvertTo-Json -InputObject $res -Compress -Depth 5)
}

function Stop-Recorder($cfg) {
  $map = @{ medal = @('Medal', 'MedalEncoder'); overwolf = @('Overwolf', 'OverwolfBrowser', 'OverwolfHelper', 'OverwolfHelper64'); obs = @('obs64'); rtss = @('RTSS', 'RTSSHooksLoader64'); steelseries = @('SteelSeriesGG', 'SteelSeriesGGClient') }
  $n = 0
  foreach ($p in @($map[$cfg.id])) { Get-Process -Name $p -ErrorAction SilentlyContinue | ForEach-Object { try { $_.Kill(); $n++ } catch {} } }
  Log ("  سكّرت " + $n + " عملية (" + $cfg.id + ")")
  Emit 'hooks' (@{ stopped = $n } | ConvertTo-Json -Compress)
}
