# سكربت تركيب التحديث — ينشحن داخل ملف التحديث نفسه، فأي إصلاح له يوصل مع التحديث
param([string]$res, [string]$exe, [string]$tmp, [string]$log, [int]$mainPid)
$ErrorActionPreference = 'Stop'
function L($m) { "$(Get-Date -Format 'HH:mm:ss') $m" | Out-File $log -Append -Encoding utf8 }
$root = Split-Path -Parent $res
L "updater: root=$root"
# 1) نسكّر كل شي شغّال من مجلد البرنامج: البرنامج وعملياته، والمحرك (PowerShell)، و PresentMon
$deadline = (Get-Date).AddSeconds(20)
do {
  $procs = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessId -ne $PID -and (($_.ExecutablePath -and $_.ExecutablePath.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) -or ($_.CommandLine -and $_.CommandLine.IndexOf($res, [StringComparison]::OrdinalIgnoreCase) -ge 0)) })
  if (-not $procs.Count) { break }
  if ((Get-Date) -gt $deadline.AddSeconds(-14)) { foreach ($p in $procs) { try { Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop; L "killed $($p.Name) $($p.ProcessId)" } catch {} } }
  Start-Sleep -Milliseconds 500
} while ((Get-Date) -lt $deadline)
Start-Sleep -Milliseconds 800
function Retry([string]$what, [scriptblock]$b) { for ($i = 0; $i -lt 15; $i++) { try { & $b; return } catch { if ($i -eq 14) { L "FAILED $what : $($_.Exception.Message)"; throw }; Start-Sleep -Milliseconds 700 } } }
# 2) نسخة احتياطية (نسخ، مو نقل) ثم نكتب فوق الملفات
$bak = Join-Path $res '_update_backup'
try {
  if (Test-Path $bak) { Remove-Item $bak -Recurse -Force -ErrorAction SilentlyContinue }
  New-Item -ItemType Directory -Path $bak -Force | Out-Null
  if (Test-Path (Join-Path $res 'app.asar')) { Copy-Item (Join-Path $res 'app.asar') $bak -Force }
  if (Test-Path (Join-Path $res 'engine')) { Copy-Item (Join-Path $res 'engine') (Join-Path $bak 'engine') -Recurse -Force }
  L 'backup ok'
  Retry 'app.asar' { Copy-Item (Join-Path $tmp 'app.asar') (Join-Path $res 'app.asar') -Force }
  L 'app.asar ok'
  Get-ChildItem (Join-Path $tmp 'engine') -File | ForEach-Object { $f = $_; Retry "engine\$($f.Name)" { Copy-Item $f.FullName (Join-Path $res "engine\$($f.Name)") -Force } }
  L 'engine ok'
  # مجلد app القديم (من النسخ الأولى) يتجاهله Electron لما فيه app.asar — نشيله عشان ما يلخبط
  if (Test-Path (Join-Path $res 'app')) { Remove-Item (Join-Path $res 'app') -Recurse -Force -ErrorAction SilentlyContinue }
  Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
  L 'ok'
} catch {
  L "fail: $($_.Exception.Message) — restoring"
  try { if (Test-Path (Join-Path $bak 'app.asar')) { Copy-Item (Join-Path $bak 'app.asar') (Join-Path $res 'app.asar') -Force } } catch {}
  try { if (Test-Path (Join-Path $bak 'engine')) { Copy-Item (Join-Path $bak 'engine\*') (Join-Path $res 'engine') -Force } } catch {}
}
Start-Process -FilePath $exe
L 'started app'
