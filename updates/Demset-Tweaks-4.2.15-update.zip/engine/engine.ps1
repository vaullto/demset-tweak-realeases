﻿# =============================================================
#  Demset Tweaks engine
#  - apply : يقرأ العمليات، يحفظ القيم القديمة، ويطبّق
#  - revert: يرجّع القيم المحفوظة بالضبط
#  - run   : أوامر تنفيذية (تنظيف، إصلاح...) بدون تراجع
#  - info  : معلومات الجهاز
# =============================================================
param(
  [Parameter(Mandatory = $true)][ValidateSet('hooks', 'hooks-stop', 'gpuoc', 'apply-many', 'bufferbloat', 'shadercache', 'doctor', 'refresh-set', 'boost', 'shortcut', 'updates-scan', 'updates-install', 'uninst-list', 'uninst-scan', 'uninst-clean', 'uninst-restore', 'vpn', 'taskbar', 'repair-check', 'repair-fix', 'procmon', 'pingtest', 'diskscan', 'drives', 'emptybin', 'installed', 'winget-user', 'selftest', 'procs', 'proc-kill', 'proc-restart', 'proc-priority', 'pawnio', 'memclean', 'apply', 'revert', 'run', 'info', 'restorepoint', 'isadmin', 'verify', 'monitor', 'bench', 'disks', 'startup-list', 'startup-set', 'apps-list', 'apps-remove', 'dnsbench')][string]$Mode,
  [string]$OpsFile,
  [string]$BackupFile
)

$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

function Emit($type, $msg) {
  $o = @{ type = $type; msg = "$msg" } | ConvertTo-Json -Compress
  [Console]::Out.WriteLine("@@" + $o)
  [Console]::Out.Flush()
}
$script:quiet = $false
$script:progLabel = ''
function Log($msg) { if (-not $script:quiet) { Emit 'log' $msg } }
function Warn($msg) { Emit 'warn' $msg }

. (Join-Path $PSScriptRoot 'system.ps1')   # القراءات والحساسات والعمليات والفحص الشامل
. (Join-Path $PSScriptRoot 'repair.ps1')   # مركز الإصلاح
. (Join-Path $PSScriptRoot 'tools.ps1')    # الأدوات: VPN وشريط المهام وإزالة البرامج
. (Join-Path $PSScriptRoot 'doctor.ps1')   # 
. (Join-Path $PSScriptRoot 'purity.ps1')   # لعبة صافية: الأوفرلاي والتسجيل داخل اللعبة
. (Join-Path $PSScriptRoot 'gpuoc.ps1')    # كرت NVIDIA: إعدادات التعريف وكسر السرعة   # طبيب الجهاز ووضع اللعب

# ---------------- Registry (.NET, no reg.exe spawning) ----------------
function Split-RegPath([string]$path) {
  $p = $path -replace '^Registry::', ''
  $i = $p.IndexOf('\')
  if ($i -lt 0) { $hive = $p; $sub = '' } else { $hive = $p.Substring(0, $i); $sub = $p.Substring($i + 1) }
  switch -Regex ($hive.ToUpper()) {
    '^(HKLM|HKEY_LOCAL_MACHINE)$' { $base = [Microsoft.Win32.Registry]::LocalMachine }
    '^(HKCU|HKEY_CURRENT_USER)$' { $base = [Microsoft.Win32.Registry]::CurrentUser }
    '^(HKU|HKEY_USERS)$' { $base = [Microsoft.Win32.Registry]::Users }
    '^(HKCR|HKEY_CLASSES_ROOT)$' { $base = [Microsoft.Win32.Registry]::ClassesRoot }
    default { throw "Unknown hive: $hive" }
  }
  return @($base, $sub)
}

function Get-RegState([string]$k, [string]$n) {
  $b = Split-RegPath $k
  $key = $b[0].OpenSubKey($b[1], $false)
  if ($null -eq $key) { return @{ exists = $false } }
  try {
    if (-not ($key.GetValueNames() -contains $n)) { return @{ exists = $false } }
    $kind = $key.GetValueKind($n).ToString()
    $val = $key.GetValue($n, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
    switch ($kind) {
      'Binary' { $val = ($val | ForEach-Object { $_.ToString('X2') }) -join '' }
      'DWord' { $val = [uint32]([BitConverter]::ToUInt32([BitConverter]::GetBytes([int32]$val), 0)) }
      'QWord' { $val = [string]$val }
      'MultiString' { $val = @($val) }
    }
    return @{ exists = $true; kind = $kind; value = $val }
  } finally { $key.Close() }
}

function Set-RegValueDirect([string]$k, [string]$n, [string]$kind, $v) {
  $b = Split-RegPath $k
  $key = $b[0].CreateSubKey($b[1], $true)
  try {
    switch -Regex ($kind) {
      '^(DWORD|DWord)$' {
        $u = [uint32]([double]$v)
        $key.SetValue($n, [BitConverter]::ToInt32([BitConverter]::GetBytes($u), 0), [Microsoft.Win32.RegistryValueKind]::DWord)
      }
      '^(QWORD|QWord)$' { $key.SetValue($n, [int64]$v, [Microsoft.Win32.RegistryValueKind]::QWord) }
      '^(SZ|String)$' { $key.SetValue($n, [string]$v, [Microsoft.Win32.RegistryValueKind]::String) }
      '^(EXPAND_SZ|ExpandString)$' { $key.SetValue($n, [string]$v, [Microsoft.Win32.RegistryValueKind]::ExpandString) }
      '^(MULTI_SZ|MultiString)$' { $key.SetValue($n, [string[]]@($v), [Microsoft.Win32.RegistryValueKind]::MultiString) }
      '^(BINARY|Binary)$' {
        $hex = [string]$v
        $bytes = New-Object byte[] ($hex.Length / 2)
        for ($i = 0; $i -lt $bytes.Length; $i++) { $bytes[$i] = [Convert]::ToByte($hex.Substring($i * 2, 2), 16) }
        $key.SetValue($n, $bytes, [Microsoft.Win32.RegistryValueKind]::Binary)
      }
      default { throw "Unknown kind $kind" }
    }
  } finally { $key.Close() }
}

function Remove-RegValueDirect([string]$k, [string]$n) {
  $b = Split-RegPath $k
  $key = $b[0].OpenSubKey($b[1], $true)
  if ($null -eq $key) { return }
  try { $key.DeleteValue($n, $false) } finally { $key.Close() }
}

# مفاتيح محمية (خدمات Defender والتحديثات وغيرها) ما يقدر يكتبها حتى المسؤول — نكتبها كـ SYSTEM
# عن طريق مهمة مجدولة مؤقتة تشغّل reg.exe، وبعدين نتأكد إن القيمة انكتبت. لـ HKLM بس.
function Test-AccessError($e) { return ($e.Exception.ToString() -match 'Unauthorized|SecurityException|denied|not allowed|Requested registry access') }
function Invoke-RegAsSystem([string]$k, [string]$n, [string]$kind, $v, [switch]$Delete) {
  if ($k -notmatch '^(HKLM|HKEY_LOCAL_MACHINE)\\') { throw "ممنوع الوصول (والكتابة كـ SYSTEM للمفاتيح HKLM بس): $k" }
  $full = 'HKLM\' + ($k -replace '^[^\\]+\\', '')
  if ($Delete) { $cmd = 'reg.exe delete "' + $full + '" /v "' + $n + '" /f' }
  else {
    $t = switch -Regex ($kind) { '^(DWORD|DWord)$' { 'REG_DWORD' } '^(QWORD|QWord)$' { 'REG_QWORD' } '^(SZ|String)$' { 'REG_SZ' } '^(EXPAND_SZ|ExpandString)$' { 'REG_EXPAND_SZ' } '^(BINARY|Binary)$' { 'REG_BINARY' } default { $null } }
    if (-not $t) { throw "نوع $kind ما ينكتب كـ SYSTEM" }
    $d = if ($t -eq 'REG_DWORD') { [string][uint32]([double]$v) } else { [string]$v }
    $cmd = 'reg.exe add "' + $full + '" /v "' + $n + '" /t ' + $t + ' /d "' + $d + '" /f'
  }
  $id = 'DemsetSys_' + [guid]::NewGuid().ToString('N').Substring(0, 10)
  $dir = Join-Path $env:windir 'Temp'
  $bat = Join-Path $dir ($id + '.cmd'); $done = Join-Path $dir ($id + '.done')
  Set-Content -LiteralPath $bat -Value ("@echo off`r`n" + $cmd + " >nul 2>&1`r`necho %errorlevel%> `"" + $done + "`"`r`n") -Encoding ASCII
  try {
    & schtasks.exe /create /tn $id /ru SYSTEM /rl HIGHEST /sc once /st 00:00 /f /tr $bat 2>&1 | Out-Null
    & schtasks.exe /run /tn $id 2>&1 | Out-Null
    $t0 = Get-Date
    while (-not (Test-Path -LiteralPath $done) -and ((Get-Date) - $t0).TotalSeconds -lt 20) { Start-Sleep -Milliseconds 200 }
  } finally {
    & schtasks.exe /delete /tn $id /f 2>&1 | Out-Null
    Remove-Item -LiteralPath $bat, $done -Force -ErrorAction SilentlyContinue
  }
  $st = Get-RegState $k $n
  $ok = if ($Delete) { -not $st.exists } else { $st.exists -and ("$($st.value)" -eq $(if ($kind -match '^(DWORD|DWord)$') { "$([uint32]([double]$v))" } else { "$v" })) }
  if (-not $ok) { throw "المفتاح محمي حتى من SYSTEM (غالبًا TrustedInstaller أو Tamper Protection): $k\$n" }
  Log ("  (انكتب كـ SYSTEM) " + $n)
}
function Set-RegValue([string]$k, [string]$n, [string]$kind, $v) {
  try { Set-RegValueDirect $k $n $kind $v }
  catch { if (Test-AccessError $_) { Invoke-RegAsSystem $k $n $kind $v } else { throw } }
}
function Remove-RegValue([string]$k, [string]$n) {
  try { Remove-RegValueDirect $k $n }
  catch { if (Test-AccessError $_) { Invoke-RegAsSystem $k $n '' $null -Delete } else { throw } }
}

function Test-RegKey([string]$k) {
  $b = Split-RegPath $k
  $key = $b[0].OpenSubKey($b[1], $false)
  if ($null -eq $key) { return $false }
  $key.Close(); return $true
}

# ---------------- System facts ----------------
$script:ramKB = $null
# حد تجميع svchost: لازم يكون أكبر من الرام المركّبة (مو بس المتاحة)، وإلا الويندوز يكمل يفصل الخدمات.
# نستخدم الرام المركّبة + 1 جيجا هامش.
function Get-RamKB {
  if ($null -eq $script:ramKB) {
    $installed = 0
    try { $installed = [double](Get-CimInstance Win32_PhysicalMemory -ErrorAction Stop | Measure-Object Capacity -Sum).Sum } catch {}
    $visible = [double](Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory
    $kb = [math]::Max($installed, $visible) / 1024 + 1048576
    $script:ramKB = [uint32][math]::Min(4294967295, [math]::Round($kb))
  }
  return $script:ramKB
}
function Resolve-Value($v) {
  if ($v -is [string] -and $v -eq 'RAM_KB') { return (Get-RamKB) }
  return $v
}

function Get-PciDevices([string]$cls, [string]$vendor) {
  $list = @()
  try {
    $devs = Get-PnpDevice -Class $cls -PresentOnly -ErrorAction SilentlyContinue
    foreach ($d in $devs) {
      $id = $d.InstanceId
      if ($cls -ne 'DiskDrive' -and $id -notlike 'PCI\*') { continue }
      if ($vendor -and $id -notmatch ("VEN_" + $vendor)) { continue }
      $list += $id
    }
  } catch {}
  return $list
}

function Get-GpuClassKeys([string]$vendor) {
  $keys = @()
  foreach ($id in (Get-PciDevices 'Display' $vendor)) {
    try {
      $drv = (Get-ItemProperty -LiteralPath ("Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Enum\" + $id) -Name Driver -ErrorAction Stop).Driver
      if ($drv) { $keys += ("HKLM\SYSTEM\CurrentControlSet\Control\Class\" + $drv) }
    } catch {}
  }
  return $keys
}

# ---------------- Expand dynamic ops into concrete ones ----------------
# نواة أداء (P-core) للمقاطعات: نتجنب النواة 0 (عليها شغل الويندوز). على المعالجات العادية ناخذ النواة الثانية.
function Get-PCoreMask {
  if (-not ('DemsetCores' -as [type])) {
    Add-Type -TypeDefinition @'
using System; using System.Collections.Generic; using System.Runtime.InteropServices;
public static class DemsetCores {
  [DllImport("kernel32.dll", SetLastError = true)] static extern bool GetLogicalProcessorInformationEx(int rel, IntPtr buf, ref int len);
  // كل نواة: [فئة الكفاءة، أول معالج منطقي فيها]
  public static List<int[]> Cores() {
    var res = new List<int[]>(); int len = 0; GetLogicalProcessorInformationEx(0, IntPtr.Zero, ref len);
    IntPtr b = Marshal.AllocHGlobal(len);
    try {
      if (!GetLogicalProcessorInformationEx(0, b, ref len)) return res;
      int off = 0;
      while (off < len) {
        IntPtr e = new IntPtr(b.ToInt64() + off); int size = Marshal.ReadInt32(e, 4);
        int eff = Marshal.ReadByte(e, 9); int groupCount = Marshal.ReadInt16(e, 30);
        long mask = Marshal.ReadInt64(e, 32); int grp = Marshal.ReadInt16(e, 40);
        if (grp == 0 && mask != 0) { int first = 0; while (((mask >> first) & 1) == 0) first++; res.Add(new int[] { eff, first }); }
        off += size;
      }
    } finally { Marshal.FreeHGlobal(b); }
    return res;
  }
}
'@
  }
  $cores = @([DemsetCores]::Cores())
  if ($cores.Count -lt 2) { return $null }
  $maxEff = ($cores | ForEach-Object { $_[0] } | Measure-Object -Maximum).Maximum
  $p = @($cores | Where-Object { $_[0] -eq $maxEff } | Sort-Object { $_[1] })
  $pick = $(if ($p.Count -ge 2) { $p[1][1] } else { $p[0][1] })
  if ($pick -eq 0 -and $cores.Count -ge 2) { $pick = ($cores | Sort-Object { $_[1] })[1][1] }
  $bytes = [BitConverter]::GetBytes([uint64]1 -shl $pick)
  return @{ cpu = $pick; hex = (($bytes | ForEach-Object { $_.ToString('X2') }) -join '') }
}

function Expand-Op($op) {
  switch ($op.t) {
    'irqpcore' {
      # مقاطعات كرت الشاشة على نواة أداء (P-core) غير الأولى
      $cpu = Get-PCoreMask
      if (-not $cpu) { Log '  - ما قدرت أحدد أنوية الأداء'; return @() }
      $out = @()
      foreach ($id in (Get-PciDevices 'Display' $op.vendor)) {
        $k = "HKLM\SYSTEM\CurrentControlSet\Enum\" + $id + "\Device Parameters\Interrupt Management\Affinity Policy"
        $out += [pscustomobject]@{ t = 'reg'; k = $k; n = 'DevicePolicy'; y = 'DWORD'; v = 4 }
        $out += [pscustomobject]@{ t = 'reg'; k = $k; n = 'AssignmentSetOverride'; y = 'BINARY'; v = $cpu.hex }
      }
      if (-not $out.Count) { Log '  - ما لقيت كرت شاشة' }
      return $out
    }
    'svc' {
      $k = "HKLM\SYSTEM\CurrentControlSet\Services\" + $op.n
      if (-not (Test-RegKey $k)) { Log ("  - الخدمة غير موجودة: " + $op.n + " (تخطي)"); return @() }
      return @([pscustomobject]@{ t = 'reg'; k = $k; n = 'Start'; y = 'DWORD'; v = $op.v })
    }
    'devreg' {
      $out = @()
      $ids = Get-PciDevices $op.cls $op.vendor
      if ($ids.Count -eq 0) { Log ("  - ما لقيت أجهزة من نوع " + $op.cls) }
      foreach ($id in $ids) {
        $k = "HKLM\SYSTEM\CurrentControlSet\Enum\" + $id + "\" + $op.sub
        $out += [pscustomobject]@{ t = 'reg'; k = $k; n = $op.n; y = $op.y; v = $op.v }
      }
      return $out
    }
    'gpucls' {
      $out = @()
      $keys = Get-GpuClassKeys $op.vendor
      if ($keys.Count -eq 0) { Log ("  - ما لقيت كرت شاشة متوافق (VEN_" + $op.vendor + ")") }
      foreach ($k in $keys) {
        $kk = $k; if ($op.sub) { $kk = $k + "\" + $op.sub }
        $out += [pscustomobject]@{ t = 'reg'; k = $kk; n = $op.n; y = $op.y; v = $op.v }
      }
      return $out
    }
    'netif' {
      $out = @()
      $keys = Get-ActiveInterfaceKeys
      if ($keys.Count -eq 0) { Log '  - ما لقيت كرت شبكة متصل' }
      foreach ($k in $keys) { $out += [pscustomobject]@{ t = 'reg'; k = $k; n = $op.n; y = 'DWORD'; v = $op.v } }
      return $out
    }
    default { return @($op) }
  }
}

# ---------------- helpers for non-registry state ----------------
function Get-BcdValue([string]$name) {
  $txt = (& bcdedit /enum '{current}') 2>$null
  foreach ($line in $txt) {
    if ($line -match ("^\s*" + [regex]::Escape($name) + "\s+(.+?)\s*$")) { return $Matches[1] }
  }
  return $null
}
function Get-FsutilValue([string]$name) {
  $txt = (& fsutil behavior query $name) 2>$null | Out-String
  if ($txt -match '=\s*(\d+)') { return $Matches[1] }
  return $null
}
function Get-PowerIndex([string]$sub, [string]$setting) {
  $txt = (& powercfg /q scheme_current $sub $setting) 2>$null | Out-String
  $m = [regex]::Matches($txt, '0x([0-9a-fA-F]{8})')
  if ($m.Count -lt 2) { return $null }
  return @{ ac = [Convert]::ToUInt32($m[$m.Count - 2].Groups[1].Value, 16); dc = [Convert]::ToUInt32($m[$m.Count - 1].Groups[1].Value, 16) }
}
# تعريف إعداد الطاقة: الـ GUID والحد الأدنى والأعلى ومكانه بالريجستري
function Get-PowerSettingDef([string]$sub, [string]$setting) {
  $txt = (& powercfg /q scheme_current $sub $setting) 2>$null | Out-String
  $g = [regex]::Matches($txt, '(?i)GUID:\s*([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})')
  if ($g.Count -lt 2) { return $null }
  # الترتيب: خطة الطاقة، المجموعة، الإعداد
  $subG = $g[$g.Count - 2].Groups[1].Value; $setG = $g[$g.Count - 1].Groups[1].Value
  $mn = [regex]::Match($txt, '(?i)Minimum Possible Setting:\s*0x([0-9a-f]+)'); $mx = [regex]::Match($txt, '(?i)Maximum Possible Setting:\s*0x([0-9a-f]+)')
  return @{ sub = $subG; guid = $setG; reg = "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\$subG\$setG"
    min = $(if ($mn.Success) { [Convert]::ToUInt32($mn.Groups[1].Value, 16) } else { $null }); max = $(if ($mx.Success) { [Convert]::ToUInt32($mx.Groups[1].Value, 16) } else { $null }) }
}
function Get-ActiveScheme {
  $txt = (& powercfg /getactivescheme) 2>$null | Out-String
  if ($txt -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})') { return $Matches[1] }
  return $null
}
function Split-TaskPath([string]$full) {
  $i = $full.LastIndexOf('\')
  return @($full.Substring(0, $i + 1), $full.Substring($i + 1))
}

# ---------------- apply one concrete op, return backup record ----------------
function Invoke-ApplyOp($op) {
  switch ($op.t) {
    'reg' {
      $v = Resolve-Value $op.v
      $prior = Get-RegState $op.k $op.n
      if ($op.y -eq 'DEL') { Remove-RegValue $op.k $op.n; Log ("  حذف  " + $op.k + " \ " + $op.n) }
      else { Set-RegValue $op.k $op.n $op.y $v; Log ("  ضبط  " + $op.n + " = " + $v) }
      return @{ t = 'reg'; k = $op.k; n = $op.n; prior = $prior }
    }
    'task' {
      $sp = Split-TaskPath $op.n
      $task = Get-ScheduledTask -TaskPath $sp[0] -TaskName $sp[1] -ErrorAction SilentlyContinue
      if ($null -eq $task) { Log ("  - المهمة غير موجودة: " + $sp[1] + " (تخطي)"); return $null }
      $wasEnabled = ($task.State -ne 'Disabled')
      if ($op.v) { Enable-ScheduledTask -InputObject $task -ErrorAction Stop | Out-Null }
      else { Stop-ScheduledTask -InputObject $task -ErrorAction SilentlyContinue; Disable-ScheduledTask -InputObject $task -ErrorAction Stop | Out-Null }
      Log ("  مهمة " + $sp[1] + (& { if ($op.v) { ' مفعّلة' } else { ' موقوفة' } }))
      return @{ t = 'task'; n = $op.n; prior = $wasEnabled }
    }
    'bcd' {
      $prior = Get-BcdValue $op.n
      if ($null -eq $op.v) { & bcdedit /deletevalue '{current}' $op.n 2>&1 | Out-Null }
      else { & bcdedit /set '{current}' $op.n $op.v 2>&1 | Out-Null }
      Log ("  BCD " + $op.n + " = " + $(if ($null -eq $op.v) { '(محذوف)' } else { $op.v }))
      return @{ t = 'bcd'; n = $op.n; prior = $prior }
    }
    'fsutil' {
      $prior = Get-FsutilValue $op.n
      & fsutil behavior set $op.n $op.v 2>&1 | Out-Null
      Log ("  NTFS " + $op.n + " = " + $op.v)
      return @{ t = 'fsutil'; n = $op.n; prior = $prior }
    }
    'pattr' {
      & powercfg -attributes $op.s $op.n -ATTRIB_HIDE 2>&1 | Out-Null
      return $null
    }
    'nvdrs' {
      $prior = Get-NvDrs $op
      $r = [DemsetNv]::Set([uint32]$op.id, [int64]$op.v, [bool]$op.bin)
      if ($r -ne 0) { throw ("تعريف NVIDIA رفض الإعداد " + $op.label + " (كود $r)") }
      Log ("  NVIDIA: " + $op.label)
      return @{ t = 'nvdrs'; id = $op.id; label = $op.label; prior = $prior }
    }
    'pcfg' {
      $prior = Get-PowerIndex $op.s $op.n
      if ($null -eq $prior) { Log ("  - إعداد طاقة غير مدعوم: " + $op.n + " (تخطي)"); return $null }
      $vmax = $null
      # بعض الأجهزة (أو برامج تحسين ثانية) تخلي أقصى قيمة مسموحة للإعداد أقل من المطلوب، فـ powercfg يرفض.
      # نرفع الحد في تعريف الإعداد نفسه (ونحفظ القديم للتراجع) ثم نكتب القيمة.
      $want = [uint32]$(if ($null -ne $op.dc) { [math]::Max([uint32]$op.ac, [uint32]$op.dc) } else { $op.ac })
      $def = Get-PowerSettingDef $op.s $op.n
      if ($def -and $null -ne $def.max -and $def.max -lt $want -and (Test-Path -LiteralPath $def.reg)) {
        $old = (Get-ItemProperty -LiteralPath $def.reg -Name ValueMax -ErrorAction SilentlyContinue).ValueMax
        Set-ItemProperty -LiteralPath $def.reg -Name ValueMax -Value $want -Type DWord -ErrorAction Stop
        $vmax = @{ reg = $def.reg; prior = $old }
        Log ("  حد " + $op.n + " كان " + $def.max + " — رفعته لـ " + $want)
      }
      $o1 = ((& powercfg /setacvalueindex scheme_current $op.s $op.n $op.ac) 2>&1 | Out-String).Trim(); $e1 = $LASTEXITCODE
      $e2 = 0; if ($null -ne $op.dc) { $o2 = ((& powercfg /setdcvalueindex scheme_current $op.s $op.n $op.dc) 2>&1 | Out-String).Trim(); $e2 = $LASTEXITCODE }
      & powercfg /setactive scheme_current 2>&1 | Out-Null
      $now = Get-PowerIndex $op.s $op.n
      if ($e1 -ne 0 -or $e2 -ne 0 -or ($now -and $now.ac -ne [uint32]$op.ac)) {
        if ($vmax) { if ($null -eq $vmax.prior) { Remove-ItemProperty -LiteralPath $vmax.reg -Name ValueMax -ErrorAction SilentlyContinue } else { Set-ItemProperty -LiteralPath $vmax.reg -Name ValueMax -Value $vmax.prior -Type DWord } }
        $msg = ("$o1 $o2" -replace '(?s)At .*', '' -replace '^powercfg(\.exe)?\s*:\s*', '').Trim()
        throw ("ويندوز رفض " + $op.n + " = " + $op.ac + " (الحالي " + $(if ($now) { $now.ac } else { '?' }) + ", الحد " + $(if ($def) { "$($def.min)–$($def.max)" } else { '?' }) + "): " + $msg)
      }
      Log ("  طاقة " + $op.n + " = " + $op.ac)
      return @{ t = 'pcfg'; s = $op.s; n = $op.n; prior = $prior; vmax = $vmax }
    }
    'mmagent' {
      $state = Get-MMAgent
      $prior = [bool]$state.($op.n)
      $p = @{}; $p[$op.n] = $true
      if ($op.v) { Enable-MMAgent @p -ErrorAction Stop } else { Disable-MMAgent @p -ErrorAction Stop }
      Log ("  " + $op.n + " = " + $op.v)
      return @{ t = 'mmagent'; n = $op.n; prior = $prior }
    }
    'plan' {
      $prior = Get-ActiveScheme
      $created = $null
      $list = (& powercfg /list) 2>$null
      $existing = $null
      foreach ($l in $list) { if ($l -match '(Polar|Demset) Ultimate Performance' -and $l -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})') { $existing = $Matches[1] } }
      if ($existing) { & powercfg /changename $existing 'Demset Ultimate Performance' 2>&1 | Out-Null; & powercfg /setactive $existing 2>&1 | Out-Null; Log '  تم تفعيل خطة Demset Ultimate Performance'; return @{ t = 'plan'; prior = $prior; created = $null } }
      $out = (& powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61) 2>&1 | Out-String
      if ($out -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})') { $created = $Matches[1] }
      if ($created) {
        & powercfg /changename $created 'Demset Ultimate Performance' 2>&1 | Out-Null
        & powercfg /setactive $created 2>&1 | Out-Null
        Log "  تم تفعيل خطة Ultimate Performance"
      } else {
        & powercfg /setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c 2>&1 | Out-Null
        Log "  جهازك ما يدعم Ultimate Performance، فعّلت High Performance بدالها"
      }
      return @{ t = 'plan'; prior = $prior; created = $created }
    }
    'dns' {
      $ads = @(Get-UpAdapters)
      if ($ads.Count -eq 0) { throw 'ما فيه كرت شبكة متصل' }
      $priors = @()
      foreach ($a in $ads) {
        $priors += (Get-AdapterDnsState $a)
        $addr = @($op.primary); if ($op.secondary) { $addr += $op.secondary }
        Set-DnsClientServerAddress -InterfaceIndex $a.ifIndex -ServerAddresses $addr -ErrorAction Stop
        Log ("  DNS " + $a.Name + " = " + ($addr -join ', '))
      }
      Clear-DnsClientCache -ErrorAction SilentlyContinue
      return @{ t = 'dns'; adapters = $priors }
    }
    'ps' {
      Invoke-Expression $op.apply 2>&1 | ForEach-Object { Log ("  " + $_) }
      return @{ t = 'ps'; revert = $op.revert }
    }
    default { Warn ("نوع غير معروف: " + $op.t); return $null }
  }
}

# تطبيق تويك واحد: يرجّع @(عدد التغييرات, عدد الأخطاء) ويحفظ النسخة الاحتياطية بعد كل عملية
function Invoke-ApplyTweak($ops, [string]$backupFile) {
  $backup = New-Object System.Collections.ArrayList
  $fail = 0
  foreach ($raw in @($ops)) {
    foreach ($op in (Expand-Op $raw)) {
      try {
        $rec = Invoke-ApplyOp $op
        if ($null -ne $rec) { [void]$backup.Add($rec) }
      } catch { $fail++; Warn ("  خطأ: " + $_.Exception.Message) }
    }
    # احفظ النسخة بعد كل عملية عشان لو انقطع شي، التراجع يظل ممكن
    ConvertTo-Json -InputObject @($backup) -Depth 6 | Set-Content -LiteralPath $backupFile -Encoding UTF8
  }
  if ($backup.Count -eq 0) { ConvertTo-Json -InputObject @() | Set-Content -LiteralPath $backupFile -Encoding UTF8 }
  return @($backup.Count, $fail)
}

function Invoke-RevertRecord($r) {
  switch ($r.t) {
    'reg' {
      if ($r.prior.exists) {
        Set-RegValue $r.k $r.n $r.prior.kind $r.prior.value
        Log ("  رجّعت " + $r.n + " = " + ($r.prior.value -join ','))
      } else {
        Remove-RegValue $r.k $r.n
        Log ("  حذفت " + $r.n + " (ما كان موجود قبل)")
      }
    }
    'task' {
      $sp = Split-TaskPath $r.n
      $task = Get-ScheduledTask -TaskPath $sp[0] -TaskName $sp[1] -ErrorAction SilentlyContinue
      if ($task) {
        if ($r.prior) { Enable-ScheduledTask -InputObject $task | Out-Null } else { Disable-ScheduledTask -InputObject $task | Out-Null }
        Log ("  رجّعت المهمة " + $sp[1])
      }
    }
    'bcd' {
      if ($null -eq $r.prior) { & bcdedit /deletevalue '{current}' $r.n 2>&1 | Out-Null }
      else { & bcdedit /set '{current}' $r.n $r.prior 2>&1 | Out-Null }
      Log ("  رجّعت BCD " + $r.n)
    }
    'fsutil' {
      if ($null -ne $r.prior) { & fsutil behavior set $r.n $r.prior 2>&1 | Out-Null; Log ("  رجّعت NTFS " + $r.n + " = " + $r.prior) }
    }
    'nvdrs' {
      if ($r.prior.exists) { [void][DemsetNv]::Set([uint32]$r.id, [int64]$r.prior.value, ($r.prior.type -eq 1)) } else { [void][DemsetNv]::Delete([uint32]$r.id) }
      Log ("  رجّعت NVIDIA: " + $r.label)
    }
    'pcfg' {
      & powercfg /setacvalueindex scheme_current $r.s $r.n $r.prior.ac 2>&1 | Out-Null
      & powercfg /setdcvalueindex scheme_current $r.s $r.n $r.prior.dc 2>&1 | Out-Null
      & powercfg /setactive scheme_current 2>&1 | Out-Null
      if ($r.vmax -and $r.vmax.reg) { if ($null -eq $r.vmax.prior) { Remove-ItemProperty -LiteralPath $r.vmax.reg -Name ValueMax -ErrorAction SilentlyContinue } else { Set-ItemProperty -LiteralPath $r.vmax.reg -Name ValueMax -Value ([uint32]$r.vmax.prior) -Type DWord -ErrorAction SilentlyContinue } }
      Log ("  رجّعت طاقة " + $r.n)
    }
    'mmagent' {
      $p = @{}; $p[$r.n] = $true
      if ($r.prior) { Enable-MMAgent @p } else { Disable-MMAgent @p }
      Log ("  رجّعت " + $r.n)
    }
    'plan' {
      if ($r.prior) { & powercfg /setactive $r.prior 2>&1 | Out-Null }
      if ($r.created) { & powercfg /delete $r.created 2>&1 | Out-Null }
      Log "  رجّعت خطة الطاقة القديمة"
    }
    'dns' {
      foreach ($a in @($r.adapters)) {
        if ("$($a.prior)".Trim()) { Set-DnsClientServerAddress -InterfaceIndex $a.idx -ServerAddresses (("$($a.prior)" -split '[,\s]+') | Where-Object { $_ }) }
        else { Set-DnsClientServerAddress -InterfaceIndex $a.idx -ResetServerAddresses }
        Log ("  رجّعت DNS " + $a.name)
      }
      Clear-DnsClientCache -ErrorAction SilentlyContinue
    }
    'ps' { if ($r.revert) { Invoke-Expression $r.revert 2>&1 | ForEach-Object { Log ("  " + $_) } } }
  }
}

# ---------------- run (actions) ----------------
function Invoke-Cmd([string]$cmd) {
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = "$env:ComSpec"
  $psi.Arguments = "/d /c chcp 65001 >nul & " + $cmd
  $psi.UseShellExecute = $false
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError = $true
  $psi.CreateNoWindow = $true
  $psi.StandardOutputEncoding = [System.Text.Encoding]::UTF8
  $p = [System.Diagnostics.Process]::Start($psi)
  while (-not $p.StandardOutput.EndOfStream) {
    $line = $p.StandardOutput.ReadLine()
    $clean = ($line -replace "`0", '').Trim()
    if (-not $clean) { continue }
    $pm = [regex]::Match($clean, '(\d{1,3}(?:[.,]\d+)?)\s*%')
    if ($pm.Success) {
      $pv = [double]($pm.Groups[1].Value -replace ',', '.')
      if ($pv -le 100) { Emit 'progress' (@{ p = $pv; label = $script:progLabel } | ConvertTo-Json -Compress); continue }
    }
    Log ("  " + $clean)
  }
  $err = $p.StandardError.ReadToEnd()
  $p.WaitForExit()
  if ($err.Trim()) { Warn $err.Trim() }
  return $p.ExitCode
}

function Clear-Temp {
  $paths = @($env:TEMP, "$env:windir\Temp", "$env:windir\SoftwareDistribution\Download")
  $total = 0; $count = 0
  foreach ($p in $paths) {
    if (-not (Test-Path $p)) { continue }
    Log ("  تنظيف " + $p)
    Get-ChildItem -LiteralPath $p -Force -ErrorAction SilentlyContinue | ForEach-Object {
      $size = 0
      try {
        if ($_.PSIsContainer) { $size = (Get-ChildItem -LiteralPath $_.FullName -Recurse -Force -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum }
        else { $size = $_.Length }
        Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction Stop
        $total += [double]$size; $count++
      } catch {}
    }
  }
  Emit 'result' ("تم مسح " + $count + " عنصر — " + [math]::Round($total / 1MB, 1) + " MB")
}

function Remove-GhostDevices {
  $devs = Get-PnpDevice -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Unknown' }
  $n = 0
  foreach ($d in $devs) {
    & pnputil /remove-device $d.InstanceId 2>&1 | Out-Null
    if ($LASTEXITCODE -eq 0) { $n++; Log ("  حذف " + $d.FriendlyName) }
  }
  Emit 'result' ("تم حذف " + $n + " جهاز قديم")
}

# ---------------- info ----------------
function Get-Info {
  $cs = Get-CimInstance Win32_ComputerSystem
  $os = Get-CimInstance Win32_OperatingSystem
  $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
  $gpus = @(Get-CimInstance Win32_VideoController | ForEach-Object {
    $v = 'other'
    if ($_.PNPDeviceID -match 'VEN_10DE') { $v = 'nvidia' } elseif ($_.PNPDeviceID -match 'VEN_1002') { $v = 'amd' } elseif ($_.PNPDeviceID -match 'VEN_8086') { $v = 'intel' }
    @{ name = $_.Name; vendor = $v; driver = $_.DriverVersion }
  })
  $disks = @()
  try { $disks = @(Get-PhysicalDisk | ForEach-Object { @{ name = $_.FriendlyName; media = "$($_.MediaType)"; sizeGB = [math]::Round($_.Size / 1GB) } }) } catch {}
  $sysDisk = $null
  try {
    $part = Get-Partition -DriveLetter ($env:SystemDrive.TrimEnd(':')) -ErrorAction Stop
    $pd = Get-PhysicalDisk | Where-Object { $_.DeviceId -eq "$($part.DiskNumber)" }
    $sysDisk = "$($pd.MediaType)"
  } catch {}
  $battery = @(Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue).Count -gt 0
  $build = [int]$os.BuildNumber
  $vol = Get-Volume -DriveLetter ($env:SystemDrive.TrimEnd(':')) -ErrorAction SilentlyContinue
  $info = @{
    cpu = $cpu.Name.Trim(); cores = $cpu.NumberOfCores; threads = $cpu.NumberOfLogicalProcessors
    cpuVendor = $(if ($cpu.Manufacturer -match 'AMD') { 'amd' } elseif ($cpu.Manufacturer -match 'Intel') { 'intel' } else { 'other' })
    ramGB = [math]::Round($cs.TotalPhysicalMemory / 1GB)
    os = $os.Caption; build = $build; win11 = ($build -ge 22000)
    gpus = $gpus; disks = $disks; systemDisk = $sysDisk
    laptop = $battery
    freeGB = $(if ($vol) { [math]::Round($vol.SizeRemaining / 1GB) } else { $null })
    totalGB = $(if ($vol) { [math]::Round($vol.Size / 1GB) } else { $null })
    pc = $env:COMPUTERNAME
  }
  Emit 'info' ($info | ConvertTo-Json -Compress -Depth 5)
}

# =============================================================
#  Demset Tweaks — ميزات إضافية
# =============================================================

# ---------------- network helpers ----------------
function Get-ActiveInterfaceKeys {
  $base = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces'
  $out = @()
  foreach ($k in (Get-ChildItem $base -ErrorAction SilentlyContinue)) {
    $p = Get-ItemProperty $k.PSPath -ErrorAction SilentlyContinue
    $ip = "$($p.DhcpIPAddress)$($p.IPAddress)"
    if ($ip -and $ip -notmatch '^(0\.0\.0\.0)*$') { $out += ('HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\' + $k.PSChildName) }
  }
  return $out
}
function Get-UpAdapters {
  try { return @(Get-NetAdapter -Physical -ErrorAction Stop | Where-Object { $_.Status -eq 'Up' }) } catch { return @() }
}
function Get-AdapterDnsState($a) {
  $guid = $a.InterfaceGuid
  $key = 'HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\' + $guid
  $st = Get-RegState $key 'NameServer'
  $static = ''
  if ($st.exists) { $static = [string]$st.value }
  return @{ idx = $a.ifIndex; name = $a.Name; prior = $static }
}

# ---------------- verify ----------------
function Test-ConcreteOp($op) {
  switch ($op.t) {
    'reg' {
      $st = Get-RegState $op.k $op.n
      if ($op.y -eq 'DEL') { return (-not $st.exists) }
      if (-not $st.exists) { return $false }
      $v = Resolve-Value $op.v
      # svchost: أي قيمة أكبر من الرام المركّبة تعتبر مطبّقة
      if ($op.v -is [string] -and $op.v -eq 'RAM_KB') { try { return ([double]$st.value -ge ([double]$v - 1048576)) } catch { return $false } }
      switch -Regex ($op.y) {
        '^(DWORD|QWORD)$' { try { return ([double]$st.value -eq [double]$v) } catch { return $false } }
        '^BINARY$' { return ("$($st.value)".ToUpper() -eq "$v".ToUpper()) }
        default { return ("$($st.value)" -eq "$v") }
      }
    }
    'task' {
      $sp = Split-TaskPath $op.n
      $task = Get-ScheduledTask -TaskPath $sp[0] -TaskName $sp[1] -ErrorAction SilentlyContinue
      if ($null -eq $task) { return $null }
      return (($task.State -ne 'Disabled') -eq [bool]$op.v)
    }
    'bcd' {
      $cur = Get-BcdValue $op.n
      if ($null -eq $op.v) { return ($null -eq $cur) }
      return ("$cur" -eq "$($op.v)")
    }
    'fsutil' { $cur = Get-FsutilValue $op.n; if ($null -eq $cur) { return $null }; return ("$cur" -eq "$($op.v)") }
    'nvdrs' { try { $g = Get-NvDrs $op; return ($g.exists -and [int64]$g.value -eq [int64]$op.v) } catch { return $null } }
    'pcfg' {
      $i = Get-PowerIndex $op.s $op.n
      if ($null -eq $i) { return $null }
      $ok = ($i.ac -eq [uint32]$op.ac)
      if ($null -ne $op.dc) { $ok = $ok -and ($i.dc -eq [uint32]$op.dc) }
      return $ok
    }
    'mmagent' { try { return ([bool](Get-MMAgent).($op.n) -eq [bool]$op.v) } catch { return $null } }
    'plan' { $txt = (& powercfg /getactivescheme) 2>$null | Out-String; return ($txt -match 'Demset|Polar|Aziz|Ultimate') }
    'dns' {
      $a = Get-UpAdapters | Select-Object -First 1
      if (-not $a) { return $null }
      $cur = @((Get-DnsClientServerAddress -InterfaceIndex $a.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue).ServerAddresses)
      return ($cur -contains $op.primary)
    }
    default { return $null }
  }
}

# وصف القيمة الحالية مقابل المطلوبة (للفحص الشامل: يوضح وش اللي اختلف بالضبط)
# متى آخر مرة انكتب فيها مفتاح ريجستري — يساعدنا نعرف مين/متى رجّع التويك
function Get-RegKeyTime([string]$k) {
  try {
    if (-not ('DemsetRegTime' -as [type])) {
      Add-Type -TypeDefinition @'
using System; using System.Runtime.InteropServices; using Microsoft.Win32.SafeHandles;
public static class DemsetRegTime {
  [DllImport("advapi32.dll", CharSet = CharSet.Unicode)]
  static extern int RegQueryInfoKey(SafeRegistryHandle h, IntPtr cls, IntPtr clsLen, IntPtr res, IntPtr subKeys, IntPtr maxSub, IntPtr maxCls, IntPtr vals, IntPtr maxValName, IntPtr maxValLen, IntPtr secDesc, out long lastWrite);
  public static DateTime Get(Microsoft.Win32.RegistryKey key) { long ft; return RegQueryInfoKey(key.Handle, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, out ft) == 0 ? DateTime.FromFileTime(ft) : DateTime.MinValue; }
}
'@
    }
    $hive, $sub = $k -split '\\', 2
    $root = switch ($hive) { 'HKCU' { [Microsoft.Win32.Registry]::CurrentUser } 'HKLM' { [Microsoft.Win32.Registry]::LocalMachine } 'HKU' { [Microsoft.Win32.Registry]::Users } default { $null } }
    if (-not $root) { return $null }
    $key = $root.OpenSubKey($sub)
    if (-not $key) { return $null }
    try { $t = [DemsetRegTime]::Get($key) } finally { $key.Close() }
    if ($t -eq [DateTime]::MinValue) { return $null }
    return $t.ToString('yyyy-MM-dd HH:mm')
  } catch { return $null }
}

function Get-OpMismatch($op) {
  try {
    switch ($op.t) {
      'reg' {
        $st = Get-RegState $op.k $op.n
        $cur = if ($st.exists) { "$($st.value)" } else { 'مو موجود' }
        $want = if ($op.y -eq 'DEL') { 'محذوف' } else { "$(Resolve-Value $op.v)" }
        $when = Get-RegKeyTime $op.k
        return "$($op.n)=$cur (المطلوب $want)$(if ($when) { ' — المفتاح انكتب ' + $when })"
      }
      'pcfg' { $i = Get-PowerIndex $op.s $op.n; return "$($op.n)=$(if ($i) { $i.ac } else { '?' }) (المطلوب $($op.ac))" }
      'task' { return "مهمة $($op.n)" }
      'bcd' { return "bcd $($op.n)=$(Get-BcdValue $op.n) (المطلوب $($op.v))" }
      default { return "$($op.t) $($op.n)" }
    }
  } catch { return "$($op.t) $($op.n)" }
}

function Invoke-Verify($map) {
  $script:quiet = $true
  $res = @{}
  foreach ($prop in $map.PSObject.Properties) {
    $known = 0; $match = 0
    foreach ($raw in @($prop.Value)) {
      if ($raw.t -eq 'pattr' -or $raw.t -eq 'ps') { continue }
      foreach ($op in (Expand-Op $raw)) {
        $r = $null
        try { $r = Test-ConcreteOp $op } catch { $r = $null }
        if ($null -ne $r) { $known++; if ($r) { $match++ } }
      }
    }
    $s = 'unknown'
    if ($known -gt 0) { if ($match -eq $known) { $s = 'on' } elseif ($match -eq 0) { $s = 'off' } else { $s = 'partial' } }
    $res[$prop.Name] = @{ s = $s; m = $match; k = $known }
  }
  $script:quiet = $false
  Emit 'verify' ($res | ConvertTo-Json -Compress -Depth 4)
}

# ---------------- live monitor ----------------
function Test-PerfCounters {
  try {
    $s = Get-CimInstance Win32_PerfFormattedData_PerfOS_System -ErrorAction Stop
    return ([double]$s.Processes -gt 0)
  } catch { return $false }
}

# تنظيف الرام (نفس فكرة Boost في PC Manager و RAMMap)
function Invoke-MemClean {
  if (-not ('PolarMem' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class PolarMem {
  [DllImport("ntdll.dll")] static extern uint NtSetSystemInformation(int infoClass, ref int info, int len);
  [DllImport("ntdll.dll")] static extern uint RtlAdjustPrivilege(int priv, bool enable, bool thread, out bool was);
  [StructLayout(LayoutKind.Sequential)] struct MS { public uint len; public uint load; public ulong total, avail, tpf, apf, tv, av, aev; }
  [DllImport("kernel32.dll")] static extern bool GlobalMemoryStatusEx(ref MS m);
  public static ulong[] Status() { var m = new MS(); m.len = (uint)Marshal.SizeOf(typeof(MS)); GlobalMemoryStatusEx(ref m); return new ulong[] { m.total, m.avail, m.load }; }
  public static uint Run(int cmd) { bool w; RtlAdjustPrivilege(13, true, false, out w); RtlAdjustPrivilege(5, true, false, out w); int c = cmd; return NtSetSystemInformation(80, ref c, 4); }
}
'@
  }
  $before = [PolarMem]::Status()
  Log '  تفريغ ذاكرة العمليات…'
  $r1 = [PolarMem]::Run(2)
  Log '  كتابة الصفحات المعدّلة…'
  $r2 = [PolarMem]::Run(3)
  Log '  مسح الذاكرة الاحتياطية (Standby)…'
  $r3 = [PolarMem]::Run(4)
  Start-Sleep -Milliseconds 400
  $after = [PolarMem]::Status()
  $res = @{
    total = [math]::Round($before[0] / 1GB, 1)
    usedBefore = [math]::Round(($before[0] - $before[1]) / 1GB, 2)
    usedAfter = [math]::Round(($after[0] - $after[1]) / 1GB, 2)
    loadBefore = $before[2]; loadAfter = $after[2]
    ok = ($r1 -eq 0 -or $r3 -eq 0)
  }
  Emit 'memclean' ($res | ConvertTo-Json -Compress)
  Emit 'result' $(if ($res.ok) { 'done' } else { 'false' })
}

function Get-NetTotals {
  # مجموع البايتات المستقبلة والمرسلة لكل كروت الشبكة الشغالة (بدون Loopback/Tunnel)
  $rx = [int64]0; $tx = [int64]0
  foreach ($n in [Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces()) {
    if ($n.OperationalStatus -ne 'Up') { continue }
    $t = "$($n.NetworkInterfaceType)"
    if ($t -eq 'Loopback' -or $t -eq 'Tunnel') { continue }
    try { $st = $n.GetIPStatistics(); $rx += $st.BytesReceived; $tx += $st.BytesSent } catch {}
  }
  return @($rx, $tx)
}
function Start-Monitor($cfg) {
  $pingHost = "$($cfg.pingHost)"; if (-not $pingHost) { $pingHost = '1.1.1.1' }
  $pinger = New-Object Net.NetworkInformation.Ping
  $pingTask = $null; $lastPing = $null
  $net0 = Get-NetTotals; $netT = [Diagnostics.Stopwatch]::StartNew()
  $perfOk = Test-PerfCounters
  $hasSmi = [bool](Get-Command nvidia-smi.exe -ErrorAction SilentlyContinue) -or (Test-Path "$env:windir\System32\nvidia-smi.exe")
  $pawn = Test-PawnIO
  $tick = 0
  while ($true) {
    $o = @{ perfOk = $perfOk; pawnio = $pawn }
    # المعالج: GetSystemTimes (نفس مصدر Task Manager تقريبًا) — نافذة 1 ثانية
    $w = Measure-CpuWindow 1000
    $o.cpu = [int][math]::Round($w.cpu)
    $m = [PolarSys]::Mem()
    $o.ramTotal = [math]::Round($m[0] / 1GB, 1)
    $o.ramUsed = [math]::Round(($m[0] - $m[1]) / 1GB, 1)
    try { $o.fgPid = [int][PolarSys]::FgPid() } catch {}
    try { $o.fgFull = [PolarSys]::FgFull() } catch {}
    # مسار برنامج النافذة اللي قدامك (لكشف الألعاب) — نخزنه عشان ما نقراه كل ثانية
    if ($o.fgPid -and $o.fgPid -ne $script:fgCachePid) { $script:fgCachePid = $o.fgPid; $script:fgCacheExe = ''; try { $script:fgCacheExe = [PolarSys]::ExePath([uint32]$o.fgPid) } catch {} }
    if ($script:fgCacheExe) { $o.fgExe = $script:fgCacheExe }
    # سرعة المعالج الفعلية مقارنة بسرعته الأساسية (تنزل تحت 100% لو فيه خنق حراري أو طاقة)
    if ($perfOk) { try { if (-not $script:perfCtr) { $script:perfCtr = New-Object Diagnostics.PerformanceCounter('Processor Information', '% Processor Performance', '_Total'); [void]$script:perfCtr.NextValue() }; $o.cpuPerf = [int][math]::Round($script:perfCtr.NextValue()) } catch {} }
    # كرت الشاشة لغير NVIDIA (NVIDIA يقراه البرنامج من nvidia-smi مباشرة)
    if (-not $hasSmi -and $perfOk) {
      try {
        $eng = Get-CimInstance Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine -ErrorAction Stop | Where-Object { $_.Name -like '*engtype_3D' }
        $o.gpu = [int][math]::Min(100, ($eng | Measure-Object UtilizationPercentage -Sum).Sum)
      } catch {}
    }
    # الحرارة: حساسات حقيقية من LibreHardwareMonitor (تحتاج PawnIO لمعالجات Intel/AMD)
    if ($tick % 2 -eq 0) {
      $t = $null
      if ($pawn) { $t = Read-LhmTemps }
      if ($t -and $t.cpu) { $script:lastCpuT = $t.cpu; $script:lastCpuSrc = 'sensor' }
      else { $wt = Read-LhmWmiTemp; if ($wt) { $script:lastCpuT = $wt; $script:lastCpuSrc = 'lhm-app' } }
      if ($t -and $t.gpu) { $script:lastGpuT = $t.gpu }
    }
    if ($script:lastCpuT) { $o.cpuTemp = [int][math]::Round($script:lastCpuT); $o.cpuTempSrc = $script:lastCpuSrc }
    if ($script:lastGpuT -and -not $hasSmi) { $o.gpuTemp = [int][math]::Round($script:lastGpuT) }
    # الشبكة: سرعة التحميل والرفع الحقيقية (من عدادات كرت الشبكة نفسه)
    try {
      $net1 = Get-NetTotals; $sec = [math]::Max(0.2, $netT.Elapsed.TotalSeconds); $netT.Restart()
      $o.netDown = [math]::Round([math]::Max(0, $net1[0] - $net0[0]) * 8 / $sec / 1e6, 2)
      $o.netUp = [math]::Round([math]::Max(0, $net1[1] - $net0[1]) * 8 / $sec / 1e6, 2)
      $net0 = $net1
    } catch {}
    # البنق: ICMP حقيقي كل ثانية بدون ما يوقف الحلقة (نقرا نتيجة اللي قبل)
    try {
      if ($pingTask -and $pingTask.IsCompleted) {
        $pr = $pingTask.Result
        $lastPing = $(if ($pr.Status -eq 'Success') { [int]$pr.RoundtripTime } else { -1 })
        $pingTask = $null
      }
      if (-not $pingTask) { $pingTask = $pinger.SendPingAsync($pingHost, 1000) }
    } catch { $lastPing = -1; $pingTask = $null }
    if ($null -ne $lastPing) { $o.ping = $lastPing; $o.pingHost = $pingHost }
    Emit 'mon' ($o | ConvertTo-Json -Compress)
    $tick++
  }
}

# ---------------- benchmark ----------------
function Invoke-Bench([int]$samples = 10) {
  $perfOk = Test-PerfCounters
  $cpu = 0.0; $dpc = 0.0; $intr = 0.0; $ints = 0.0; $ctx = 0.0; $dpcRate = 0.0; $ram = 0.0; $procs = 0.0; $threads = 0.0; $perfCpu = 0.0
  for ($i = 1; $i -le $samples; $i++) {
    if ($perfOk) {
      try {
        $p = Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'"
        $s = Get-CimInstance Win32_PerfFormattedData_PerfOS_System
        $ctx += [double]$s.ContextSwitchesPersec; $dpcRate += [double]$p.DPCsQueuedPersec; $perfCpu += [double]$p.PercentProcessorTime
      } catch {}
    }
    $w = Measure-CpuWindow 1000
    $cpu += $w.cpu; $dpc += [double]$w.dpc; $intr += [double]$w.intr; $ints += [double]$w.ints
    $m = [PolarSys]::Mem(); $ram += ($m[0] - $m[1]) / 1GB
    $pl = @(Get-Process -ErrorAction SilentlyContinue)
    $procs += $pl.Count
    $threads += [double](($pl | ForEach-Object { $_.Threads.Count } | Measure-Object -Sum).Sum)
    Emit 'progress' (@{ p = [int](100 * $i / $samples); label = 'قياس' } | ConvertTo-Json -Compress)
  }
  $n = [double]$samples
  $r = @{
    cpu = [math]::Round($cpu / $n, 2); dpc = [math]::Round($dpc / $n, 3); intr = [math]::Round($intr / $n, 3); ints = [math]::Round($ints / $n)
    ram = [math]::Round($ram / $n, 2); procs = [math]::Round($procs / $n); threads = [math]::Round($threads / $n)
    ctx = $(if ($perfOk) { [math]::Round($ctx / $n) } else { $null }); dpcRate = $(if ($perfOk) { [math]::Round($dpcRate / $n) } else { $null })
    perfCpu = $(if ($perfOk) { [math]::Round($perfCpu / $n, 2) } else { $null })
    perfOk = $perfOk; src = 'GetSystemTimes+NtQuerySystemInformation'
  }
  Emit 'bench' ($r | ConvertTo-Json -Compress)
}

# ---------------- disks ----------------
function Get-DiskHealth {
  $list = @()
  foreach ($d in (Get-PhysicalDisk -ErrorAction SilentlyContinue)) {
    $rel = $null
    try { $rel = $d | Get-StorageReliabilityCounter -ErrorAction Stop } catch {}
    $list += @{
      name = "$($d.FriendlyName)".Trim(); media = "$($d.MediaType)"; bus = "$($d.BusType)"
      sizeGB = [math]::Round($d.Size / 1GB); health = "$($d.HealthStatus)"; status = "$($d.OperationalStatus)"
      temp = $(if ($rel -and $rel.Temperature) { [int]$rel.Temperature } else { $null })
      tempMax = $(if ($rel -and $rel.TemperatureMax) { [int]$rel.TemperatureMax } else { $null })
      wear = $(if ($rel -and $null -ne $rel.Wear) { [int]$rel.Wear } else { $null })
      hours = $(if ($rel -and $rel.PowerOnHours) { [int]$rel.PowerOnHours } else { $null })
      readErr = $(if ($rel) { $rel.ReadErrorsTotal } else { $null })
      writeErr = $(if ($rel) { $rel.WriteErrorsTotal } else { $null })
    }
  }
  Emit 'disks' (ConvertTo-Json -InputObject @($list) -Compress -Depth 4)
}

# ---------------- startup manager ----------------
$script:SA = 'Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\'
function Get-ExeFromCommand([string]$cmd) {
  $c = [Environment]::ExpandEnvironmentVariables($cmd.Trim())
  if ($c.StartsWith('"')) { $e = $c.IndexOf('"', 1); if ($e -gt 0) { return $c.Substring(1, $e - 1) } }
  $m = [regex]::Match($c, '^(.+?\.(exe|bat|cmd|com|lnk))', 'IgnoreCase')
  if ($m.Success) { return $m.Groups[1].Value }
  return ($c -split ' ')[0]
}
function Get-StartupEnabled([string]$hive, [string]$sub, [string]$name) {
  $st = Get-RegState ($hive + '\' + $script:SA + $sub) $name
  if (-not $st.exists -or -not $st.value) { return $true }
  $b = [Convert]::ToByte("$($st.value)".Substring(0, 2), 16)
  return (($b -band 1) -eq 0)
}
function Get-StartupItemsData {
  $items = @()
  $sources = @(
    @{ hive = 'HKCU'; key = 'HKCU\Software\Microsoft\Windows\CurrentVersion\Run'; sub = 'Run'; src = 'المستخدم' },
    @{ hive = 'HKLM'; key = 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run'; sub = 'Run'; src = 'كل المستخدمين' },
    @{ hive = 'HKLM'; key = 'HKLM\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run'; sub = 'Run32'; src = 'كل المستخدمين (32-bit)' },
    @{ hive = 'HKCU'; key = 'HKCU\Software\Microsoft\Windows\CurrentVersion\RunOnce'; sub = 'RunOnce'; src = 'مرة وحدة (المستخدم)'; once = $true },
    @{ hive = 'HKLM'; key = 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce'; sub = 'RunOnce'; src = 'مرة وحدة (كل المستخدمين)'; once = $true }
  )
  foreach ($s in $sources) {
    $b = Split-RegPath $s.key
    $k = $b[0].OpenSubKey($b[1], $false)
    if ($null -eq $k) { continue }
    foreach ($n in $k.GetValueNames()) {
      if (-not $n) { continue }
      $cmd = [string]$k.GetValue($n, '', [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
      $en = $(if ($s.once) { $true } else { Get-StartupEnabled $s.hive $s.sub $n })
      $items += @{ type = $(if ($s.once) { 'once' } else { 'run' }); hive = $s.hive; sub = $s.sub; name = $n; cmd = $cmd; src = $s.src; exe = (Get-ExeFromCommand $cmd); enabled = $en; key = $s.key }
    }
    $k.Close()
  }
  $folders = @(
    @{ hive = 'HKCU'; path = [Environment]::GetFolderPath('Startup'); src = 'مجلد بدء التشغيل' },
    @{ hive = 'HKLM'; path = [Environment]::GetFolderPath('CommonStartup'); src = 'مجلد بدء التشغيل العام' }
  )
  $sh = $null
  try { $sh = New-Object -ComObject WScript.Shell } catch {}
  foreach ($f in $folders) {
    if (-not $f.path -or -not (Test-Path $f.path)) { continue }
    foreach ($file in (Get-ChildItem -LiteralPath $f.path -File -ErrorAction SilentlyContinue)) {
      if ($file.Name -ieq 'desktop.ini') { continue }
      $target = $file.FullName
      if ($sh -and $file.Extension -ieq '.lnk') { try { $t = $sh.CreateShortcut($file.FullName).TargetPath; if ($t) { $target = $t } } catch {} }
      $items += @{ type = 'folder'; hive = $f.hive; sub = 'StartupFolder'; name = $file.Name; cmd = $target; src = $f.src; exe = $target; enabled = (Get-StartupEnabled $f.hive 'StartupFolder' $file.Name) }
    }
  }
  # مهام مجدولة تشتغل مع الدخول أو الإقلاع (غير مهام مايكروسوفت)
  try {
    foreach ($t in (Get-ScheduledTask -ErrorAction Stop)) {
      if ($t.TaskPath -like '\Microsoft\*') { continue }
      $trig = @($t.Triggers | Where-Object { $_ -and ("$($_.CimClass.CimClassName)" -match 'LogonTrigger|BootTrigger') })
      if (-not $trig.Count) { continue }
      $act = @($t.Actions | Where-Object { $_.Execute }) | Select-Object -First 1
      $exe = $(if ($act) { [Environment]::ExpandEnvironmentVariables("$($act.Execute)".Trim('"')) } else { '' })
      $items += @{ type = 'task'; hive = ''; sub = 'Task'; name = $t.TaskName; path = $t.TaskPath; cmd = $(if ($act) { "$($act.Execute) $($act.Arguments)".Trim() } else { '' }); src = $(if ("$($trig[0].CimClass.CimClassName)" -match 'Boot') { 'مهمة مجدولة (مع الإقلاع)' } else { 'مهمة مجدولة (مع الدخول)' }); exe = $exe; enabled = ("$($t.State)" -ne 'Disabled') }
    }
  } catch {}
  # تطبيقات المتجر اللي تشتغل مع الويندوز (نفس اللي يعرضها Task Manager)
  try {
    $root = 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\SystemAppData'
    foreach ($pk in (Get-ChildItem $root -ErrorAction Stop)) {
      foreach ($tk in (Get-ChildItem $pk.PSPath -ErrorAction SilentlyContinue)) {
        $st = (Get-ItemProperty $tk.PSPath -Name State -ErrorAction SilentlyContinue).State
        if ($null -eq $st) { continue }
        $pkg = $pk.PSChildName; $nm = ($pkg -split '_')[0]
        $items += @{ type = 'uwp'; hive = 'HKCU'; sub = 'UWP'; name = $nm; pkg = $pkg; task = $tk.PSChildName; cmd = $pkg; src = 'تطبيق من المتجر'; exe = ''; enabled = ($st -eq 2 -or $st -eq 4); state = [int]$st }
      }
    }
  } catch {}
  # خدمات برامج خارجية تشتغل تلقائيًا (مو من الويندوز)
  try {
    $winDir = $env:windir.ToLower()
    foreach ($sv in (Get-CimInstance Win32_Service -ErrorAction Stop | Where-Object { $_.StartMode -eq 'Auto' -and $_.PathName })) {
      $exe = Get-ExeFromCommand ([Environment]::ExpandEnvironmentVariables("$($sv.PathName)"))
      if (-not $exe -or $exe.ToLower().StartsWith($winDir)) { continue }
      $co = ''; try { $co = "$((Get-Item -LiteralPath $exe -ErrorAction Stop).VersionInfo.CompanyName)".Trim() } catch {}
      if ($co -match '^Microsoft') { continue }
      $items += @{ type = 'service'; hive = ''; sub = 'Service'; name = $sv.Name; display = $sv.DisplayName; cmd = "$($sv.PathName)"; src = 'خدمة تلقائية'; exe = $exe; enabled = $true; running = ($sv.State -eq 'Running') }
    }
    # الخدمات اللي وقفناها من البرنامج تظهر عشان تقدر ترجعها
    foreach ($sv in (Get-CimInstance Win32_Service -ErrorAction Stop | Where-Object { $_.StartMode -eq 'Manual' })) {
      $mark = Get-RegState ('HKLM\SYSTEM\CurrentControlSet\Services\' + $sv.Name) 'DemsetStartupOff'
      if (-not $mark.exists) { continue }
      $exe = Get-ExeFromCommand ([Environment]::ExpandEnvironmentVariables("$($sv.PathName)"))
      $items += @{ type = 'service'; hive = ''; sub = 'Service'; name = $sv.Name; display = $sv.DisplayName; cmd = "$($sv.PathName)"; src = 'خدمة تلقائية'; exe = $exe; enabled = $false; running = ($sv.State -eq 'Running') }
    }
  } catch {}
  foreach ($it in $items) {
    $it.company = ''; $it.desc = ''
    try {
      if ($it.exe -and (Test-Path -LiteralPath $it.exe)) {
        $vi = (Get-Item -LiteralPath $it.exe).VersionInfo
        $it.company = "$($vi.CompanyName)".Trim(); $it.desc = "$($vi.FileDescription)".Trim()
      }
    } catch {}
  }
  return $items
}
function Get-StartupItems { Emit 'startup' (ConvertTo-Json -InputObject @(Get-StartupItemsData) -Compress -Depth 4) }
function Set-StartupItem($o) {
  switch ("$($o.type)") {
    'task' {
      if ($o.enabled) { Enable-ScheduledTask -TaskName $o.name -TaskPath $o.path -ErrorAction Stop | Out-Null } else { Disable-ScheduledTask -TaskName $o.name -TaskPath $o.path -ErrorAction Stop | Out-Null }
      $now = "$((Get-ScheduledTask -TaskName $o.name -TaskPath $o.path).State)"
      if (($now -ne 'Disabled') -ne [bool]$o.enabled) { throw "الحالة ما تغيّرت ($now)" }
    }
    'uwp' {
      $k = 'HKCU\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\SystemAppData\' + $o.pkg + '\' + $o.task
      Set-RegValue $k 'State' 'DWORD' $(if ($o.enabled) { 2 } else { 1 })
    }
    'service' {
      $k = 'HKLM\SYSTEM\CurrentControlSet\Services\' + $o.name
      if ($o.enabled) { Set-Service -Name $o.name -StartupType Automatic -ErrorAction Stop; Remove-RegValue $k 'DemsetStartupOff' }
      else { Set-Service -Name $o.name -StartupType Manual -ErrorAction Stop; Set-RegValue $k 'DemsetStartupOff' 'DWORD' 1 }
      $mode = "$((Get-CimInstance Win32_Service -Filter ("Name='" + $o.name + "'")).StartMode)"
      if (($mode -eq 'Auto') -ne [bool]$o.enabled) { throw "نوع التشغيل ما تغيّر ($mode)" }
    }
    'once' { throw 'عناصر "مرة وحدة" تنحذف تلقائيًا بعد ما تشتغل — ما لها إيقاف' }
    default {
      $key = $o.hive + '\' + $script:SA + $o.sub
      if ($o.enabled) { $hex = '020000000000000000000000' }
      else {
        $ft = [BitConverter]::GetBytes([DateTime]::Now.ToFileTime())
        $hex = '03000000' + (($ft | ForEach-Object { $_.ToString('X2') }) -join '')
      }
      Set-RegValue $key $o.name 'BINARY' $hex
      if ((Get-StartupEnabled $o.hive $o.sub $o.name) -ne [bool]$o.enabled) { throw 'الحالة ما تغيّرت' }
    }
  }
  Log ("  " + $o.name + $(if ($o.enabled) { ' مفعّل' } else { ' موقوف' }))
  Emit 'result' 'ok'
}

# ---------------- Windows apps ----------------
function Get-BloatApps($patterns) {
  $out = @()
  foreach ($p in @($patterns)) {
    foreach ($pkg in @(Get-AppxPackage -Name $p -ErrorAction SilentlyContinue)) {
      if ($pkg.IsFramework -or $pkg.NonRemovable) { continue }
      $out += @{ pattern = $p; name = $pkg.Name; full = $pkg.PackageFullName; version = "$($pkg.Version)" }
    }
  }
  Emit 'apps' (ConvertTo-Json -InputObject @($out) -Compress -Depth 4)
}
function Remove-Apps($fulls) {
  $list = @($fulls); $i = 0; $ok = 0
  foreach ($f in $list) {
    $i++
    Emit 'progress' (@{ p = [int](100 * ($i - 1) / $list.Count); label = $f.Split('_')[0] } | ConvertTo-Json -Compress)
    try { Remove-AppxPackage -Package $f -ErrorAction Stop; $ok++; Log ("  حذف " + $f.Split('_')[0]) }
    catch { Warn ("  ما انحذف " + $f.Split('_')[0] + ": " + $_.Exception.Message) }
  }
  Emit 'progress' (@{ p = 100; label = '' } | ConvertTo-Json -Compress)
  Emit 'result' ("done:" + $ok + ":" + ($list.Count - $ok))
}

# ---------------- DNS benchmark ----------------
# ---------------- قياس البنق الحقيقي ----------------
# لكل هدف: 20 ping (ICMP) — أقل/متوسط/أعلى، الـ Jitter (متوسط الفرق بين كل قياسين)، ونسبة الضياع
function Invoke-PingTest($cfg) {
  $targets = @($cfg.targets)
  $gw = $null
  try { $gw = (Get-NetRoute -DestinationPrefix '0.0.0.0/0' -ErrorAction Stop | Sort-Object RouteMetric | Select-Object -First 1).NextHop } catch {}
  if ($gw -and $gw -ne '0.0.0.0') { $targets = @([pscustomobject]@{ name = 'الراوتر (شبكتك الداخلية)'; host = $gw; gw = $true }) + $targets }
  $count = [int]$cfg.count; if ($count -lt 5) { $count = 20 }
  $p = New-Object Net.NetworkInformation.Ping
  $out = @(); $i = 0
  foreach ($t in $targets) {
    $i++
    $rtts = @(); $lost = 0
    for ($k = 0; $k -lt $count; $k++) {
      try { $r = $p.Send($t.host, 1000); if ($r.Status -eq 'Success') { $rtts += [int]$r.RoundtripTime } else { $lost++ } } catch { $lost++ }
      Emit 'progress' (@{ p = [int]((($i - 1) * $count + $k + 1) * 100 / ($targets.Count * $count)); label = "$($t.name)" } | ConvertTo-Json -Compress)
      Start-Sleep -Milliseconds 120
    }
    $o = @{ name = "$($t.name)"; host = "$($t.host)"; gw = [bool]$t.gw; sent = $count; lost = $lost; loss = [math]::Round($lost * 100.0 / $count, 1) }
    if ($rtts.Count) {
      $o.min = ($rtts | Measure-Object -Minimum).Minimum; $o.max = ($rtts | Measure-Object -Maximum).Maximum
      $o.avg = [math]::Round(($rtts | Measure-Object -Average).Average, 1)
      $j = 0.0; for ($k = 1; $k -lt $rtts.Count; $k++) { $j += [math]::Abs($rtts[$k] - $rtts[$k - 1]) }
      $o.jitter = $(if ($rtts.Count -gt 1) { [math]::Round($j / ($rtts.Count - 1), 1) } else { 0 })
    }
    $out += $o
  }
  Emit 'pingtest' (ConvertTo-Json -InputObject @($out) -Compress)
}

function Invoke-DnsBench($servers) {
  $domains = @('google.com', 'youtube.com', 'discord.com', 'steampowered.com', 'cloudflare.com')
  $res = @()
  $list = @($servers)
  $cur = @()
  $a = Get-UpAdapters | Select-Object -First 1
  if ($a) { $cur = @((Get-DnsClientServerAddress -InterfaceIndex $a.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue).ServerAddresses) }
  if ($cur.Count -gt 0 -and -not ($list | Where-Object { $_.ip -eq $cur[0] })) { $list = @(@{ name = 'الحالي'; ip = $cur[0]; ip2 = $(if ($cur.Count -gt 1) { $cur[1] } else { '' }); current = $true }) + $list }
  $ping = New-Object System.Net.NetworkInformation.Ping
  $n = 0
  foreach ($s in $list) {
    $n++
    Emit 'progress' (@{ p = [int](100 * ($n - 1) / $list.Count); label = $s.name } | ConvertTo-Json -Compress)
    $pings = @()
    for ($k = 0; $k -lt 4; $k++) { try { $r = $ping.Send($s.ip, 1200); if ($r.Status -eq 'Success') { $pings += $r.RoundtripTime } } catch {} }
    $times = @(); $fails = 0
    foreach ($d in $domains) {
      $sw = [Diagnostics.Stopwatch]::StartNew()
      try { Resolve-DnsName -Name $d -Server $s.ip -DnsOnly -NoHostsFile -QuickTimeout -Type A -ErrorAction Stop | Out-Null; $sw.Stop(); $times += $sw.Elapsed.TotalMilliseconds }
      catch { $fails++ }
    }
    $res += @{
      name = $s.name; ip = $s.ip; ip2 = $s.ip2; current = [bool]$s.current
      ping = $(if ($pings.Count) { [math]::Round(($pings | Measure-Object -Average).Average) } else { $null })
      dns = $(if ($times.Count) { [math]::Round(($times | Measure-Object -Average).Average) } else { $null })
      fails = $fails
    }
  }
  Emit 'progress' (@{ p = 100; label = '' } | ConvertTo-Json -Compress)
  Emit 'dnsbench' (ConvertTo-Json -InputObject @($res) -Compress -Depth 4)
}

# ---------------- drive optimize with progress ----------------
function Invoke-OptimizeDrives {
  $vols = @(Get-Volume | Where-Object { $_.DriveLetter -and $_.DriveType -eq 'Fixed' } | Sort-Object DriveLetter)
  foreach ($v in $vols) {
    $script:progLabel = "$($v.DriveLetter):"
    Log ("> تحسين القرص " + $v.DriveLetter + ":")
    [void](Invoke-Cmd ("defrag " + $v.DriveLetter + ": /O /U /V"))
  }
  $script:progLabel = ''
}

# =============================================================
switch ($Mode) {
  'isadmin' {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $pr = New-Object Security.Principal.WindowsPrincipal($id)
    Emit 'result' ($pr.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator))
  }
  'info' { Get-Info }
  'verify' { Invoke-Verify (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json) }
  'monitor' { $mcfg = $null; if ($OpsFile -and (Test-Path -LiteralPath $OpsFile)) { $mcfg = Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json }; Start-Monitor $mcfg }
  'memclean' { Invoke-MemClean }
  'selftest' { Invoke-SelfTest (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json) }
  'uninst-list' { Emit 'uninstlist' (ConvertTo-Json -InputObject @(Get-UninstallList) -Compress -Depth 3) }
  'uninst-scan' { Emit 'leftovers' (ConvertTo-Json -InputObject @(Find-Leftovers (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json)) -Compress -Depth 3) }
  'uninst-clean' { Remove-Leftovers (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json) }
  'uninst-restore' { Restore-UninstallBackup ((Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json).dir) }
  'vpn' { Invoke-Vpn ((Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json).action) }
  'taskbar' { Invoke-Taskbar (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json) }
  'repair-check' { Invoke-RepairCheck (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json | ForEach-Object { $_ }) }
  'repair-fix' { try { Invoke-RepairFix ((Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json).id) } catch { Emit 'error' $_.Exception.Message; exit 1 } }
  'procmon' { $pc = $null; if ($OpsFile) { $pc = Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json }; Start-ProcMon $pc }
  'bufferbloat' { Invoke-Bufferbloat $(if ($OpsFile) { Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json }) }
  'shadercache' { Invoke-ShaderCache $(if ($OpsFile) { Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json }) }
  'pingtest' { Invoke-PingTest (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json) }
  'diskscan' { Invoke-DiskScan (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json) }
  'drives' { Emit 'drives' (ConvertTo-Json -InputObject @(Get-FixedDrives) -Compress) }
  'emptybin' {
    $before = 0; try { $before = (New-Object -ComObject Shell.Application).NameSpace(10).Items().Count } catch {}
    Clear-RecycleBin -Force -ErrorAction SilentlyContinue
    Emit 'result' ('done:' + $before + ':0')
  }
  'installed' { Emit 'installed' (ConvertTo-Json -InputObject @(Get-InstalledApps) -Compress -Depth 3) }
  'doctor' { Invoke-Doctor }
  'refresh-set' { Set-RefreshRate (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json) }
  'hooks' { Invoke-HookScan $(if ($OpsFile) { Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json }) }
  'hooks-stop' { Stop-Recorder (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json) }
  'gpuoc' { Invoke-GpuOc (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json) }
  'boost' { Invoke-GameBoost (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json) }
  'updates-scan' { Invoke-UpdatesScan $null }
  'updates-install' { Invoke-UpdatesInstall (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json) }
  'shortcut' { Add-AppShortcuts (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json) }
  'winget-user' { Invoke-WingetAsUser (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json) }
  'procs' { Emit 'procs' (ConvertTo-Json -InputObject @(Get-ProcList) -Compress -Depth 4) }
  'proc-kill' { Stop-Procs (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json | ForEach-Object { $_ }) }
  'proc-restart' { Restart-Procs (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json | ForEach-Object { $_ }) }
  'proc-priority' { Set-ProcPriority (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json | ForEach-Object { $_ }) }
  'pawnio' {
    $setup = Join-Path $PSScriptRoot '..\bin\PawnIO_setup.exe'
    if (Test-PawnIO) { Emit 'result' 'ok'; break }
    $p = Start-Process -FilePath $setup -ArgumentList '-install', '-silent' -Wait -PassThru
    if (Test-PawnIO) { Emit 'result' 'ok' } else { Emit 'error' ('تثبيت PawnIO ما نجح (كود ' + $p.ExitCode + ')'); exit 1 }
  }
  'bench' { Invoke-Bench 10 }
  'disks' { Get-DiskHealth }
  'startup-list' { Get-StartupItems }
  'startup-set' { try { Set-StartupItem (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { Emit 'error' $_.Exception.Message; exit 1 } }
  'apps-list' { Get-BloatApps (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json) }
  'apps-remove' { Remove-Apps (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json) }
  'dnsbench' { Invoke-DnsBench (Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json) }
  'restorepoint' {
    try {
      Enable-ComputerRestore -Drive "$env:SystemDrive\" -ErrorAction SilentlyContinue
      Set-RegValue 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore' 'SystemRestorePointCreationFrequency' 'DWORD' 0
      Log "  جاري إنشاء نقطة الاستعادة..."
      Checkpoint-Computer -Description 'Demset Tweaks' -RestorePointType MODIFY_SETTINGS -ErrorAction Stop
      Emit 'result' 'ok'
    } catch { Emit 'error' $_.Exception.Message; exit 1 }
  }
  'apply' {
    $ops = Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json
    $r = Invoke-ApplyTweak $ops $BackupFile
    Emit 'result' ("done:" + $r[0] + ":" + $r[1])
  }
  # تطبيق كذا تويك بعملية PowerShell وحدة (أسرع بكثير من عملية لكل تويك)
  'apply-many' {
    # PowerShell 5.1 يرجّع المصفوفة كعنصر واحد — ForEach-Object يفكّها لتويكات منفصلة
    $list = @(Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json | ForEach-Object { $_ })
    $i = 0
    foreach ($t in $list) {
      $i++
      Emit 'progress' (@{ p = [int](100 * ($i - 1) / $list.Count); label = "$($t.title)" } | ConvertTo-Json -Compress)
      Log ("▶ " + $t.title)
      $cnt = 0; $fl = 0; $err = ''
      try { $r = Invoke-ApplyTweak $t.ops $t.backup; $cnt = $r[0]; $fl = $r[1] } catch { $fl++; $err = $_.Exception.Message; Warn ("  خطأ: " + $err) }
      Emit 'tw' (@{ id = $t.id; count = $cnt; fail = $fl; error = $err } | ConvertTo-Json -Compress)
    }
    Emit 'progress' (@{ p = 100; label = '' } | ConvertTo-Json -Compress)
    Emit 'result' 'done'
  }
  'revert' {
    if (-not (Test-Path -LiteralPath $BackupFile)) { Emit 'error' 'ما فيه نسخة احتياطية لهذا التويك'; exit 1 }
    $recs = @(Get-Content -LiteralPath $BackupFile -Raw -Encoding UTF8 | ConvertFrom-Json | ForEach-Object { $_ })
    [array]::Reverse($recs)
    foreach ($r in $recs) {
      try { Invoke-RevertRecord $r } catch { Warn ("  خطأ: " + $_.Exception.Message) }
    }
    Emit 'result' 'reverted'
  }
  'run' {
    $ops = Get-Content -LiteralPath $OpsFile -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($op in $ops) {
      switch ($op.t) {
        'run' { Log ("> " + $(if ($op.label) { $op.label } else { $op.cmd })); [void](Invoke-Cmd $op.cmd) }
        'open' {
          Log ("> فتح " + $op.file)
          if ($op.args) { Start-Process -FilePath $op.file -ArgumentList $op.args } else { Start-Process -FilePath $op.file }
        }
        'optimize' { Invoke-OptimizeDrives }
        'cleantemp' { Clear-Temp }
        'ghostdevices' { Remove-GhostDevices }
      }
    }
    Emit 'result' 'done'
  }
}
